
-- Ajouter une colonne share_link à la table tontines si elle n'existe pas déjà
-- (Elle semble déjà exister selon le schéma, mais on s'assure qu'elle soit unique)
ALTER TABLE tontines ADD COLUMN IF NOT EXISTS share_link text UNIQUE DEFAULT gen_random_uuid()::text;

-- Créer un index pour optimiser les recherches par share_link
CREATE INDEX IF NOT EXISTS idx_tontines_share_link ON tontines(share_link);

-- Ajouter des colonnes pour tracker les tontines complétées
ALTER TABLE tontines ADD COLUMN IF NOT EXISTS completed_at timestamp with time zone;
ALTER TABLE tontines ADD COLUMN IF NOT EXISTS completion_percentage numeric DEFAULT 0;

-- Créer une table pour les liens de parrainage
CREATE TABLE IF NOT EXISTS referral_links (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  referral_code text UNIQUE NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamp with time zone DEFAULT now(),
  expires_at timestamp with time zone,
  total_referrals integer DEFAULT 0
);

-- Créer une table pour tracker qui a rejoint via quel lien
CREATE TABLE IF NOT EXISTS referral_signups (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  referrer_user_id uuid NOT NULL,
  referred_user_id uuid NOT NULL,
  referral_code text NOT NULL,
  signed_up_at timestamp with time zone DEFAULT now()
);

-- Créer une table pour les étapes de démo complétées
CREATE TABLE IF NOT EXISTS user_demo_progress (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  step_number integer NOT NULL,
  completed_at timestamp with time zone DEFAULT now(),
  UNIQUE(user_id, step_number)
);

-- Fonction pour vérifier si un utilisateur a complété au moins une tontine
CREATE OR REPLACE FUNCTION has_completed_tontine(user_uuid uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
AS $$
  SELECT EXISTS (
    SELECT 1 
    FROM tontines 
    WHERE creator_id = user_uuid 
    AND (status = 'completed' OR completion_percentage >= 100)
  );
$$;

-- Fonction pour générer un code de parrainage unique
CREATE OR REPLACE FUNCTION generate_unique_referral_code()
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  new_code text;
BEGIN
  LOOP
    new_code := upper(substring(encode(gen_random_bytes(4), 'base64') from 1 for 6));
    new_code := replace(replace(replace(new_code, '+', ''), '/', ''), '=', '');
    
    IF NOT EXISTS (SELECT 1 FROM referral_links WHERE referral_code = new_code) THEN
      EXIT;
    END IF;
  END LOOP;
  
  RETURN new_code;
END;
$$;

-- Trigger pour mettre à jour le statut de complétion des tontines
CREATE OR REPLACE FUNCTION update_tontine_completion()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  -- Calculer le pourcentage de complétion basé sur les paiements
  UPDATE tontines 
  SET completion_percentage = (
    SELECT COALESCE(
      (COUNT(CASE WHEN tp.is_paid = true THEN 1 END) * 100.0) / NULLIF(COUNT(*), 0),
      0
    )
    FROM tontine_payments tp 
    WHERE tp.tontine_id = NEW.tontine_id
  )
  WHERE id = NEW.tontine_id;
  
  -- Marquer comme complétée si 100%
  UPDATE tontines 
  SET 
    status = 'completed',
    completed_at = now()
  WHERE id = NEW.tontine_id 
  AND completion_percentage >= 100 
  AND status != 'completed';
  
  RETURN NEW;
END;
$$;

-- Créer le trigger pour la complétion automatique
DROP TRIGGER IF EXISTS trigger_update_completion ON tontine_payments;
CREATE TRIGGER trigger_update_completion
  AFTER INSERT OR UPDATE ON tontine_payments
  FOR EACH ROW
  EXECUTE FUNCTION update_tontine_completion();

-- Ajouter des politiques RLS pour les nouvelles tables
ALTER TABLE referral_links ENABLE ROW LEVEL SECURITY;
ALTER TABLE referral_signups ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_demo_progress ENABLE ROW LEVEL SECURITY;

-- Politiques pour referral_links
CREATE POLICY "Users can view their own referral links" 
  ON referral_links FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own referral links" 
  ON referral_links FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own referral links" 
  ON referral_links FOR UPDATE 
  USING (auth.uid() = user_id);

-- Politiques pour referral_signups
CREATE POLICY "Users can view referrals they made" 
  ON referral_signups FOR SELECT 
  USING (auth.uid() = referrer_user_id);

CREATE POLICY "System can insert referral signups" 
  ON referral_signups FOR INSERT 
  WITH CHECK (true);

-- Politiques pour user_demo_progress
CREATE POLICY "Users can view their own demo progress" 
  ON user_demo_progress FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own demo progress" 
  ON user_demo_progress FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

-- Mettre à jour les share_links existants s'ils sont null
UPDATE tontines SET share_link = gen_random_uuid()::text WHERE share_link IS NULL;

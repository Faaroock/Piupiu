
-- Ajouter le champ has_seen_demo à la table profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS has_seen_demo BOOLEAN DEFAULT FALSE;

-- Créer la table pour le système de parrainage (si elle n'existe pas déjà)
CREATE TABLE IF NOT EXISTS public.referral_earnings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  referrer_id UUID REFERENCES public.profiles(user_id) NOT NULL,
  referee_id UUID REFERENCES public.profiles(user_id) NOT NULL,
  tontine_id UUID REFERENCES public.tontines(id) NOT NULL,
  total_contributed NUMERIC NOT NULL,
  earning_amount NUMERIC NOT NULL,
  is_paid BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Mettre à jour la table user_roles pour inclure tous les rôles nécessaires
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
        CREATE TYPE user_role AS ENUM ('super_admin', 'admin', 'moderator', 'developer', 'user');
    END IF;
END $$;

-- Ajouter des contraintes pour le super admin
INSERT INTO public.user_roles (user_id, role, assigned_at)
SELECT u.id, 'super_admin', NOW()
FROM auth.users u
WHERE u.email = 'faaroockt@gmail.com'
AND NOT EXISTS (
  SELECT 1 FROM public.user_roles ur 
  WHERE ur.user_id = u.id AND ur.role = 'super_admin'
);

-- Améliorer la table tontines avec de nouvelles colonnes
ALTER TABLE public.tontines 
ADD COLUMN IF NOT EXISTS goal_amount NUMERIC DEFAULT 0,
ADD COLUMN IF NOT EXISTS currency TEXT DEFAULT 'F',
ADD COLUMN IF NOT EXISTS min_members INTEGER DEFAULT 2,
ADD COLUMN IF NOT EXISTS is_private BOOLEAN DEFAULT FALSE;

-- Créer une table pour l'historique de connexion
CREATE TABLE IF NOT EXISTS public.connection_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) NOT NULL,
  ip_address INET,
  user_agent TEXT,
  location TEXT,
  connected_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  session_duration INTERVAL
);

-- Créer une table pour l'historique des tontines
CREATE TABLE IF NOT EXISTS public.tontine_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tontine_id UUID REFERENCES public.tontines(id) NOT NULL,
  user_id UUID REFERENCES auth.users(id) NOT NULL,
  action TEXT NOT NULL,
  details JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Améliorer la table frozen_funds avec plus de détails
ALTER TABLE public.frozen_funds 
ADD COLUMN IF NOT EXISTS expires_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS auto_release BOOLEAN DEFAULT FALSE;

-- Fonction pour traiter les gains de parrainage quand une tontine se termine
CREATE OR REPLACE FUNCTION process_referral_earnings_on_completion()
RETURNS TRIGGER AS $$
BEGIN
  -- Si la tontine vient d'être marquée comme complétée
  IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
    -- Appeler la fonction existante pour traiter les gains
    PERFORM process_referral_earnings(NEW.id);
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Créer le trigger pour traiter automatiquement les gains de parrainage
DROP TRIGGER IF EXISTS trigger_process_referral_earnings ON public.tontines;
CREATE TRIGGER trigger_process_referral_earnings
  AFTER UPDATE ON public.tontines
  FOR EACH ROW
  EXECUTE FUNCTION process_referral_earnings_on_completion();

-- Politique RLS pour les nouvelles tables
ALTER TABLE public.referral_earnings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.connection_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tontine_history ENABLE ROW LEVEL SECURITY;

-- Politiques pour referral_earnings
CREATE POLICY "Users can view their own referral earnings" ON public.referral_earnings
  FOR SELECT USING (auth.uid() = referrer_id OR auth.uid() = referee_id);

-- Politiques pour connection_history
CREATE POLICY "Users can view their own connection history" ON public.connection_history
  FOR SELECT USING (auth.uid() = user_id);

-- Politiques pour tontine_history
CREATE POLICY "Users can view history of their tontines" ON public.tontine_history
  FOR SELECT USING (
    auth.uid() = user_id OR 
    EXISTS (
      SELECT 1 FROM public.tontines t 
      WHERE t.id = tontine_id AND t.creator_id = auth.uid()
    ) OR
    EXISTS (
      SELECT 1 FROM public.tontine_members tm 
      WHERE tm.tontine_id = tontine_id AND tm.user_id = auth.uid()
    )
  );

-- Fonction pour enregistrer l'historique des connexions
CREATE OR REPLACE FUNCTION log_user_connection()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.connection_history (user_id, connected_at)
  VALUES (NEW.id, NOW());
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger pour enregistrer les connexions (sur auth.users last_sign_in_at)
-- Note: Ce trigger peut nécessiter des permissions spéciales sur auth.users

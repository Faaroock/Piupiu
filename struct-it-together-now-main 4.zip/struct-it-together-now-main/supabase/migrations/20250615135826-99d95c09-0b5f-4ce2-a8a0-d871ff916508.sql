
-- First, drop existing RLS policies on messages table
DROP POLICY IF EXISTS "Users can view their messages" ON public.messages;
DROP POLICY IF EXISTS "Users can send messages" ON public.messages;

-- Create table for conversations
CREATE TABLE IF NOT EXISTS public.conversations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type TEXT NOT NULL CHECK (type IN ('private', 'tontine_group')),
  name TEXT,
  tontine_id UUID REFERENCES public.tontines(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create table for conversation participants
CREATE TABLE IF NOT EXISTS public.conversation_participants (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  conversation_id UUID REFERENCES public.conversations(id) ON DELETE CASCADE NOT NULL,
  user_id UUID NOT NULL,
  joined_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  left_at TIMESTAMP WITH TIME ZONE,
  last_read_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Now we can safely modify the messages table
ALTER TABLE public.messages 
ADD COLUMN IF NOT EXISTS conversation_id UUID REFERENCES public.conversations(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS sender_id UUID;

-- Update sender_id with values from from_user_id for existing records
UPDATE public.messages SET sender_id = from_user_id WHERE sender_id IS NULL;

-- Make sender_id NOT NULL after populating it
ALTER TABLE public.messages ALTER COLUMN sender_id SET NOT NULL;

-- Now drop the old columns
ALTER TABLE public.messages 
DROP COLUMN IF EXISTS from_user_id CASCADE,
DROP COLUMN IF EXISTS to_user_id CASCADE;

-- Add Row Level Security (RLS) to conversations
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

-- Policy for conversations - users can see conversations they participate in
CREATE POLICY "Users can view their conversations" 
  ON public.conversations 
  FOR SELECT 
  USING (
    id IN (
      SELECT conversation_id 
      FROM public.conversation_participants 
      WHERE user_id = auth.uid() AND left_at IS NULL
    )
  );

-- Policy for conversation participants
ALTER TABLE public.conversation_participants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view conversation participants" 
  ON public.conversation_participants 
  FOR SELECT 
  USING (
    conversation_id IN (
      SELECT conversation_id 
      FROM public.conversation_participants 
      WHERE user_id = auth.uid() AND left_at IS NULL
    )
  );

-- Create new messages policies
CREATE POLICY "Users can view messages in their conversations" 
  ON public.messages 
  FOR SELECT 
  USING (
    conversation_id IN (
      SELECT conversation_id 
      FROM public.conversation_participants 
      WHERE user_id = auth.uid() AND left_at IS NULL
    )
  );

CREATE POLICY "Users can send messages to their conversations" 
  ON public.messages 
  FOR INSERT 
  WITH CHECK (
    sender_id = auth.uid() AND
    conversation_id IN (
      SELECT conversation_id 
      FROM public.conversation_participants 
      WHERE user_id = auth.uid() AND left_at IS NULL
    )
  );

-- Function to create tontine group conversation when a tontine is created
CREATE OR REPLACE FUNCTION create_tontine_group_conversation()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.conversations (type, name, tontine_id)
  VALUES ('tontine_group', 'Groupe - ' || NEW.name, NEW.id);
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to automatically create group conversation for new tontines
DROP TRIGGER IF EXISTS on_tontine_created ON public.tontines;
CREATE TRIGGER on_tontine_created
  AFTER INSERT ON public.tontines
  FOR EACH ROW EXECUTE FUNCTION create_tontine_group_conversation();

-- Function to add user to tontine group conversation when they join
CREATE OR REPLACE FUNCTION add_user_to_tontine_conversation()
RETURNS TRIGGER AS $$
DECLARE
  conversation_uuid UUID;
BEGIN
  -- Find the conversation for this tontine
  SELECT id INTO conversation_uuid
  FROM public.conversations
  WHERE tontine_id = NEW.tontine_id AND type = 'tontine_group';
  
  -- Add user to the conversation
  IF conversation_uuid IS NOT NULL THEN
    INSERT INTO public.conversation_participants (conversation_id, user_id)
    VALUES (conversation_uuid, NEW.user_id)
    ON CONFLICT DO NOTHING;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to add users to group conversation when they join a tontine
DROP TRIGGER IF EXISTS on_tontine_member_joined ON public.tontine_members;
CREATE TRIGGER on_tontine_member_joined
  AFTER INSERT ON public.tontine_members
  FOR EACH ROW EXECUTE FUNCTION add_user_to_tontine_conversation();

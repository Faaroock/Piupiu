
-- Vérifier et corriger la table des notifications
-- D'abord, supprimer la contrainte problématique si elle existe
ALTER TABLE public.notifications 
DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;

-- Recréer la contrainte correctement pour référencer auth.users
ALTER TABLE public.notifications 
ADD CONSTRAINT notifications_user_id_fkey 
FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;

-- Supprimer le trigger existant qui cause le problème
DROP TRIGGER IF EXISTS send_welcome_notification_trigger ON public.profiles;

-- Supprimer la fonction existante
DROP FUNCTION IF EXISTS public.send_welcome_notification();

-- Recréer une fonction plus sûre pour les notifications de bienvenue
CREATE OR REPLACE FUNCTION public.safe_send_welcome_notification()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Insérer la notification seulement si l'utilisateur existe dans auth.users
  INSERT INTO public.notifications (
    user_id,
    title,
    message,
    notification_type
  ) 
  SELECT 
    NEW.user_id,
    'Bienvenue sur NONRU !',
    'Félicitations ! Votre compte a été créé avec succès. Explorez nos tontines et commencez à épargner dès maintenant.',
    'system'
  WHERE EXISTS (
    SELECT 1 FROM auth.users WHERE id = NEW.user_id
  );
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- En cas d'erreur, on continue sans bloquer l'inscription
    RAISE WARNING 'Erreur lors de la création de la notification de bienvenue: %', SQLERRM;
    RETURN NEW;
END;
$$;

-- Recréer le trigger avec la nouvelle fonction
CREATE TRIGGER safe_welcome_notification_trigger
  AFTER INSERT ON public.profiles
  FOR EACH ROW 
  EXECUTE FUNCTION public.safe_send_welcome_notification();

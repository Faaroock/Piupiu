
-- Vérifier si l'enum user_role existe déjà et l'étendre si nécessaire
DO $$
BEGIN
    -- Ajouter 'user' à l'enum s'il n'existe pas déjà
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'user' AND enumtypid = (SELECT oid FROM pg_type WHERE typname = 'user_role')) THEN
        ALTER TYPE public.user_role ADD VALUE 'user';
    END IF;
END$$;

-- Créer la table des logs d'activité admin si elle n'existe pas
CREATE TABLE IF NOT EXISTS public.admin_activity_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_user_id UUID NOT NULL REFERENCES auth.users(id),
  target_user_id UUID REFERENCES auth.users(id),
  action TEXT NOT NULL,
  details JSONB,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Activer RLS sur la table des logs si elle n'est pas déjà activée
ALTER TABLE public.admin_activity_logs ENABLE ROW LEVEL SECURITY;

-- Vérifier et créer les politiques RLS pour user_roles si elles n'existent pas
DO $$
BEGIN
    -- Politique pour que les admins puissent voir tous les rôles
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'user_roles' AND policyname = 'Admins can view all user roles') THEN
        CREATE POLICY "Admins can view all user roles"
          ON public.user_roles
          FOR SELECT
          TO authenticated
          USING (public.has_permission_level(auth.uid(), 'admin'));
    END IF;

    -- Politique pour que les super admins puissent gérer tous les rôles
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'user_roles' AND policyname = 'Super admins can manage all roles') THEN
        CREATE POLICY "Super admins can manage all roles"
          ON public.user_roles
          FOR ALL
          TO authenticated
          USING (public.has_role(auth.uid(), 'super_admin'));
    END IF;
END$$;

-- Créer les politiques RLS pour admin_activity_logs
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'admin_activity_logs' AND policyname = 'Admins can view activity logs') THEN
        CREATE POLICY "Admins can view activity logs"
          ON public.admin_activity_logs
          FOR SELECT
          TO authenticated
          USING (public.has_permission_level(auth.uid(), 'admin'));
    END IF;

    IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'admin_activity_logs' AND policyname = 'Admins can create activity logs') THEN
        CREATE POLICY "Admins can create activity logs"
          ON public.admin_activity_logs
          FOR INSERT
          TO authenticated
          WITH CHECK (auth.uid() = admin_user_id AND public.has_permission_level(auth.uid(), 'admin'));
    END IF;
END$$;

-- Insérer le rôle super_admin pour faaroockt@gmail.com
INSERT INTO public.user_roles (user_id, role, assigned_at)
SELECT id, 'super_admin', now()
FROM auth.users
WHERE email = 'faaroockt@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;

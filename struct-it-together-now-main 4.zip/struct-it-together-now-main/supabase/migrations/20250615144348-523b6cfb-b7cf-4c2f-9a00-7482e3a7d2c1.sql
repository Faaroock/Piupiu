
-- Créer la table pour les fonds gelés
CREATE TABLE IF NOT EXISTS public.frozen_funds (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  amount NUMERIC NOT NULL CHECK (amount > 0),
  reason TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  is_active BOOLEAN NOT NULL DEFAULT true
);

-- Activer RLS sur la table frozen_funds
ALTER TABLE public.frozen_funds ENABLE ROW LEVEL SECURITY;

-- Politique pour que les utilisateurs voient seulement leurs propres fonds gelés
CREATE POLICY "Users can view their own frozen funds" 
  ON public.frozen_funds 
  FOR SELECT 
  USING (user_id = (SELECT id FROM profiles WHERE user_id = auth.uid()));

-- Politique pour que les utilisateurs créent leurs propres fonds gelés
CREATE POLICY "Users can create their own frozen funds" 
  ON public.frozen_funds 
  FOR INSERT 
  WITH CHECK (user_id = (SELECT id FROM profiles WHERE user_id = auth.uid()));

-- Politique pour que les utilisateurs modifient leurs propres fonds gelés
CREATE POLICY "Users can update their own frozen funds" 
  ON public.frozen_funds 
  FOR UPDATE 
  USING (user_id = (SELECT id FROM profiles WHERE user_id = auth.uid()));

-- Politique pour que les utilisateurs suppriment leurs propres fonds gelés
CREATE POLICY "Users can delete their own frozen funds" 
  ON public.frozen_funds 
  FOR DELETE 
  USING (user_id = (SELECT id FROM profiles WHERE user_id = auth.uid()));

-- Fonction pour calculer le total des fonds gelés pour un utilisateur
CREATE OR REPLACE FUNCTION get_user_frozen_balance(profile_user_id UUID)
RETURNS NUMERIC
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT COALESCE(SUM(amount), 0)
  FROM public.frozen_funds
  WHERE user_id = profile_user_id AND is_active = true;
$$;

-- Fonction pour calculer le solde disponible (balance - fonds gelés)
CREATE OR REPLACE FUNCTION get_user_available_balance(profile_user_id UUID)
RETURNS NUMERIC
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT COALESCE(
    (SELECT balance FROM public.profiles WHERE id = profile_user_id) - 
    get_user_frozen_balance(profile_user_id), 
    0
  );
$$;

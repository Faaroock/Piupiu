
-- Table for referrals
CREATE TABLE public.referrals (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  referrer_id uuid NOT NULL,
  referee_id uuid NOT NULL,
  referral_code text NOT NULL UNIQUE,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  status text NOT NULL DEFAULT 'pending',
  CONSTRAINT referrals_referrer_id_fkey FOREIGN KEY (referrer_id) REFERENCES auth.users(id),
  CONSTRAINT referrals_referee_id_fkey FOREIGN KEY (referee_id) REFERENCES auth.users(id)
);

-- Table for referral earnings
CREATE TABLE public.referral_earnings (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  referrer_id uuid NOT NULL,
  referee_id uuid NOT NULL,
  tontine_id uuid NOT NULL,
  total_contributed numeric NOT NULL,
  earning_amount numeric NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  is_paid boolean DEFAULT false,
  CONSTRAINT referral_earnings_referrer_id_fkey FOREIGN KEY (referrer_id) REFERENCES auth.users(id),
  CONSTRAINT referral_earnings_referee_id_fkey FOREIGN KEY (referee_id) REFERENCES auth.users(id),
  CONSTRAINT referral_earnings_tontine_id_fkey FOREIGN KEY (tontine_id) REFERENCES public.tontines(id)
);

-- Add referral code to profiles table
ALTER TABLE public.profiles ADD COLUMN referral_code text UNIQUE DEFAULT (substring(encode(gen_random_bytes(6), 'base64') from 1 for 8));
ALTER TABLE public.profiles ADD COLUMN referred_by uuid REFERENCES auth.users(id);
ALTER TABLE public.profiles ADD COLUMN referral_earnings numeric DEFAULT 0;

-- Update user_badges table with new badge types
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'badge_type') THEN
    CREATE TYPE badge_type AS ENUM (
      'petit_cotiseur',
      'cotiseur_serieux', 
      'gros_poisson',
      'turbo_cotiseur',
      'discipline',
      'machine_guerre',
      'loyal',
      'secours_fraternel',
      'main_tendue',
      'mentor',
      'debutant',
      'confirme',
      'expert',
      'legende_nonru',
      'sans_tache',
      'confiance_totale',
      'invisible_fiable',
      'parrain_officiel',
      'tete_reseau',
      'ambassadeur_nonru'
    );
  END IF;
END $$;

-- Enable RLS on new tables
ALTER TABLE public.referrals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_earnings ENABLE ROW LEVEL SECURITY;

-- RLS policies for referrals
CREATE POLICY "Users can view their own referrals" ON public.referrals
  FOR SELECT USING (auth.uid() = referrer_id OR auth.uid() = referee_id);

CREATE POLICY "Users can create referrals" ON public.referrals
  FOR INSERT WITH CHECK (auth.uid() = referrer_id);

-- RLS policies for referral earnings
CREATE POLICY "Users can view their own earnings" ON public.referral_earnings
  FOR SELECT USING (auth.uid() = referrer_id);

CREATE POLICY "System can create earnings" ON public.referral_earnings
  FOR INSERT WITH CHECK (true);

-- Function to generate unique referral code
CREATE OR REPLACE FUNCTION generate_referral_code()
RETURNS text AS $$
DECLARE
  new_code text;
BEGIN
  LOOP
    new_code := upper(substring(encode(gen_random_bytes(6), 'base64') from 1 for 8));
    new_code := replace(new_code, '+', '');
    new_code := replace(new_code, '/', '');
    new_code := replace(new_code, '=', '');
    
    IF NOT EXISTS (SELECT 1 FROM profiles WHERE referral_code = new_code) THEN
      EXIT;
    END IF;
  END LOOP;
  
  RETURN new_code;
END;
$$ LANGUAGE plpgsql;

-- Function to process referral earnings when tontine completes
CREATE OR REPLACE FUNCTION process_referral_earnings(tontine_uuid uuid)
RETURNS void AS $$
DECLARE
  tontine_data record;
  total_contributed_amount numeric;
  earning_amount numeric;
  referrer_profile_id uuid;
BEGIN
  -- Get tontine data
  SELECT * INTO tontine_data FROM tontines WHERE id = tontine_uuid AND status = 'completed';
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Calculate total contributed amount
  SELECT COALESCE(SUM(amount_paid), 0) INTO total_contributed_amount
  FROM tontine_payments 
  WHERE tontine_id = tontine_uuid AND is_paid = true;
  
  -- Check if creator has a referrer
  SELECT referred_by INTO referrer_profile_id
  FROM profiles 
  WHERE user_id = tontine_data.creator_id;
  
  IF referrer_profile_id IS NOT NULL THEN
    -- Calculate 1% earnings
    earning_amount := total_contributed_amount * 0.01;
    
    -- Create referral earning record
    INSERT INTO referral_earnings (
      referrer_id, 
      referee_id, 
      tontine_id, 
      total_contributed, 
      earning_amount
    ) VALUES (
      referrer_profile_id,
      tontine_data.creator_id,
      tontine_uuid,
      total_contributed_amount,
      earning_amount
    );
    
    -- Update referrer's earnings balance
    UPDATE profiles 
    SET referral_earnings = COALESCE(referral_earnings, 0) + earning_amount
    WHERE user_id = referrer_profile_id;
  END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

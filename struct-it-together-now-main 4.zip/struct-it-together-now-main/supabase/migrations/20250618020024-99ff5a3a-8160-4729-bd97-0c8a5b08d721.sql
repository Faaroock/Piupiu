
-- Première étape: Renommer toutes les tables
ALTER TABLE tontines RENAME TO epargnes;
ALTER TABLE tontine_members RENAME TO epargne_members;
ALTER TABLE tontine_payments RENAME TO epargne_payments;
ALTER TABLE tontine_requests RENAME TO epargne_requests;
ALTER TABLE tontine_history RENAME TO epargne_history;

-- Deuxième étape: Renommer les colonnes qui référencent tontine_id
ALTER TABLE epargne_members RENAME COLUMN tontine_id TO epargne_id;
ALTER TABLE epargne_payments RENAME COLUMN tontine_id TO epargne_id;
ALTER TABLE epargne_requests RENAME COLUMN tontine_id TO epargne_id;
ALTER TABLE epargne_history RENAME COLUMN tontine_id TO epargne_id;
ALTER TABLE conversations RENAME COLUMN tontine_id TO epargne_id;
ALTER TABLE transactions RENAME COLUMN tontine_id TO epargne_id;
ALTER TABLE referral_earnings RENAME COLUMN tontine_id TO epargne_id;

-- Troisième étape: Ajouter le champ type pour différencier épargne personnelle et collective
ALTER TABLE epargnes ADD COLUMN IF NOT EXISTS type TEXT DEFAULT 'personnelle' CHECK (type IN ('personnelle', 'collective'));

-- Quatrième étape: Supprimer les triggers existants avant de modifier les fonctions
DROP TRIGGER IF EXISTS trigger_update_completion ON epargne_payments;
DROP TRIGGER IF EXISTS on_epargne_created ON epargnes;
DROP TRIGGER IF EXISTS on_epargne_member_added ON epargne_members;
DROP TRIGGER IF EXISTS on_epargne_completed ON epargnes;

-- Cinquième étape: Supprimer les anciennes fonctions
DROP FUNCTION IF EXISTS update_tontine_completion() CASCADE;
DROP FUNCTION IF EXISTS process_referral_earnings(uuid) CASCADE;
DROP FUNCTION IF EXISTS create_tontine_group_conversation() CASCADE;
DROP FUNCTION IF EXISTS add_user_to_tontine_conversation() CASCADE;
DROP FUNCTION IF EXISTS process_referral_earnings_on_completion() CASCADE;

-- Sixième étape: Créer les nouvelles fonctions avec les bons noms de tables
CREATE OR REPLACE FUNCTION public.update_epargne_completion()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  -- Calculer le pourcentage de complétion basé sur les paiements
  UPDATE epargnes 
  SET completion_percentage = (
    SELECT COALESCE(
      (COUNT(CASE WHEN ep.is_paid = true THEN 1 END) * 100.0) / NULLIF(COUNT(*), 0),
      0
    )
    FROM epargne_payments ep 
    WHERE ep.epargne_id = NEW.epargne_id
  )
  WHERE id = NEW.epargne_id;
  
  -- Marquer comme complétée si 100%
  UPDATE epargnes 
  SET 
    status = 'completed',
    completed_at = now()
  WHERE id = NEW.epargne_id 
  AND completion_percentage >= 100 
  AND status != 'completed';
  
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.process_referral_earnings(epargne_uuid uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  epargne_data record;
  total_contributed_amount numeric;
  earning_amount numeric;
  referrer_profile_id uuid;
BEGIN
  -- Get epargne data
  SELECT * INTO epargne_data FROM epargnes WHERE id = epargne_uuid AND status = 'completed';
  
  IF NOT FOUND THEN
    RETURN;
  END IF;
  
  -- Calculate total contributed amount
  SELECT COALESCE(SUM(amount_paid), 0) INTO total_contributed_amount
  FROM epargne_payments 
  WHERE epargne_id = epargne_uuid AND is_paid = true;
  
  -- Check if creator has a referrer
  SELECT referred_by INTO referrer_profile_id
  FROM profiles 
  WHERE user_id = epargne_data.creator_id;
  
  IF referrer_profile_id IS NOT NULL THEN
    -- Calculate 1% earnings
    earning_amount := total_contributed_amount * 0.01;
    
    -- Create referral earning record
    INSERT INTO referral_earnings (
      referrer_id, 
      referee_id, 
      epargne_id, 
      total_contributed, 
      earning_amount
    ) VALUES (
      referrer_profile_id,
      epargne_data.creator_id,
      epargne_uuid,
      total_contributed_amount,
      earning_amount
    );
    
    -- Update referrer's earnings balance
    UPDATE profiles 
    SET referral_earnings = COALESCE(referral_earnings, 0) + earning_amount
    WHERE user_id = referrer_profile_id;
  END IF;
END;
$function$;

CREATE OR REPLACE FUNCTION public.create_epargne_group_conversation()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  INSERT INTO public.conversations (type, name, epargne_id)
  VALUES ('epargne_group', 'Groupe - ' || NEW.name, NEW.id);
  
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.add_user_to_epargne_conversation()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
DECLARE
  conversation_uuid UUID;
BEGIN
  -- Find the conversation for this epargne
  SELECT id INTO conversation_uuid
  FROM public.conversations
  WHERE epargne_id = NEW.epargne_id AND type = 'epargne_group';
  
  -- Add user to the conversation
  IF conversation_uuid IS NOT NULL THEN
    INSERT INTO public.conversation_participants (conversation_id, user_id)
    VALUES (conversation_uuid, NEW.user_id)
    ON CONFLICT DO NOTHING;
  END IF;
  
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.process_referral_earnings_on_completion()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
  -- Si l'épargne vient d'être marquée comme complétée
  IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
    -- Appeler la fonction existante pour traiter les gains
    PERFORM process_referral_earnings(NEW.id);
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Septième étape: Recréer les triggers avec les nouvelles fonctions
CREATE TRIGGER trigger_update_completion
  AFTER UPDATE ON epargne_payments
  FOR EACH ROW
  WHEN (NEW.is_paid = true AND OLD.is_paid = false)
  EXECUTE FUNCTION update_epargne_completion();

CREATE TRIGGER on_epargne_created
  AFTER INSERT ON epargnes
  FOR EACH ROW
  EXECUTE FUNCTION create_epargne_group_conversation();

CREATE TRIGGER on_epargne_member_added
  AFTER INSERT ON epargne_members
  FOR EACH ROW
  EXECUTE FUNCTION add_user_to_epargne_conversation();

CREATE TRIGGER on_epargne_completed
  AFTER UPDATE ON epargnes
  FOR EACH ROW
  EXECUTE FUNCTION process_referral_earnings_on_completion();

-- Huitième étape: Mettre à jour les types ENUM pour les conversations
UPDATE conversations SET type = 'epargne_group' WHERE type = 'tontine_group';

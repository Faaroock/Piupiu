
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.0';
import { Resend } from "npm:resend@4.0.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const resend = new Resend(Deno.env.get('RESEND_API_KEY'));

interface EmailRequest {
  to: string;
  firstName: string;
  type: 'welcome' | 'email_confirmation' | 'password_reset';
  confirmationUrl?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { to, firstName, type, confirmationUrl }: EmailRequest = await req.json();

    let emailData;

    switch (type) {
      case 'welcome':
        emailData = {
          from: 'NONRU <noreply@nonru.com>',
          to: [to],
          subject: '🎉 Bienvenue sur NONRU !',
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
              <div style="text-align: center; margin-bottom: 30px;">
                <div style="background-color: #fab005; width: 80px; height: 80px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 36px;">💰</div>
                <h1 style="color: #333; margin: 20px 0;">Bienvenue sur NONRU !</h1>
              </div>
              
              <div style="background-color: #f8f9fa; padding: 25px; border-radius: 10px; margin: 20px 0;">
                <h2 style="color: #00B894; margin-top: 0;">Bonjour ${firstName} ! 👋</h2>
                <p style="color: #666; line-height: 1.6;">
                  Félicitations ! Votre compte NONRU a été créé avec succès. Vous rejoignez une communauté qui révolutionne l'épargne collaborative.
                </p>
                
                <h3 style="color: #333;">🚀 Prochaines étapes :</h3>
                <ul style="color: #666; line-height: 1.8;">
                  <li>✅ Confirmez votre adresse email (si ce n'est pas encore fait)</li>
                  <li>🔍 Explorez nos tontines disponibles</li>
                  <li>💫 Créez votre première tontine</li>
                  <li>👥 Invitez vos proches à vous rejoindre</li>
                </ul>
              </div>
              
              <div style="text-align: center; margin: 30px 0;">
                <a href="${Deno.env.get('SUPABASE_URL')?.replace('//', '//mjvznxmerkckdskcimjc.')}/dashboard" 
                   style="background-color: #00B894; color: white; padding: 12px 30px; border-radius: 6px; text-decoration: none; display: inline-block; font-weight: bold;">
                  Accéder à mon dashboard
                </a>
              </div>
              
              <div style="background-color: #e3f2fd; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #1976d2; margin-top: 0;">💡 Astuce du jour</h3>
                <p style="color: #666; margin-bottom: 0;">
                  Commencez par une petite tontine avec vos proches pour vous familiariser avec le système. C'est le meilleur moyen d'apprendre !
                </p>
              </div>
              
              <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee;">
                <p style="color: #999; font-size: 14px;">
                  Cet email a été envoyé par NONRU.<br>
                  Si vous avez des questions, n'hésitez pas à nous contacter.
                </p>
              </div>
            </div>
          `,
        };
        break;

      case 'email_confirmation':
        emailData = {
          from: 'NONRU <noreply@nonru.com>',
          to: [to],
          subject: '📧 Confirmez votre adresse email - NONRU',
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
              <div style="text-align: center; margin-bottom: 30px;">
                <div style="background-color: #fab005; width: 80px; height: 80px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-size: 36px;">💰</div>
                <h1 style="color: #333; margin: 20px 0;">Confirmez votre email</h1>
              </div>
              
              <div style="background-color: #f8f9fa; padding: 25px; border-radius: 10px;">
                <h2 style="color: #00B894; margin-top: 0;">Bonjour ${firstName} !</h2>
                <p style="color: #666; line-height: 1.6;">
                  Pour finaliser votre inscription sur NONRU et accéder à toutes les fonctionnalités, veuillez confirmer votre adresse email en cliquant sur le bouton ci-dessous.
                </p>
                
                <div style="text-align: center; margin: 30px 0;">
                  <a href="${confirmationUrl}" 
                     style="background-color: #00B894; color: white; padding: 15px 30px; border-radius: 6px; text-decoration: none; display: inline-block; font-weight: bold;">
                    ✅ Confirmer mon email
                  </a>
                </div>
                
                <p style="color: #666; font-size: 14px; margin-top: 20px;">
                  Si le bouton ne fonctionne pas, copiez et collez ce lien dans votre navigateur :<br>
                  <a href="${confirmationUrl}" style="color: #00B894; word-break: break-all;">${confirmationUrl}</a>
                </p>
              </div>
              
              <div style="background-color: #fff3cd; padding: 15px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #ffc107;">
                <p style="color: #856404; margin: 0; font-size: 14px;">
                  ⚡ Ce lien expirera dans 24 heures pour votre sécurité.
                </p>
              </div>
              
              <div style="text-align: center; margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee;">
                <p style="color: #999; font-size: 14px;">
                  Si vous n'avez pas créé de compte NONRU, vous pouvez ignorer cet email.
                </p>
              </div>
            </div>
          `,
        };
        break;

      default:
        throw new Error('Type d\'email non supporté');
    }

    const result = await resend.emails.send(emailData);
    console.log('Email envoyé avec succès:', result);

    return new Response(
      JSON.stringify({ success: true, messageId: result.data?.id }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );

  } catch (error: any) {
    console.error('Erreur lors de l\'envoi de l\'email:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Erreur lors de l\'envoi de l\'email',
        details: error 
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});

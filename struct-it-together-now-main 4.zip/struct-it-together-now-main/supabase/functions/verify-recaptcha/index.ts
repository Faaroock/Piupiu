
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface RecaptchaRequest {
  token: string;
}

interface RecaptchaResponse {
  success: boolean;
  challenge_ts?: string;
  hostname?: string;
  "error-codes"?: string[];
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { token }: RecaptchaRequest = await req.json();

    if (!token) {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: "Merci de cocher la case pour confirmer que vous n'êtes pas un robot." 
        }),
        {
          status: 400,
          headers: {
            "Content-Type": "application/json",
            ...corsHeaders,
          },
        }
      );
    }

    // Utiliser votre vraie clé secrète de production
    const recaptchaSecretKey = "6LdR4mErAAAAAJFdzvRTcapUQvAD50SoywM2TkQl";
    
    console.log("Vérification reCAPTCHA v2 avec la clé secrète de production pour nonru.netlify.app");

    // Vérifier le token auprès de Google pour reCAPTCHA v2
    const verificationUrl = "https://www.google.com/recaptcha/api/siteverify";
    const formData = new FormData();
    formData.append("secret", recaptchaSecretKey);
    formData.append("response", token);

    console.log("Envoi de la requête de vérification à Google...");
    
    const verificationResponse = await fetch(verificationUrl, {
      method: "POST",
      body: formData,
    });

    const verificationData: RecaptchaResponse = await verificationResponse.json();

    console.log("Résultat de vérification reCAPTCHA v2:", JSON.stringify(verificationData, null, 2));

    if (verificationData.success) {
      console.log("reCAPTCHA v2 vérifié avec succès pour le domaine:", verificationData.hostname);
      return new Response(
        JSON.stringify({ 
          success: true,
          message: "reCAPTCHA v2 vérifié avec succès",
          hostname: verificationData.hostname
        }),
        {
          status: 200,
          headers: {
            "Content-Type": "application/json",
            ...corsHeaders,
          },
        }
      );
    } else {
      const errorCodes = verificationData["error-codes"] || [];
      console.error("Échec de la vérification reCAPTCHA. Codes d'erreur:", errorCodes);
      
      let errorMessage = "Vérification échouée, merci de cocher la case pour confirmer que vous n'êtes pas un robot.";
      
      // Messages d'erreur spécifiques et clairs
      if (errorCodes.includes("missing-input-response")) {
        errorMessage = "Merci de cocher la case pour confirmer que vous n'êtes pas un robot.";
      } else if (errorCodes.includes("invalid-input-response")) {
        errorMessage = "Vérification échouée, merci de cocher la case pour confirmer que vous n'êtes pas un robot.";
      } else if (errorCodes.includes("timeout-or-duplicate")) {
        errorMessage = "La vérification a expiré, veuillez recommencer.";
      } else if (errorCodes.includes("bad-request")) {
        errorMessage = "Erreur de configuration du reCAPTCHA.";
      } else if (errorCodes.includes("invalid-input-secret")) {
        errorMessage = "Configuration serveur invalide.";
      }

      return new Response(
        JSON.stringify({ 
          success: false, 
          error: errorMessage,
          errorCodes: errorCodes,
          hostname: verificationData.hostname
        }),
        {
          status: 400,
          headers: {
            "Content-Type": "application/json",
            ...corsHeaders,
          },
        }
      );
    }

  } catch (error: any) {
    console.error("Erreur dans verify-recaptcha:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: "Erreur serveur lors de la vérification" 
      }),
      {
        status: 500,
        headers: { 
          "Content-Type": "application/json", 
          ...corsHeaders 
        },
      }
    );
  }
};

serve(handler);

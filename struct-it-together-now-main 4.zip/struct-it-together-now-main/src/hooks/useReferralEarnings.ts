
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface ReferralEarning {
  id: string;
  earning_amount: number;
  total_contributed: number;
  is_paid: boolean;
  created_at: string;
  epargne_id: string;
}

export const useReferralEarnings = () => {
  const { user } = useAuth();
  const [earnings, setEarnings] = useState<ReferralEarning[]>([]);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchEarnings = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('referral_earnings')
        .select('*')
        .eq('referrer_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setEarnings(data || []);
      
      // Calculer le total des gains
      const total = (data || []).reduce((sum, earning) => sum + earning.earning_amount, 0);
      setTotalEarnings(total);

    } catch (error) {
      console.error('Erreur récupération gains parrainage:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEarnings();
  }, [user?.id]);

  return {
    earnings,
    totalEarnings,
    loading,
    refetch: fetchEarnings
  };
};

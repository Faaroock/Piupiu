import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface Message {
  id: string;
  content: string;
  sender_id: string;
  conversation_id: string;
  message_type: 'text' | 'audio' | 'image';
  file_url?: string;
  is_read: boolean;
  created_at: string;
  sender_profile?: {
    first_name: string;
    last_name: string;
    avatar_url?: string;
  };
}

export interface Conversation {
  id: string;
  type: 'private' | 'tontine_group';
  name?: string;
  tontine_id?: string;
  created_at: string;
  updated_at: string;
  participants?: ConversationParticipant[];
  last_message?: Message;
  unread_count?: number;
}

export interface ConversationParticipant {
  id: string;
  conversation_id: string;
  user_id: string;
  joined_at: string;
  left_at?: string;
  last_read_at?: string;
  profile?: {
    first_name: string;
    last_name: string;
    avatar_url?: string;
  };
}

export const useMessages = () => {
  const { user } = useAuth();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentConversationId, setCurrentConversationId] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Fetch user's conversations
  const fetchConversations = async () => {
    if (!user?.id) return;

    try {
      setIsLoading(true);
      
      const { data: conversationsData, error } = await supabase
        .from('conversations')
        .select(`
          *,
          conversation_participants!inner(
            *,
            profiles!conversation_participants_user_id_fkey(first_name, last_name, avatar_url)
          ),
          tontines(name)
        `)
        .order('updated_at', { ascending: false });

      if (error) {
        console.error('Error fetching conversations:', error);
        return;
      }

      // Get last message for each conversation
      const conversationsWithLastMessage = await Promise.all(
        (conversationsData || []).map(async (conv: any) => {
          const { data: lastMessage } = await supabase
            .from('messages')
            .select(`
              id,
              content,
              sender_id,
              conversation_id,
              message_type,
              file_url,
              is_read,
              created_at
            `)
            .eq('conversation_id', conv.id)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle();

          // Get sender profile separately if message exists
          let senderProfile = null;
          if (lastMessage) {
            const { data: profileData } = await supabase
              .from('profiles')
              .select('first_name, last_name, avatar_url')
              .eq('id', lastMessage.sender_id)
              .maybeSingle();
            
            if (profileData) {
              senderProfile = {
                first_name: profileData.first_name || '',
                last_name: profileData.last_name || '',
                avatar_url: profileData.avatar_url || undefined
              };
            }
          }

          // Count unread messages
          const { count: unreadCount } = await supabase
            .from('messages')
            .select('*', { count: 'exact', head: true })
            .eq('conversation_id', conv.id)
            .eq('is_read', false)
            .neq('sender_id', user.id);

          // Transform the data to match our interfaces
          const transformedConv: Conversation = {
            id: conv.id,
            type: conv.type as 'private' | 'tontine_group',
            name: conv.name,
            tontine_id: conv.tontine_id,
            created_at: conv.created_at,
            updated_at: conv.updated_at,
            participants: conv.conversation_participants?.map((p: any) => ({
              id: p.id,
              conversation_id: p.conversation_id,
              user_id: p.user_id,
              joined_at: p.joined_at,
              left_at: p.left_at,
              last_read_at: p.last_read_at,
              profile: p.profiles ? {
                first_name: p.profiles.first_name || '',
                last_name: p.profiles.last_name || '',
                avatar_url: p.profiles.avatar_url || undefined
              } : undefined
            })),
            last_message: lastMessage ? {
              id: lastMessage.id,
              content: lastMessage.content || '',
              sender_id: lastMessage.sender_id,
              conversation_id: lastMessage.conversation_id || '',
              message_type: lastMessage.message_type || 'text',
              file_url: lastMessage.file_url || undefined,
              is_read: lastMessage.is_read || false,
              created_at: lastMessage.created_at || '',
              sender_profile: senderProfile
            } : undefined,
            unread_count: unreadCount || 0
          };

          return transformedConv;
        })
      );

      setConversations(conversationsWithLastMessage);
    } catch (error) {
      console.error('Error fetching conversations:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch messages for a specific conversation
  const fetchMessages = async (conversationId: string) => {
    if (!conversationId) return;

    try {
      setIsLoading(true);
      
      const { data, error } = await supabase
        .from('messages')
        .select(`
          id,
          content,
          sender_id,
          conversation_id,
          message_type,
          file_url,
          is_read,
          created_at
        `)
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error fetching messages:', error);
        return;
      }

      // Get sender profiles separately
      const transformedMessages: Message[] = await Promise.all(
        (data || []).map(async (msg: any) => {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('first_name, last_name, avatar_url')
            .eq('id', msg.sender_id)
            .maybeSingle();

          return {
            id: msg.id,
            content: msg.content || '',
            sender_id: msg.sender_id,
            conversation_id: msg.conversation_id || '',
            message_type: msg.message_type || 'text',
            file_url: msg.file_url || undefined,
            is_read: msg.is_read || false,
            created_at: msg.created_at || '',
            sender_profile: profileData ? {
              first_name: profileData.first_name || '',
              last_name: profileData.last_name || '',
              avatar_url: profileData.avatar_url || undefined
            } : undefined
          };
        })
      );

      setMessages(transformedMessages);
      setCurrentConversationId(conversationId);

      // Mark messages as read
      await markMessagesAsRead(conversationId);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Send a new message
  const sendMessage = async (conversationId: string, content: string, messageType: 'text' | 'audio' | 'image' = 'text') => {
    if (!user?.id || !content.trim()) return;

    try {
      const { data, error } = await supabase
        .from('messages')
        .insert({
          conversation_id: conversationId,
          sender_id: user.id,
          content: content.trim(),
          message_type: messageType,
          is_read: false
        })
        .select(`
          id,
          content,
          sender_id,
          conversation_id,
          message_type,
          file_url,
          is_read,
          created_at
        `)
        .single();

      if (error) {
        console.error('Error sending message:', error);
        return;
      }

      // Get sender profile separately
      const { data: profileData } = await supabase
        .from('profiles')
        .select('first_name, last_name, avatar_url')
        .eq('id', data.sender_id)
        .maybeSingle();

      const newMessage: Message = {
        id: data.id,
        content: data.content || '',
        sender_id: data.sender_id,
        conversation_id: data.conversation_id || '',
        message_type: data.message_type || 'text',
        file_url: data.file_url || undefined,
        is_read: data.is_read || false,
        created_at: data.created_at || '',
        sender_profile: profileData ? {
          first_name: profileData.first_name || '',
          last_name: profileData.last_name || '',
          avatar_url: profileData.avatar_url || undefined
        } : undefined
      };

      // Update local state if this is the current conversation
      if (conversationId === currentConversationId) {
        setMessages(prev => [...prev, newMessage]);
      }

      // Update conversation updated_at
      await supabase
        .from('conversations')
        .update({ updated_at: new Date().toISOString() })
        .eq('id', conversationId);

      // Refresh conversations to update last message
      await fetchConversations();

      return newMessage;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  };

  // Mark messages as read
  const markMessagesAsRead = async (conversationId: string) => {
    if (!user?.id) return;

    try {
      await supabase
        .from('messages')
        .update({ is_read: true })
        .eq('conversation_id', conversationId)
        .neq('sender_id', user.id)
        .eq('is_read', false);

      // Update participant's last_read_at
      await supabase
        .from('conversation_participants')
        .update({ last_read_at: new Date().toISOString() })
        .eq('conversation_id', conversationId)
        .eq('user_id', user.id);

    } catch (error) {
      console.error('Error marking messages as read:', error);
    }
  };

  // Create a private conversation
  const createPrivateConversation = async (otherUserId: string) => {
    if (!user?.id) return null;

    try {
      // Check if conversation already exists
      const { data: existingConv } = await supabase
        .from('conversation_participants')
        .select(`
          conversation_id,
          conversations!inner(type)
        `)
        .eq('user_id', user.id)
        .eq('conversations.type', 'private');

      if (existingConv) {
        for (const conv of existingConv) {
          const { data: otherParticipant } = await supabase
            .from('conversation_participants')
            .select('user_id')
            .eq('conversation_id', conv.conversation_id)
            .eq('user_id', otherUserId)
            .maybeSingle();

          if (otherParticipant) {
            return conv.conversation_id;
          }
        }
      }

      // Create new conversation
      const { data: newConv, error: convError } = await supabase
        .from('conversations')
        .insert({
          type: 'private'
        })
        .select()
        .single();

      if (convError) throw convError;

      // Add both users as participants
      const { error: participantsError } = await supabase
        .from('conversation_participants')
        .insert([
          { conversation_id: newConv.id, user_id: user.id },
          { conversation_id: newConv.id, user_id: otherUserId }
        ]);

      if (participantsError) throw participantsError;

      await fetchConversations();
      return newConv.id;
    } catch (error) {
      console.error('Error creating private conversation:', error);
      return null;
    }
  };

  // Setup real-time subscriptions
  useEffect(() => {
    if (!user?.id) return;

    const messagesChannel = supabase
      .channel('messages-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages'
        },
        (payload) => {
          const newMessage = payload.new as any;
          
          // Only update if it's for the current conversation and not sent by current user
          if (newMessage.conversation_id === currentConversationId && newMessage.sender_id !== user.id) {
            // Fetch the full message with profile
            fetchMessages(currentConversationId);
          }
          
          // Always refresh conversations for last message update
          fetchConversations();
        }
      )
      .subscribe();

    const conversationsChannel = supabase
      .channel('conversations-changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'conversations'
        },
        () => {
          fetchConversations();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(messagesChannel);
      supabase.removeChannel(conversationsChannel);
    };
  }, [user?.id, currentConversationId]);

  // Fetch conversations on mount
  useEffect(() => {
    if (user?.id) {
      fetchConversations();
    }
  }, [user?.id]);

  return {
    conversations,
    messages,
    currentConversationId,
    isLoading,
    fetchConversations,
    fetchMessages,
    sendMessage,
    createPrivateConversation,
    markMessagesAsRead
  };
};

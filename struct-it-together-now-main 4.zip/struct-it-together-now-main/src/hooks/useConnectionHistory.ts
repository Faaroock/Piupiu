
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface ConnectionRecord {
  id: string;
  ip_address: string | null;
  user_agent: string | null;
  location: string | null;
  connected_at: string;
  session_duration: string | null;
}

export const useConnectionHistory = () => {
  const { user } = useAuth();
  const [connections, setConnections] = useState<ConnectionRecord[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchConnectionHistory = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('connection_history')
        .select('*')
        .eq('user_id', user.id)
        .order('connected_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      
      // Transform the data to match our interface
      const transformedData = (data || []).map(item => ({
        id: item.id,
        ip_address: item.ip_address ? String(item.ip_address) : null,
        user_agent: item.user_agent,
        location: item.location,
        connected_at: item.connected_at || '',
        session_duration: item.session_duration ? String(item.session_duration) : null
      }));
      
      setConnections(transformedData);
    } catch (error) {
      console.error('Erreur récupération historique connexions:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchConnectionHistory();
  }, [user?.id]);

  return {
    connections,
    loading,
    refetch: fetchConnectionHistory
  };
};


import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

export interface FrozenFund {
  id: string;
  amount: number;
  reason: string;
  created_at: string;
  is_active: boolean;
}

export const useFrozenFunds = () => {
  const [frozenFunds, setFrozenFunds] = useState<FrozenFund[]>([]);
  const [totalFrozen, setTotalFrozen] = useState(0);
  const [availableBalance, setAvailableBalance] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();

  const fetchFrozenFunds = async () => {
    if (!user) return;

    try {
      setIsLoading(true);
      
      // Récupérer les fonds gelés
      const { data: funds, error: fundsError } = await supabase
        .from('frozen_funds')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (fundsError) throw fundsError;

      setFrozenFunds(funds || []);

      // Récupérer le profil utilisateur pour obtenir le solde
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('id, balance')
        .eq('user_id', user.id)
        .single();

      if (profileError) throw profileError;

      if (profile) {
        // Calculer le total gelé et le solde disponible
        const { data: frozenBalance, error: frozenError } = await supabase
          .rpc('get_user_frozen_balance', { profile_user_id: profile.id });

        const { data: available, error: availableError } = await supabase
          .rpc('get_user_available_balance', { profile_user_id: profile.id });

        if (frozenError) throw frozenError;
        if (availableError) throw availableError;

        setTotalFrozen(frozenBalance || 0);
        setAvailableBalance(available || 0);
      }
    } catch (error) {
      console.error('Erreur lors de la récupération des fonds gelés:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les fonds gelés",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const freezeFunds = async (amount: number, reason: string) => {
    if (!user) return false;

    try {
      // Récupérer l'ID du profil
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('id, balance')
        .eq('user_id', user.id)
        .single();

      if (profileError) throw profileError;

      if (!profile || profile.balance < amount) {
        toast({
          title: "Solde insuffisant",
          description: "Vous n'avez pas assez de fonds disponibles",
          variant: "destructive"
        });
        return false;
      }

      // Créer le gel de fonds
      const { error: freezeError } = await supabase
        .from('frozen_funds')
        .insert({
          user_id: profile.id,
          amount,
          reason
        });

      if (freezeError) throw freezeError;

      toast({
        title: "Fonds gelés avec succès",
        description: `${amount} F ont été gelés pour: ${reason}`
      });

      // Rafraîchir les données
      await fetchFrozenFunds();
      return true;
    } catch (error) {
      console.error('Erreur lors du gel des fonds:', error);
      toast({
        title: "Erreur",
        description: "Impossible de geler les fonds",
        variant: "destructive"
      });
      return false;
    }
  };

  const unfreezeFunds = async (fundId: string) => {
    try {
      const { error } = await supabase
        .from('frozen_funds')
        .update({ is_active: false })
        .eq('id', fundId);

      if (error) throw error;

      toast({
        title: "Fonds dégelés",
        description: "Les fonds ont été dégelés avec succès"
      });

      // Rafraîchir les données
      await fetchFrozenFunds();
      return true;
    } catch (error) {
      console.error('Erreur lors du dégel des fonds:', error);
      toast({
        title: "Erreur",
        description: "Impossible de dégeler les fonds",
        variant: "destructive"
      });
      return false;
    }
  };

  useEffect(() => {
    fetchFrozenFunds();
  }, [user]);

  return {
    frozenFunds,
    totalFrozen,
    availableBalance,
    isLoading,
    freezeFunds,
    unfreezeFunds,
    refetch: fetchFrozenFunds
  };
};


import { useCallback } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'welcome' | 'tontine_created' | 'tontine_modified' | 'milestone' | 'general' | 'message_received' | 'join_request' | 'tontine_completed';
  isRead: boolean;
  createdAt: Date;
  relatedId?: string;
}

export const useNotifications = () => {
  const { t } = useLanguage();

  const addNotification = useCallback((notification: Omit<Notification, 'id' | 'isRead' | 'createdAt'>) => {
    const newNotification: Notification = {
      ...notification,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      isRead: false,
      createdAt: new Date()
    };

    const existingNotifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    const updatedNotifications = [newNotification, ...existingNotifications];
    
    // Garder seulement les 50 dernières notifications
    const limitedNotifications = updatedNotifications.slice(0, 50);
    
    localStorage.setItem('notifications', JSON.stringify(limitedNotifications));
    
    console.log('📱 Nouvelle notification:', notification.title);
  }, []);

  const addWelcomeNotification = useCallback(() => {
    addNotification({
      title: "🎉 Bienvenue sur NONRU !",
      message: "Félicitations ! Votre compte a été créé avec succès. Commencez dès maintenant votre voyage vers l'épargne collaborative.",
      type: 'welcome'
    });
  }, [addNotification]);

  const addTontineCreatedNotification = useCallback((tontineName: string, tontineCount: number) => {
    let title, message;
    
    if (tontineCount === 1) {
      title = "🎊 Votre première tontine !";
      message = `Félicitations ! Vous avez créé votre première tontine "${tontineName}". C'est le début de votre aventure d'épargne collective !`;
    } else {
      title = `🎯 ${tontineCount}ème tontine créée !`;
      message = `Excellent ! Votre ${tontineCount}ème tontine "${tontineName}" a été créée avec succès. Vous maîtrisez de mieux en mieux l'épargne collaborative !`;
    }

    addNotification({
      title,
      message,
      type: 'tontine_created'
    });
  }, [addNotification]);

  const addMessageReceivedNotification = useCallback((senderName: string, preview: string) => {
    addNotification({
      title: `💬 Nouveau message de ${senderName}`,
      message: `Vous avez reçu un message de ${senderName}: "${preview.length > 50 ? preview.substring(0, 50) + '...' : preview}"`,
      type: 'message_received'
    });
  }, [addNotification]);

  const addJoinRequestNotification = useCallback((requesterName: string, tontineName: string) => {
    addNotification({
      title: `👋 Demande de participation`,
      message: `${requesterName} souhaite rejoindre votre tontine "${tontineName}". Vous pouvez examiner son profil ou lui envoyer un message.`,
      type: 'join_request'
    });
  }, [addNotification]);

  const addTontineCompletedNotification = useCallback((tontineName: string, completedCount: number) => {
    let title, message;
    
    switch (completedCount) {
      case 1:
        title = "🏆 Première tontine terminée !";
        message = `Incroyable ! Vous avez terminé votre première tontine "${tontineName}". Félicitations pour ce premier succès dans l'épargne collaborative !`;
        break;
      case 2:
        title = "🌟 Deuxième tontine terminée !";
        message = `Bravo ! Votre deuxième tontine "${tontineName}" est maintenant terminée. Vous développez une excellente habitude d'épargne !`;
        break;
      case 3:
        title = "🚀 Troisième tontine terminée !";
        message = `Extraordinaire ! Votre troisième tontine "${tontineName}" est terminée. Vous êtes en train de devenir un expert de l'épargne collaborative !`;
        break;
      default:
        title = `🎖️ ${completedCount}ème tontine terminée !`;
        message = `Félicitations ! Votre ${completedCount}ème tontine "${tontineName}" est maintenant terminée. Votre discipline d'épargne est remarquable !`;
    }

    addNotification({
      title,
      message,
      type: 'tontine_completed'
    });
  }, [addNotification]);

  const addTontineModifiedNotification = useCallback((tontineName: string, changes: string[]) => {
    addNotification({
      title: "✏️ Tontine modifiée",
      message: `Votre tontine "${tontineName}" a été modifiée. Changements: ${changes.join(', ')}.`,
      type: 'tontine_modified'
    });
  }, [addNotification]);

  const addMilestoneNotification = useCallback((milestone: string, description: string) => {
    addNotification({
      title: `🎉 ${milestone}`,
      message: description,
      type: 'milestone'
    });
  }, [addNotification]);

  return {
    addNotification,
    addWelcomeNotification,
    addTontineCreatedNotification,
    addMessageReceivedNotification,
    addJoinRequestNotification,
    addTontineCompletedNotification,
    addTontineModifiedNotification,
    addMilestoneNotification
  };
};

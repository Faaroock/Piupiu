
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface TontineShareHook {
  shareLink: string | null;
  isGenerating: boolean;
  generateShareLink: (tontineId: string) => Promise<string | null>;
  copyShareLink: (link: string, name: string) => Promise<void>;
}

export const useTontineShare = (): TontineShareHook => {
  const [shareLink, setShareLink] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const { toast } = useToast();

  const generateShareLink = async (tontineId: string): Promise<string | null> => {
    try {
      setIsGenerating(true);
      
      // Récupérer ou générer le share_link
      let { data: tontine, error } = await supabase
        .from('tontines')
        .select('share_link')
        .eq('id', tontineId)
        .single();

      if (error) throw error;

      let link = tontine?.share_link;
      
      // Générer un nouveau lien si nécessaire
      if (!link) {
        const { data: updatedTontine, error: updateError } = await supabase
          .from('tontines')
          .update({ share_link: crypto.randomUUID() })
          .eq('id', tontineId)
          .select('share_link')
          .single();

        if (updateError) throw updateError;
        link = updatedTontine?.share_link;
      }

      const fullLink = `${window.location.origin}/tontine/${link}`;
      setShareLink(fullLink);
      return fullLink;
    } catch (error) {
      console.error('Erreur génération lien de partage:', error);
      toast({
        title: "Erreur",
        description: "Impossible de générer le lien de partage",
        variant: "destructive"
      });
      return null;
    } finally {
      setIsGenerating(false);
    }
  };

  const copyShareLink = async (link: string, name: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(link);
      toast({
        title: "Lien copié !",
        description: `Le lien de partage pour "${name}" a été copié`
      });
    } catch (error) {
      console.error('Erreur copie du lien:', error);
      toast({
        title: "Erreur",
        description: "Impossible de copier le lien",
        variant: "destructive"
      });
    }
  };

  return {
    shareLink,
    isGenerating,
    generateShareLink,
    copyShareLink
  };
};

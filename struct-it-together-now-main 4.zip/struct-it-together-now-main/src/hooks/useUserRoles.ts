
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface UserRole {
  id: string;
  user_id: string;
  role: 'super_admin' | 'admin' | 'moderator' | 'developer' | 'user';
  assigned_at: string;
  assigned_by?: string;
}

export interface UserWithRole {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  roles: UserRole[];
}

type RoleType = 'super_admin' | 'admin' | 'moderator' | 'developer' | 'user';

export const useUserRoles = () => {
  const { user } = useAuth();
  const [users, setUsers] = useState<UserWithRole[]>([]);
  const [currentUserRoles, setCurrentUserRoles] = useState<UserRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if current user has specific role
  const hasRole = (role: RoleType): boolean => {
    return currentUserRoles.some(userRole => userRole.role === role);
  };

  // Check if current user has permission level (hierarchical)
  const hasPermissionLevel = (minRole: RoleType): boolean => {
    const roleHierarchy: Record<RoleType, number> = {
      'super_admin': 5,
      'admin': 4,
      'moderator': 3,
      'developer': 2,
      'user': 1
    };

    const userMaxLevel = Math.max(...currentUserRoles.map(r => roleHierarchy[r.role] || 0));
    const requiredLevel = roleHierarchy[minRole] || 0;
    
    return userMaxLevel >= requiredLevel;
  };

  // Fetch current user's roles
  const fetchCurrentUserRoles = async () => {
    if (!user?.id) return;

    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('*')
        .eq('user_id', user.id);

      if (error) throw error;
      setCurrentUserRoles(data || []);
    } catch (err) {
      console.error('Error fetching current user roles:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch user roles');
    }
  };

  // Fetch all users with their roles (admin only)
  const fetchUsersWithRoles = async () => {
    if (!hasPermissionLevel('admin')) return;

    try {
      setLoading(true);
      
      // First get all profiles
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, user_id, email, first_name, last_name');

      if (profilesError) throw profilesError;

      // Then get all user roles
      const { data: roles, error: rolesError } = await supabase
        .from('user_roles')
        .select('*');

      if (rolesError) throw rolesError;

      // Combine the data
      const usersWithRoles = profiles.map(profile => ({
        id: profile.user_id || profile.id,
        email: profile.email,
        first_name: profile.first_name,
        last_name: profile.last_name,
        roles: roles.filter(role => role.user_id === (profile.user_id || profile.id))
      }));

      setUsers(usersWithRoles);
    } catch (err) {
      console.error('Error fetching users with roles:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch users');
    } finally {
      setLoading(false);
    }
  };

  // Assign role to user
  const assignRole = async (userId: string, role: RoleType) => {
    if (!hasRole('super_admin')) {
      throw new Error('Unauthorized: Only super admins can assign roles');
    }

    try {
      const { error } = await supabase
        .from('user_roles')
        .insert({
          user_id: userId,
          role: role,
          assigned_by: user?.id
        });

      if (error) throw error;

      // Log the action
      await supabase
        .from('admin_activity_logs')
        .insert({
          admin_user_id: user?.id,
          target_user_id: userId,
          action: 'assign_role',
          details: { role }
        });

      // Refresh data
      await fetchUsersWithRoles();
      
    } catch (err) {
      console.error('Error assigning role:', err);
      throw err;
    }
  };

  // Remove role from user
  const removeRole = async (userId: string, role: RoleType) => {
    if (!hasRole('super_admin')) {
      throw new Error('Unauthorized: Only super admins can remove roles');
    }

    try {
      const { error } = await supabase
        .from('user_roles')
        .delete()
        .eq('user_id', userId)
        .eq('role', role);

      if (error) throw error;

      // Log the action
      await supabase
        .from('admin_activity_logs')
        .insert({
          admin_user_id: user?.id,
          target_user_id: userId,
          action: 'remove_role',
          details: { role }
        });

      // Refresh data
      await fetchUsersWithRoles();
      
    } catch (err) {
      console.error('Error removing role:', err);
      throw err;
    }
  };

  useEffect(() => {
    if (user?.id) {
      fetchCurrentUserRoles();
    }
  }, [user?.id]);

  useEffect(() => {
    if (currentUserRoles.length > 0 && hasPermissionLevel('admin')) {
      fetchUsersWithRoles();
    }
  }, [currentUserRoles]);

  return {
    users,
    currentUserRoles,
    loading,
    error,
    hasRole,
    hasPermissionLevel,
    assignRole,
    removeRole,
    refreshUsers: fetchUsersWithRoles
  };
};

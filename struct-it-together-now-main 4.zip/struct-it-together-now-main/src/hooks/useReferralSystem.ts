import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

interface ReferralData {
  referralCode: string;
  isUnlocked: boolean;
  totalReferrals: number;
  totalEarnings: number;
  qrCodeUrl: string;
}

interface UseReferralSystemReturn {
  referralData: ReferralData | null;
  loading: boolean;
  generateReferralCode: () => Promise<void>;
  checkReferralUnlock: () => Promise<boolean>;
}

export const useReferralSystem = (): UseReferralSystemReturn => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [referralData, setReferralData] = useState<ReferralData | null>(null);
  const [loading, setLoading] = useState(true);

  const checkReferralUnlock = async () => {
    if (!user) return false;

    try {
      // Vérifier si l'utilisateur a complété au moins une tontine
      const { data: hasCompleted, error } = await supabase
        .rpc('has_completed_tontine', { user_uuid: user.id });

      if (error) throw error;

      return hasCompleted;
    } catch (error) {
      console.error('Erreur vérification déverrouillage:', error);
      return false;
    }
  };

  const fetchReferralData = async () => {
    if (!user) return;

    try {
      // Vérifier le déverrouillage
      const isUnlocked = await checkReferralUnlock();

      if (!isUnlocked) {
        setReferralData({
          referralCode: '',
          isUnlocked: false,
          totalReferrals: 0,
          totalEarnings: 0,
          qrCodeUrl: ''
        });
        return;
      }

      // Récupérer les données de parrainage
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('referral_code, referral_earnings')
        .eq('user_id', user.id)
        .single();

      if (profileError) throw profileError;

      // Compter les parrainages
      const { count: totalReferrals } = await supabase
        .from('referrals')
        .select('*', { count: 'exact', head: true })
        .eq('referrer_id', user.id);

      const referralCode = profileData?.referral_code || '';
      const referralLink = `${window.location.origin}/signup?ref=${referralCode}`;
      const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(referralLink)}`;

      setReferralData({
        referralCode,
        isUnlocked: true,
        totalReferrals: totalReferrals || 0,
        totalEarnings: profileData?.referral_earnings || 0,
        qrCodeUrl
      });
    } catch (error) {
      console.error('Erreur récupération données parrainage:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateReferralCode = async () => {
    if (!user) return;

    try {
      // Générer un nouveau code via la fonction Supabase
      const { data: newCode, error } = await supabase
        .rpc('generate_unique_referral_code');

      if (error) throw error;

      // Mettre à jour le profil
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ referral_code: newCode })
        .eq('user_id', user.id);

      if (updateError) throw updateError;

      await fetchReferralData();
      toast({
        title: "Code généré !",
        description: "Nouveau code de parrainage créé avec succès"
      });
    } catch (error) {
      console.error('Erreur génération code:', error);
      toast({
        title: "Erreur",
        description: "Impossible de générer le code de parrainage",
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    fetchReferralData();
  }, [user]);

  return {
    referralData,
    loading,
    generateReferralCode,
    checkReferralUnlock
  };
};


import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface TontineHistoryEntry {
  id: string;
  action: string;
  details: any;
  created_at: string;
  user_name?: string;
}

export const useTontineHistory = (tontineId: string) => {
  const [history, setHistory] = useState<TontineHistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchHistory = async () => {
    if (!tontineId) return;

    try {
      const { data, error } = await supabase
        .from('epargne_history')
        .select(`
          id,
          action,
          details,
          created_at,
          user_id
        `)
        .eq('epargne_id', tontineId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Get user profiles for the user_ids in the history
      const userIds = [...new Set((data || []).map(entry => entry.user_id))];
      
      let profilesData = [];
      if (userIds.length > 0) {
        const { data: profiles, error: profilesError } = await supabase
          .from('profiles')
          .select('user_id, first_name, last_name')
          .in('user_id', userIds);

        if (!profilesError) {
          profilesData = profiles || [];
        }
      }

      // Combine history with user names
      const formattedHistory = (data || []).map(entry => {
        const userProfile = profilesData.find(profile => profile.user_id === entry.user_id);
        return {
          id: entry.id,
          action: entry.action,
          details: entry.details,
          created_at: entry.created_at,
          user_name: userProfile 
            ? `${userProfile.first_name} ${userProfile.last_name}`.trim()
            : undefined
        };
      });

      setHistory(formattedHistory);
    } catch (error) {
      console.error('Erreur récupération historique épargne:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [tontineId]);

  return {
    history,
    loading,
    refetch: fetchHistory
  };
};

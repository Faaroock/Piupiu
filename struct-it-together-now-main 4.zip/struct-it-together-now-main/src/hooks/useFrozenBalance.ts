
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

interface FrozenBalance {
  id: string;
  amount: number;
  reason: string;
  created_at: string;
  is_active: boolean;
}

interface UseFrozenBalanceReturn {
  frozenBalances: FrozenBalance[];
  totalFrozenAmount: number;
  availableBalance: number;
  loading: boolean;
  freezeFunds: (amount: number, reason: string) => Promise<void>;
  unfreezeFunds: (id: string) => Promise<void>;
  refreshBalances: () => Promise<void>;
}

export const useFrozenBalance = (): UseFrozenBalanceReturn => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [frozenBalances, setFrozenBalances] = useState<FrozenBalance[]>([]);
  const [totalFrozenAmount, setTotalFrozenAmount] = useState(0);
  const [availableBalance, setAvailableBalance] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchBalances = async () => {
    if (!user) return;

    try {
      // Récupérer les fonds confinés
      const { data: frozenData, error: frozenError } = await supabase
        .from('frozen_funds')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (frozenError) throw frozenError;

      // Récupérer le solde total
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('balance')
        .eq('user_id', user.id)
        .single();

      if (profileError) throw profileError;

      const frozen = frozenData || [];
      const totalBalance = profileData?.balance || 0;
      const totalFrozen = frozen.reduce((sum, item) => sum + Number(item.amount), 0);
      
      setFrozenBalances(frozen);
      setTotalFrozenAmount(totalFrozen);
      setAvailableBalance(totalBalance - totalFrozen);
    } catch (error) {
      console.error('Erreur récupération balances:', error);
      toast({
        title: "Erreur",
        description: "Impossible de récupérer les informations de balance",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const freezeFunds = async (amount: number, reason: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('frozen_funds')
        .insert({
          user_id: user.id,
          amount,
          reason,
          is_active: true
        });

      if (error) throw error;

      await fetchBalances();
      toast({
        title: "Fonds confinés",
        description: `${amount.toLocaleString()} F ont été confinés avec succès`
      });
    } catch (error) {
      console.error('Erreur confinement fonds:', error);
      toast({
        title: "Erreur",
        description: "Impossible de confiner les fonds",
        variant: "destructive"
      });
    }
  };

  const unfreezeFunds = async (id: string) => {
    try {
      const { error } = await supabase
        .from('frozen_funds')
        .update({ is_active: false })
        .eq('id', id);

      if (error) throw error;

      await fetchBalances();
      toast({
        title: "Fonds libérés",
        description: "Les fonds ont été libérés avec succès"
      });
    } catch (error) {
      console.error('Erreur libération fonds:', error);
      toast({
        title: "Erreur",
        description: "Impossible de libérer les fonds",
        variant: "destructive"
      });
    }
  };

  const refreshBalances = async () => {
    setLoading(true);
    await fetchBalances();
  };

  useEffect(() => {
    fetchBalances();
  }, [user]);

  return {
    frozenBalances,
    totalFrozenAmount,
    availableBalance,
    loading,
    freezeFunds,
    unfreezeFunds,
    refreshBalances
  };
};

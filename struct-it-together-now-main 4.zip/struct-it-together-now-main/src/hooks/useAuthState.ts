
import { useState, useEffect } from "react";
import { Session, AuthChangeEvent } from '@supabase/supabase-js';
import { supabase } from "@/integrations/supabase/client";
import { User } from "@/types/auth";

export const useAuthState = () => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  const convertSupabaseUserToUser = (supabaseSession: Session): User => {
    return {
      id: supabaseSession.user.id,
      email: supabaseSession.user.email || '',
      name: supabaseSession.user.user_metadata?.first_name || supabaseSession.user.email?.split('@')[0] || 'User',
      avatar: supabaseSession.user.user_metadata?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${supabaseSession.user.email}`,
      user_metadata: {
        first_name: supabaseSession.user.user_metadata?.first_name,
        last_name: supabaseSession.user.user_metadata?.last_name,
        age: supabaseSession.user.user_metadata?.age,
        referral_source: supabaseSession.user.user_metadata?.referral_source,
        referral_other: supabaseSession.user.user_metadata?.referral_other,
        is_new_user: supabaseSession.user.user_metadata?.is_new_user,
      }
    };
  };

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event: AuthChangeEvent, session) => {
        console.log('Auth state changed:', event, session);
        setSession(session);
        
        if (session?.user) {
          const userData = convertSupabaseUserToUser(session);
          setUser(userData);

          // Détecter les nouvelles inscriptions avec SIGNED_IN et le flag is_new_user
          if (event === 'SIGNED_IN' && session.user.user_metadata?.is_new_user === true) {
            console.log('nouvel inscrit');
            
            // Retirer le flag is_new_user pour éviter les notifications répétées
            setTimeout(async () => {
              try {
                await supabase.auth.updateUser({
                  data: {
                    ...session.user.user_metadata,
                    is_new_user: false
                  }
                });
                console.log('Flag is_new_user retiré avec succès');
              } catch (error) {
                console.error('Erreur lors de la mise à jour des métadonnées utilisateur:', error);
              }
            }, 1000);
          }
        } else {
          setUser(null);
        }
        setLoading(false);
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      console.log('Initial session check:', session);
      setSession(session);
      
      if (session?.user) {
        const userData = convertSupabaseUserToUser(session);
        setUser(userData);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  return { user, session, loading, setUser, setSession, setLoading };
};

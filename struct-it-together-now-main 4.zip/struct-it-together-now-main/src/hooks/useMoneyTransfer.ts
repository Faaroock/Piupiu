
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { useNotifications } from '@/hooks/useNotifications';

export const useMoneyTransfer = () => {
  const [availableBalance, setAvailableBalance] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const { user } = useAuth();
  const { toast } = useToast();
  const { addNotification } = useNotifications();

  const fetchBalance = async () => {
    if (!user) return;

    try {
      setIsLoading(true);
      
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('id, balance')
        .eq('user_id', user.id)
        .single();

      if (error) throw error;

      if (profile) {
        const { data: available, error: availableError } = await supabase
          .rpc('get_user_available_balance', { profile_user_id: profile.id });

        if (availableError) throw availableError;
        setAvailableBalance(available || 0);
      }
    } catch (error) {
      console.error('Erreur lors de la récupération du solde:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger le solde",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const calculateTransferFees = (amount: number): number => {
    if (amount <= 1000) return 25;
    if (amount <= 5000) return 50;
    if (amount <= 10000) return 75;
    if (amount <= 50000) return 100;
    return Math.ceil(amount * 0.002); // 0.2% pour les gros montants
  };

  const sendMoney = async (receiverEmail: string, amount: number, message: string = ''): Promise<boolean> => {
    if (!user) return false;

    try {
      const fees = calculateTransferFees(amount);
      const totalAmount = amount + fees;

      if (totalAmount > availableBalance) {
        toast({
          title: "Solde insuffisant",
          description: "Vous n'avez pas assez de fonds disponibles pour ce transfert",
          variant: "destructive"
        });
        return false;
      }

      // Récupérer le profil de l'expéditeur
      const { data: senderProfile, error: senderError } = await supabase
        .from('profiles')
        .select('id, balance')
        .eq('user_id', user.id)
        .single();

      if (senderError) throw senderError;

      // Récupérer le profil du destinataire par email
      const { data: receiverProfile, error: receiverError } = await supabase
        .from('profiles')
        .select('id, balance, user_id')
        .eq('email', receiverEmail)
        .single();

      if (receiverError || !receiverProfile) {
        toast({
          title: "Destinataire introuvable",
          description: "Aucun utilisateur trouvé avec cette adresse email",
          variant: "destructive"
        });
        return false;
      }

      // Vérifier que l'expéditeur a suffisamment de fonds
      if (senderProfile.balance < totalAmount) {
        toast({
          title: "Solde insuffisant",
          description: "Votre solde est insuffisant pour ce transfert",
          variant: "destructive"
        });
        return false;
      }

      // Effectuer le transfert manuellement
      // 1. Débiter l'expéditeur
      const { error: debitError } = await supabase
        .from('profiles')
        .update({ balance: senderProfile.balance - totalAmount })
        .eq('id', senderProfile.id);

      if (debitError) throw debitError;

      // 2. Créditer le destinataire
      const { error: creditError } = await supabase
        .from('profiles')
        .update({ balance: receiverProfile.balance + amount })
        .eq('id', receiverProfile.id);

      if (creditError) {
        // En cas d'erreur, restaurer le solde de l'expéditeur
        await supabase
          .from('profiles')
          .update({ balance: senderProfile.balance })
          .eq('id', senderProfile.id);
        throw creditError;
      }

      // Enregistrer la transaction
      const { error: transactionError } = await supabase
        .from('transactions')
        .insert({
          from_user_id: user.id,
          to_user_id: receiverProfile.user_id,
          amount: amount,
          fee_amount: fees,
          transaction_type: 'transfer',
          description: message || 'Transfert d\'argent'
        });

      if (transactionError) {
        console.error('Erreur lors de l\'enregistrement de la transaction:', transactionError);
      }

      // Ajouter des notifications
      addNotification({
        title: "Transfert envoyé",
        message: `Vous avez envoyé ${amount.toLocaleString()} F à ${receiverEmail}`,
        type: 'general'
      });

      toast({
        title: "Transfert réussi",
        description: `${amount.toLocaleString()} F ont été envoyés à ${receiverEmail}`
      });

      // Rafraîchir le solde
      await fetchBalance();
      return true;

    } catch (error) {
      console.error('Erreur lors du transfert:', error);
      
      // Enregistrer l'échec de la transaction
      try {
        const { data: senderProfile } = await supabase
          .from('profiles')
          .select('id')
          .eq('user_id', user.id)
          .single();

        if (senderProfile) {
          await supabase
            .from('transactions')
            .insert({
              from_user_id: user.id,
              to_user_id: null,
              amount: amount,
              fee_amount: calculateTransferFees(amount),
              transaction_type: 'transfer',
              description: `Échec: ${message || 'Transfert d\'argent'}`
            });
        }
      } catch (logError) {
        console.error('Erreur lors de l\'enregistrement de l\'échec:', logError);
      }

      toast({
        title: "Erreur de transfert",
        description: "Impossible d'effectuer le transfert",
        variant: "destructive"
      });
      return false;
    }
  };

  useEffect(() => {
    fetchBalance();
  }, [user]);

  return {
    availableBalance,
    isLoading,
    sendMoney,
    calculateTransferFees,
    refetch: fetchBalance
  };
};

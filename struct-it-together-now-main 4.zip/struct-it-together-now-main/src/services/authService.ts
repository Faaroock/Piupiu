
import { supabase } from "@/integrations/supabase/client";

export const authService = {
  login: async (email: string, password: string) => {
    console.log('🔑 [AUTH] Tentative de connexion pour:', email);
    
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.error('❌ [AUTH] Erreur de connexion:', error);
      throw new Error(error.message);
    }

    console.log('✅ [AUTH] Connexion réussie pour:', email);
    return data;
  },

  signup: async (email: string, password: string, name: string, metadata?: any) => {
    console.log('👤 [AUTH] Début de l\'inscription pour:', email);
    console.log('👤 [AUTH] Métadonnées utilisateur:', metadata);
    
    // Validation de l'âge côté frontend aussi
    if (metadata?.age && metadata.age < 15) {
      console.log('❌ [AUTH] Âge insuffisant:', metadata.age);
      throw new Error("Vous n'avez pas l'âge requis pour vous inscrire sur Nonru");
    }

    // Configuration de l'URL de redirection avec l'origine actuelle
    const redirectUrl = `${window.location.origin}/dashboard`;
    console.log('🔗 [AUTH] URL de redirection configurée:', redirectUrl);

    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: {
          first_name: metadata?.first_name || name,
          last_name: metadata?.last_name || "",
          age: metadata?.age,
          referral_source: metadata?.referral_source,
          referral_other: metadata?.referral_other,
          is_new_user: true, // Flag pour détecter les nouveaux utilisateurs
        }
      }
    });

    if (error) {
      console.error('❌ [AUTH] Erreur lors de l\'inscription:', error);
      console.error('❌ [AUTH] Détails de l\'erreur:', {
        message: error.message,
        status: error.status,
        details: error
      });
      throw new Error(error.message);
    }

    console.log('✅ [AUTH] Inscription réussie pour:', email);
    console.log('✅ [AUTH] Données retournées:', {
      user: data.user?.id,
      session: data.session?.access_token ? 'Présent' : 'Absent'
    });
    return data;
  },

  logout: async () => {
    console.log('🚪 [AUTH] Déconnexion en cours...');
    const { error } = await supabase.auth.signOut();
    if (error) {
      console.error('❌ [AUTH] Erreur de déconnexion:', error);
      throw error;
    }
    console.log('✅ [AUTH] Déconnexion réussie');
  }
};

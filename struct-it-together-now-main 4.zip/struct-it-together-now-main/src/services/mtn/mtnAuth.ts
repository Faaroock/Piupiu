
import { getMtnApiByCountry } from '../paymentManager';

interface MtnTokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}

interface MtnApiKeyResponse {
  apiKey: string;
}

export class MtnAuthService {
  private static tokens: Map<string, { token: string; expires: number }> = new Map();

  static async generateApiKey(countryCode: string): Promise<string> {
    const config = getMtnApiByCountry(countryCode);
    
    try {
      const response = await fetch(`${config.apiUrl.replace('/collection/v1_0', '')}/v1_0/apiuser/${config.apiUserId}/apikey`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key': config.subscriptionKey,
          'X-Target-Environment': config.targetEnvironment
        }
      });

      if (!response.ok) {
        throw new Error(`Erreur génération API Key MTN : ${response.status}`);
      }

      const data: MtnApiKeyResponse = await response.json();
      console.log(`API Key générée pour ${countryCode}:`, data.apiKey);
      return data.apiKey;
    } catch (error) {
      console.error('Erreur génération API Key MTN:', error);
      throw error;
    }
  }

  static async getAccessToken(countryCode: string, apiKey: string): Promise<string> {
    const tokenKey = `mtn_${countryCode}`;
    const cached = this.tokens.get(tokenKey);
    
    if (cached && cached.expires > Date.now()) {
      return cached.token;
    }

    const config = getMtnApiByCountry(countryCode);
    const credentials = btoa(`${config.apiUserId}:${apiKey}`);

    try {
      const response = await fetch(`${config.apiUrl}/token/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Basic ${credentials}`,
          'Ocp-Apim-Subscription-Key': config.subscriptionKey,
          'X-Target-Environment': config.targetEnvironment
        }
      });

      if (!response.ok) {
        throw new Error(`Erreur token MTN : ${response.status}`);
      }

      const data: MtnTokenResponse = await response.json();
      
      // Cache le token
      this.tokens.set(tokenKey, {
        token: data.access_token,
        expires: Date.now() + (data.expires_in * 1000) - 60000 // -1 min de sécurité
      });

      return data.access_token;
    } catch (error) {
      console.error('Erreur récupération token MTN:', error);
      throw error;
    }
  }
}


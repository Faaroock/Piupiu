
import { getMtnApiByCountry } from '../paymentManager';
import { MtnAuthService } from './mtnAuth';

interface PaymentRequest {
  amount: string;
  currency: string;
  externalId: string;
  payer: {
    partyIdType: string;
    partyId: string;
  };
  payerMessage: string;
  payeeNote: string;
}

interface PaymentResponse {
  referenceId: string;
  status: string;
  reason?: string;
}

interface PaymentStatus {
  amount: string;
  currency: string;
  externalId: string;
  payer: {
    partyIdType: string;
    partyId: string;
  };
  status: string;
  reason?: string;
  financialTransactionId?: string;
}

export class MtnPaymentService {
  static async requestToPay(
    countryCode: string,
    apiKey: string,
    payment: PaymentRequest
  ): Promise<PaymentResponse> {
    const config = getMtnApiByCountry(countryCode);
    const accessToken = await MtnAuthService.getAccessToken(countryCode, apiKey);
    const referenceId = crypto.randomUUID();

    try {
      const response = await fetch(`${config.apiUrl}/requesttopay`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
          'X-Reference-Id': referenceId,
          'X-Target-Environment': config.targetEnvironment,
          'Ocp-Apim-Subscription-Key': config.subscriptionKey
        },
        body: JSON.stringify(payment)
      });

      if (response.status === 202) {
        console.log(`Paiement MTN initié pour ${countryCode}, référence: ${referenceId}`);
        return { referenceId, status: 'PENDING' };
      } else {
        const errorText = await response.text();
        throw new Error(`Erreur paiement MTN : ${response.status} - ${errorText}`);
      }
    } catch (error) {
      console.error('Erreur requestToPay MTN:', error);
      throw error;
    }
  }

  static async getPaymentStatus(
    countryCode: string,
    apiKey: string,
    referenceId: string
  ): Promise<PaymentStatus> {
    const config = getMtnApiByCountry(countryCode);
    const accessToken = await MtnAuthService.getAccessToken(countryCode, apiKey);

    try {
      const response = await fetch(`${config.apiUrl}/requesttopay/${referenceId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'X-Target-Environment': config.targetEnvironment,
          'Ocp-Apim-Subscription-Key': config.subscriptionKey
        }
      });

      if (!response.ok) {
        throw new Error(`Erreur statut paiement MTN : ${response.status}`);
      }

      const data: PaymentStatus = await response.json();
      return data;
    } catch (error) {
      console.error('Erreur getPaymentStatus MTN:', error);
      throw error;
    }
  }
}



interface ApiConfig {
  apiUrl: string;
  apiKey?: string;
  subscriptionKey: string;
  apiUserId: string;
  targetEnvironment: string;
}

interface MoovConfig {
  publicKey: string;
  sandbox: boolean;
  allowedDomains: string[];
}

interface KkiaPayConfig {
  publicKey: string;
  sandbox: boolean;
}

// Configuration MTN MoMo par pays
const mtnConfigs: Record<string, ApiConfig> = {
  bj: {
    apiUrl: "https://sandbox.momodeveloper.mtn.com/collection/v1_0",
    subscriptionKey: "4affb76646c5438292afd483e55083df",
    apiUserId: "f31f86a3-bb0f-445b-914d-eac6f5ffb56d",
    targetEnvironment: "sandbox"
  },
  ci: {
    apiUrl: "https://sandbox.momodeveloper.mtn.com/collection/v1_0",
    subscriptionKey: "4affb76646c5438292afd483e55083df",
    apiUserId: "f31f86a3-bb0f-445b-914d-eac6f5ffb56d",
    targetEnvironment: "sandbox"
  },
  bf: {
    apiUrl: "https://sandbox.momodeveloper.mtn.com/collection/v1_0",
    subscriptionKey: "4affb76646c5438292afd483e55083df",
    apiUserId: "f31f86a3-bb0f-445b-914d-eac6f5ffb56d",
    targetEnvironment: "sandbox"
  }
};

// Configuration Moov
const moovConfig: MoovConfig = {
  publicKey: "0OJBFZyZ2aqIeBGx",
  sandbox: true,
  allowedDomains: [
    "https://lovable.dev/projects/29a104d6-b0a8-46c1-8c1d-ca40ecf46cad",
    "https://nonrufaaroock.netlify.app"
  ]
};

// Configuration KkiaPay
const kkiaPayConfig: KkiaPayConfig = {
  publicKey: "de9979e04a7311f09b9e233509c54e45",
  sandbox: true
};

export function getMtnApiByCountry(countryCode: string): ApiConfig {
  const config = mtnConfigs[countryCode.toLowerCase()];
  if (!config) {
    throw new Error(`Pays non pris en charge pour MTN MoMo : ${countryCode}`);
  }
  return config;
}

export function getMoovConfig(): MoovConfig {
  return moovConfig;
}

export function getKkiaPayConfig(): KkiaPayConfig {
  return kkiaPayConfig;
}

export function getPaymentProvider(countryCode: string, operator?: string): 'mtn' | 'moov' | 'kkiapay' {
  // Logique pour déterminer le bon fournisseur selon le pays/opérateur
  const supportedMtnCountries = ['bj', 'ci', 'bf'];
  const supportedKkiaPayCountries = ['bj', 'ci', 'bf', 'tg', 'sn', 'ne', 'ml'];
  
  if (operator) {
    if (operator.toLowerCase().includes('mtn')) return 'mtn';
    if (operator.toLowerCase().includes('moov')) return 'moov';
    if (operator.toLowerCase().includes('kkiapay')) return 'kkiapay';
  }
  
  // Prioriser KkiaPay pour sa simplicité d'intégration
  if (supportedKkiaPayCountries.includes(countryCode.toLowerCase())) {
    return 'kkiapay';
  }
  
  if (supportedMtnCountries.includes(countryCode.toLowerCase())) {
    return 'mtn';
  }
  
  return 'moov'; // Par défaut
}

export const SUPPORTED_COUNTRIES = {
  MTN: ['bj', 'ci', 'bf'],
  MOOV: ['bj', 'ci', 'bf', 'tg', 'sn'],
  KKIAPAY: ['bj', 'ci', 'bf', 'tg', 'sn', 'ne', 'ml']
};

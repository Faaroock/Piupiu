
import { getMoovConfig } from '../paymentManager';

interface MoovTransferRequest {
  amount: number;
  currency: string;
  description: string;
  reference: string;
  recipient: {
    phone: string;
    name: string;
  };
  sender: {
    phone: string;
    name: string;
  };
}

interface MoovTransferResponse {
  transactionId: string;
  status: string;
  message: string;
  reference: string;
}

export class MoovPaymentService {
  private static baseUrl = 'https://api.moov-africa.com';

  static async initializeTransfer(transfer: MoovTransferRequest): Promise<MoovTransferResponse> {
    const config = getMoovConfig();
    
    // Vérification du domaine (seulement en sandbox)
    if (config.sandbox && typeof window !== 'undefined') {
      const currentDomain = window.location.origin;
      if (!config.allowedDomains.includes(currentDomain)) {
        console.warn(`Domaine non autorisé: ${currentDomain}`);
      }
    }

    const endpoint = config.sandbox ? '/sandbox/v1/transfers' : '/v1/transfers';

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${config.publicKey}`,
          'X-Sandbox': config.sandbox.toString()
        },
        body: JSON.stringify({
          ...transfer,
          sandbox: config.sandbox
        })
      });

      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(`Erreur Moov Transfer : ${response.status} - ${errorData}`);
      }

      const data: MoovTransferResponse = await response.json();
      console.log('Transfert Moov initié:', data);
      return data;
    } catch (error) {
      console.error('Erreur initializeTransfer Moov:', error);
      throw error;
    }
  }

  static async getTransferStatus(transactionId: string): Promise<any> {
    const config = getMoovConfig();
    const endpoint = config.sandbox ? '/sandbox/v1/transfers' : '/v1/transfers';

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}/${transactionId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${config.publicKey}`,
          'X-Sandbox': config.sandbox.toString()
        }
      });

      if (!response.ok) {
        throw new Error(`Erreur statut Moov : ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Erreur getTransferStatus Moov:', error);
      throw error;
    }
  }

  static async getAccountBalance(): Promise<any> {
    const config = getMoovConfig();
    const endpoint = config.sandbox ? '/sandbox/v1/accounts/balance' : '/v1/accounts/balance';

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${config.publicKey}`,
          'X-Sandbox': config.sandbox.toString()
        }
      });

      if (!response.ok) {
        throw new Error(`Erreur balance Moov : ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Erreur getAccountBalance Moov:', error);
      throw error;
    }
  }
}


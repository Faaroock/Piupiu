
interface KkiaPayConfig {
  publicKey: string;
  sandbox: boolean;
  theme: string;
  position: string;
}

interface KkiaPayPaymentRequest {
  amount: number;
  reason: string;
  callback: string;
  data?: any;
}

interface KkiaPayResponse {
  transactionId: string;
  status: string;
  amount: number;
  reason: string;
  paymentMethod: string;
  performedAt: string;
}

// Configuration KkiaPay en mode sandbox
const kkiaPayConfig: KkiaPayConfig = {
  publicKey: "de9979e04a7311f09b9e233509c54e45", // Clé sandbox fournie
  sandbox: true,
  theme: "#00B894", // Couleur NONRU
  position: "center"
};

export class KkiaPayService {
  private static config = kkiaPayConfig;

  static getConfig(): KkiaPayConfig {
    return this.config;
  }

  static async initializePayment(payment: KkiaPayPaymentRequest): Promise<void> {
    // Vérification que le SDK KkiaPay est chargé
    if (typeof (window as any).kkiapay === 'undefined') {
      throw new Error('SDK KkiaPay non chargé. Veuillez actualiser la page.');
    }

    console.log('Initialisation du paiement KkiaPay:', payment);

    // Initialisation du widget KkiaPay
    (window as any).kkiapay.open({
      amount: payment.amount,
      position: this.config.position,
      callback: payment.callback,
      data: payment.data || {},
      theme: this.config.theme,
      key: this.config.publicKey,
      sandbox: this.config.sandbox,
      reason: payment.reason
    });
  }

  static handleCallback(response: KkiaPayResponse): void {
    console.log('Réponse KkiaPay reçue:', response);
    
    // Traitement de la réponse selon le statut
    if (response.status === 'SUCCESS') {
      console.log('Paiement réussi:', response.transactionId);
    } else {
      console.log('Paiement échoué ou annulé:', response.status);
    }
  }

  static generateCallbackUrl(): string {
    const currentDomain = window.location.origin;
    return `${currentDomain}/payment-test?provider=kkiapay`;
  }

  static isAvailable(): boolean {
    return typeof (window as any).kkiapay !== 'undefined';
  }
}

// Types pour TypeScript
declare global {
  interface Window {
    kkiapay: {
      open: (options: {
        amount: number;
        position: string;
        callback: string;
        data: any;
        theme: string;
        key: string;
        sandbox: boolean;
        reason: string;
      }) => void;
    };
  }
}

export const KKIAPAY_SUPPORTED_COUNTRIES = ['bj', 'ci', 'bf', 'tg', 'sn', 'ne', 'ml'];

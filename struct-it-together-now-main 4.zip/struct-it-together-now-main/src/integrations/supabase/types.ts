export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      admin_activity_logs: {
        Row: {
          action: string
          admin_user_id: string
          created_at: string
          details: Json | null
          id: string
          target_user_id: string | null
        }
        Insert: {
          action: string
          admin_user_id: string
          created_at?: string
          details?: Json | null
          id?: string
          target_user_id?: string | null
        }
        Update: {
          action?: string
          admin_user_id?: string
          created_at?: string
          details?: Json | null
          id?: string
          target_user_id?: string | null
        }
        Relationships: []
      }
      connection_history: {
        Row: {
          connected_at: string | null
          id: string
          ip_address: unknown | null
          location: string | null
          session_duration: unknown | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          connected_at?: string | null
          id?: string
          ip_address?: unknown | null
          location?: string | null
          session_duration?: unknown | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          connected_at?: string | null
          id?: string
          ip_address?: unknown | null
          location?: string | null
          session_duration?: unknown | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      conversation_participants: {
        Row: {
          conversation_id: string
          id: string
          joined_at: string
          last_read_at: string | null
          left_at: string | null
          user_id: string
        }
        Insert: {
          conversation_id: string
          id?: string
          joined_at?: string
          last_read_at?: string | null
          left_at?: string | null
          user_id: string
        }
        Update: {
          conversation_id?: string
          id?: string
          joined_at?: string
          last_read_at?: string | null
          left_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversation_participants_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          created_at: string
          epargne_id: string | null
          id: string
          name: string | null
          type: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          epargne_id?: string | null
          id?: string
          name?: string | null
          type: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          epargne_id?: string | null
          id?: string
          name?: string | null
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversations_tontine_id_fkey"
            columns: ["epargne_id"]
            isOneToOne: false
            referencedRelation: "epargnes"
            referencedColumns: ["id"]
          },
        ]
      }
      epargne_history: {
        Row: {
          action: string
          created_at: string | null
          details: Json | null
          epargne_id: string
          id: string
          user_id: string
        }
        Insert: {
          action: string
          created_at?: string | null
          details?: Json | null
          epargne_id: string
          id?: string
          user_id: string
        }
        Update: {
          action?: string
          created_at?: string | null
          details?: Json | null
          epargne_id?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tontine_history_tontine_id_fkey"
            columns: ["epargne_id"]
            isOneToOne: false
            referencedRelation: "epargnes"
            referencedColumns: ["id"]
          },
        ]
      }
      epargne_members: {
        Row: {
          beneficiary_date: string | null
          epargne_id: string | null
          id: string
          is_beneficiary: boolean | null
          joined_at: string | null
          left_at: string | null
          total_contributed: number | null
          user_id: string | null
        }
        Insert: {
          beneficiary_date?: string | null
          epargne_id?: string | null
          id?: string
          is_beneficiary?: boolean | null
          joined_at?: string | null
          left_at?: string | null
          total_contributed?: number | null
          user_id?: string | null
        }
        Update: {
          beneficiary_date?: string | null
          epargne_id?: string | null
          id?: string
          is_beneficiary?: boolean | null
          joined_at?: string | null
          left_at?: string | null
          total_contributed?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tontine_members_tontine_id_fkey"
            columns: ["epargne_id"]
            isOneToOne: false
            referencedRelation: "epargnes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tontine_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      epargne_payments: {
        Row: {
          amount_due: number
          amount_paid: number | null
          created_at: string | null
          due_date: string
          epargne_id: string | null
          id: string
          is_late: boolean | null
          is_paid: boolean | null
          paid_date: string | null
          payment_round: number
          penalty_amount: number | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          amount_due: number
          amount_paid?: number | null
          created_at?: string | null
          due_date: string
          epargne_id?: string | null
          id?: string
          is_late?: boolean | null
          is_paid?: boolean | null
          paid_date?: string | null
          payment_round: number
          penalty_amount?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          amount_due?: number
          amount_paid?: number | null
          created_at?: string | null
          due_date?: string
          epargne_id?: string | null
          id?: string
          is_late?: boolean | null
          is_paid?: boolean | null
          paid_date?: string | null
          payment_round?: number
          penalty_amount?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tontine_payments_tontine_id_fkey"
            columns: ["epargne_id"]
            isOneToOne: false
            referencedRelation: "epargnes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tontine_payments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      epargne_requests: {
        Row: {
          created_at: string
          epargne_id: string
          id: string
          message: string | null
          requester_id: string
          status: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          epargne_id: string
          id?: string
          message?: string | null
          requester_id: string
          status?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          epargne_id?: string
          id?: string
          message?: string | null
          requester_id?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tontine_requests_tontine_id_fkey"
            columns: ["epargne_id"]
            isOneToOne: false
            referencedRelation: "epargnes"
            referencedColumns: ["id"]
          },
        ]
      }
      epargnes: {
        Row: {
          actual_end_date: string | null
          completed_at: string | null
          completion_percentage: number | null
          contribution_amount: number
          created_at: string | null
          creator_id: string | null
          currency: string | null
          current_members: number | null
          custom_frequency_days: number | null
          description: string | null
          estimated_end_date: string | null
          frequency: string
          goal_amount: number | null
          id: string
          is_private: boolean | null
          max_members: number
          max_missed_payments: number | null
          min_members: number | null
          name: string
          penalty_rate: number | null
          photo_url: string | null
          reason: string | null
          share_link: string | null
          start_date: string | null
          status: Database["public"]["Enums"]["tontine_status"] | null
          target_amount: number
          type: string | null
          updated_at: string | null
        }
        Insert: {
          actual_end_date?: string | null
          completed_at?: string | null
          completion_percentage?: number | null
          contribution_amount: number
          created_at?: string | null
          creator_id?: string | null
          currency?: string | null
          current_members?: number | null
          custom_frequency_days?: number | null
          description?: string | null
          estimated_end_date?: string | null
          frequency: string
          goal_amount?: number | null
          id?: string
          is_private?: boolean | null
          max_members: number
          max_missed_payments?: number | null
          min_members?: number | null
          name: string
          penalty_rate?: number | null
          photo_url?: string | null
          reason?: string | null
          share_link?: string | null
          start_date?: string | null
          status?: Database["public"]["Enums"]["tontine_status"] | null
          target_amount: number
          type?: string | null
          updated_at?: string | null
        }
        Update: {
          actual_end_date?: string | null
          completed_at?: string | null
          completion_percentage?: number | null
          contribution_amount?: number
          created_at?: string | null
          creator_id?: string | null
          currency?: string | null
          current_members?: number | null
          custom_frequency_days?: number | null
          description?: string | null
          estimated_end_date?: string | null
          frequency?: string
          goal_amount?: number | null
          id?: string
          is_private?: boolean | null
          max_members?: number
          max_missed_payments?: number | null
          min_members?: number | null
          name?: string
          penalty_rate?: number | null
          photo_url?: string | null
          reason?: string | null
          share_link?: string | null
          start_date?: string | null
          status?: Database["public"]["Enums"]["tontine_status"] | null
          target_amount?: number
          type?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tontines_creator_id_fkey"
            columns: ["creator_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      frozen_balances: {
        Row: {
          amount: number
          created_at: string | null
          id: string
          reason: string
          released_at: string | null
          user_id: string | null
        }
        Insert: {
          amount: number
          created_at?: string | null
          id?: string
          reason: string
          released_at?: string | null
          user_id?: string | null
        }
        Update: {
          amount?: number
          created_at?: string | null
          id?: string
          reason?: string
          released_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "frozen_balances_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      frozen_funds: {
        Row: {
          amount: number
          auto_release: boolean | null
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          reason: string
          user_id: string
        }
        Insert: {
          amount: number
          auto_release?: boolean | null
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          reason: string
          user_id: string
        }
        Update: {
          amount?: number
          auto_release?: boolean | null
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          reason?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "frozen_funds_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          content: string | null
          conversation_id: string | null
          created_at: string | null
          file_url: string | null
          id: string
          is_read: boolean | null
          message_type: Database["public"]["Enums"]["message_type"] | null
          sender_id: string
        }
        Insert: {
          content?: string | null
          conversation_id?: string | null
          created_at?: string | null
          file_url?: string | null
          id?: string
          is_read?: boolean | null
          message_type?: Database["public"]["Enums"]["message_type"] | null
          sender_id: string
        }
        Update: {
          content?: string | null
          conversation_id?: string | null
          created_at?: string | null
          file_url?: string | null
          id?: string
          is_read?: boolean | null
          message_type?: Database["public"]["Enums"]["message_type"] | null
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      missed_payments: {
        Row: {
          created_at: string | null
          id: string
          is_ejected: boolean | null
          missed_count: number | null
          tontine_id: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_ejected?: boolean | null
          missed_count?: number | null
          tontine_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          is_ejected?: boolean | null
          missed_count?: number | null
          tontine_id?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "missed_payments_tontine_id_fkey"
            columns: ["tontine_id"]
            isOneToOne: false
            referencedRelation: "epargnes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "missed_payments_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string | null
          id: string
          is_read: boolean | null
          message: string
          notification_type: Database["public"]["Enums"]["notification_type"]
          related_id: string | null
          title: string
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_read?: boolean | null
          message: string
          notification_type: Database["public"]["Enums"]["notification_type"]
          related_id?: string | null
          title: string
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          is_read?: boolean | null
          message?: string
          notification_type?: Database["public"]["Enums"]["notification_type"]
          related_id?: string | null
          title?: string
          user_id?: string | null
        }
        Relationships: []
      }
      payment_methods: {
        Row: {
          account_name: string | null
          account_number: string
          created_at: string | null
          id: string
          is_active: boolean | null
          is_default: boolean | null
          method_type: string
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          account_name?: string | null
          account_number: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          method_type: string
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          account_name?: string | null
          account_number?: string
          created_at?: string | null
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          method_type?: string
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "payment_methods_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          balance: number | null
          created_at: string | null
          date_of_birth: string | null
          email: string
          first_name: string
          has_seen_demo: boolean | null
          id: string
          is_admin: boolean | null
          last_name: string
          phone: string | null
          referral_code: string | null
          referral_earnings: number | null
          referred_by: string | null
          total_contributed: number | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          avatar_url?: string | null
          balance?: number | null
          created_at?: string | null
          date_of_birth?: string | null
          email: string
          first_name: string
          has_seen_demo?: boolean | null
          id?: string
          is_admin?: boolean | null
          last_name: string
          phone?: string | null
          referral_code?: string | null
          referral_earnings?: number | null
          referred_by?: string | null
          total_contributed?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          avatar_url?: string | null
          balance?: number | null
          created_at?: string | null
          date_of_birth?: string | null
          email?: string
          first_name?: string
          has_seen_demo?: boolean | null
          id?: string
          is_admin?: boolean | null
          last_name?: string
          phone?: string | null
          referral_code?: string | null
          referral_earnings?: number | null
          referred_by?: string | null
          total_contributed?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      referral_earnings: {
        Row: {
          created_at: string
          earning_amount: number
          epargne_id: string
          id: string
          is_paid: boolean | null
          referee_id: string
          referrer_id: string
          total_contributed: number
        }
        Insert: {
          created_at?: string
          earning_amount: number
          epargne_id: string
          id?: string
          is_paid?: boolean | null
          referee_id: string
          referrer_id: string
          total_contributed: number
        }
        Update: {
          created_at?: string
          earning_amount?: number
          epargne_id?: string
          id?: string
          is_paid?: boolean | null
          referee_id?: string
          referrer_id?: string
          total_contributed?: number
        }
        Relationships: [
          {
            foreignKeyName: "referral_earnings_tontine_id_fkey"
            columns: ["epargne_id"]
            isOneToOne: false
            referencedRelation: "epargnes"
            referencedColumns: ["id"]
          },
        ]
      }
      referral_links: {
        Row: {
          created_at: string | null
          expires_at: string | null
          id: string
          is_active: boolean | null
          referral_code: string
          total_referrals: number | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          referral_code: string
          total_referrals?: number | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          expires_at?: string | null
          id?: string
          is_active?: boolean | null
          referral_code?: string
          total_referrals?: number | null
          user_id?: string
        }
        Relationships: []
      }
      referral_signups: {
        Row: {
          id: string
          referral_code: string
          referred_user_id: string
          referrer_user_id: string
          signed_up_at: string | null
        }
        Insert: {
          id?: string
          referral_code: string
          referred_user_id: string
          referrer_user_id: string
          signed_up_at?: string | null
        }
        Update: {
          id?: string
          referral_code?: string
          referred_user_id?: string
          referrer_user_id?: string
          signed_up_at?: string | null
        }
        Relationships: []
      }
      referrals: {
        Row: {
          created_at: string
          id: string
          referee_id: string
          referral_code: string
          referrer_id: string
          status: string
        }
        Insert: {
          created_at?: string
          id?: string
          referee_id: string
          referral_code: string
          referrer_id: string
          status?: string
        }
        Update: {
          created_at?: string
          id?: string
          referee_id?: string
          referral_code?: string
          referrer_id?: string
          status?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          created_at: string | null
          description: string | null
          epargne_id: string | null
          fee_amount: number | null
          from_user_id: string | null
          id: string
          is_international: boolean | null
          reference: string | null
          to_user_id: string | null
          transaction_type: Database["public"]["Enums"]["transaction_type"]
        }
        Insert: {
          amount: number
          created_at?: string | null
          description?: string | null
          epargne_id?: string | null
          fee_amount?: number | null
          from_user_id?: string | null
          id?: string
          is_international?: boolean | null
          reference?: string | null
          to_user_id?: string | null
          transaction_type: Database["public"]["Enums"]["transaction_type"]
        }
        Update: {
          amount?: number
          created_at?: string | null
          description?: string | null
          epargne_id?: string | null
          fee_amount?: number | null
          from_user_id?: string | null
          id?: string
          is_international?: boolean | null
          reference?: string | null
          to_user_id?: string | null
          transaction_type?: Database["public"]["Enums"]["transaction_type"]
        }
        Relationships: [
          {
            foreignKeyName: "transactions_from_user_id_fkey"
            columns: ["from_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_to_user_id_fkey"
            columns: ["to_user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_tontine_id_fkey"
            columns: ["epargne_id"]
            isOneToOne: false
            referencedRelation: "epargnes"
            referencedColumns: ["id"]
          },
        ]
      }
      user_badges: {
        Row: {
          badge_type: Database["public"]["Enums"]["badge_type"]
          earned_at: string | null
          id: string
          user_id: string | null
        }
        Insert: {
          badge_type: Database["public"]["Enums"]["badge_type"]
          earned_at?: string | null
          id?: string
          user_id?: string | null
        }
        Update: {
          badge_type?: Database["public"]["Enums"]["badge_type"]
          earned_at?: string | null
          id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_badges_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_demo_progress: {
        Row: {
          completed_at: string | null
          id: string
          step_number: number
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          id?: string
          step_number: number
          user_id: string
        }
        Update: {
          completed_at?: string | null
          id?: string
          step_number?: number
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          assigned_at: string
          assigned_by: string | null
          created_at: string
          id: string
          role: Database["public"]["Enums"]["user_role"]
          updated_at: string
          user_id: string
        }
        Insert: {
          assigned_at?: string
          assigned_by?: string | null
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string
          user_id: string
        }
        Update: {
          assigned_at?: string
          assigned_by?: string | null
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      wallet_transactions: {
        Row: {
          amount: number
          created_at: string | null
          external_reference: string | null
          fee_amount: number | null
          id: string
          net_amount: number
          notes: string | null
          payment_method_id: string | null
          payment_method_type: string
          processed_at: string | null
          status: string | null
          transaction_type: string
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          amount: number
          created_at?: string | null
          external_reference?: string | null
          fee_amount?: number | null
          id?: string
          net_amount: number
          notes?: string | null
          payment_method_id?: string | null
          payment_method_type: string
          processed_at?: string | null
          status?: string | null
          transaction_type: string
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          amount?: number
          created_at?: string | null
          external_reference?: string | null
          fee_amount?: number | null
          id?: string
          net_amount?: number
          notes?: string | null
          payment_method_id?: string | null
          payment_method_type?: string
          processed_at?: string | null
          status?: string | null
          transaction_type?: string
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wallet_transactions_payment_method_id_fkey"
            columns: ["payment_method_id"]
            isOneToOne: false
            referencedRelation: "payment_methods"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wallet_transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      calculate_deposit_fee: {
        Args: { amount: number }
        Returns: number
      }
      calculate_withdrawal_fee: {
        Args: { amount: number }
        Returns: number
      }
      generate_referral_code: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      generate_unique_referral_code: {
        Args: Record<PropertyKey, never>
        Returns: string
      }
      get_user_available_balance: {
        Args: { profile_user_id: string }
        Returns: number
      }
      get_user_frozen_balance: {
        Args: { profile_user_id: string }
        Returns: number
      }
      has_completed_tontine: {
        Args: { user_uuid: string }
        Returns: boolean
      }
      has_permission_level: {
        Args: {
          _user_id: string
          _min_role: Database["public"]["Enums"]["user_role"]
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _user_id: string
          _role: Database["public"]["Enums"]["user_role"]
        }
        Returns: boolean
      }
      process_referral_earnings: {
        Args: { epargne_uuid: string }
        Returns: undefined
      }
    }
    Enums: {
      badge_type:
        | "entrepreneur"
        | "fidele"
        | "debutant"
        | "economiste"
        | "leader"
      message_type: "text" | "audio" | "image"
      notification_type:
        | "payment_received"
        | "new_member"
        | "contribution_due"
        | "reminder"
        | "tontine_completed"
        | "system"
      tontine_status: "active" | "completed" | "cancelled"
      transaction_type:
        | "deposit"
        | "transfer"
        | "contribution"
        | "withdrawal"
        | "fee"
      user_role: "super_admin" | "admin" | "moderator" | "developer" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      badge_type: [
        "entrepreneur",
        "fidele",
        "debutant",
        "economiste",
        "leader",
      ],
      message_type: ["text", "audio", "image"],
      notification_type: [
        "payment_received",
        "new_member",
        "contribution_due",
        "reminder",
        "tontine_completed",
        "system",
      ],
      tontine_status: ["active", "completed", "cancelled"],
      transaction_type: [
        "deposit",
        "transfer",
        "contribution",
        "withdrawal",
        "fee",
      ],
      user_role: ["super_admin", "admin", "moderator", "developer", "user"],
    },
  },
} as const

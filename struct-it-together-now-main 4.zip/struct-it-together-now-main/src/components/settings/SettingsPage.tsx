
import { useState } from "react";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { BottomNavigation } from "@/components/layout/BottomNavigation";
import { SettingsNavigation } from "./SettingsNavigation";
import { AccountSettings } from "./AccountSettings";
import { PaymentSettings } from "./PaymentSettings";
import { LanguageSettings } from "./LanguageSettings";
import { ReferralSettings } from "./ReferralSettings";
import { LegalSettings } from "./LegalSettings";
import { LogoutSection } from "@/components/auth/LogoutSection";
import { SecuritySettings } from "./advanced/SecuritySettings";
import { PremiumSettings } from "./advanced/PremiumSettings";
import { useLanguage } from "@/contexts/LanguageContext";
import { CustomThemeCreator } from "./CustomThemeCreator";

type SettingsSection = "account" | "theme" | "language" | "social" | "security" | "payments" | "legal" | "advanced";

interface SettingsPageProps {
  onNavigate: (page: string) => void;
}

export const SettingsPage = ({ onNavigate }: SettingsPageProps) => {
  const { t } = useLanguage();
  const [activeSection, setActiveSection] = useState<SettingsSection>("account");
  const [isThemeCreatorOpen, setIsThemeCreatorOpen] = useState(false);

  const handleApplyTheme = (theme: any) => {
    console.log('Applying theme:', theme);
    setIsThemeCreatorOpen(false);
  };

  const renderSettingsContent = () => {
    switch (activeSection) {
      case "account":
        return (
          <div className="space-y-6">
            <AccountSettings />
            <LogoutSection />
          </div>
        );
      case "payments":
        return <PaymentSettings />;
      case "theme":
        return (
          <CustomThemeCreator 
            onApplyTheme={handleApplyTheme}
            isOpen={isThemeCreatorOpen}
            onClose={() => setIsThemeCreatorOpen(false)}
          />
        );
      case "language":
        return <LanguageSettings />;
      case "social":
        return <ReferralSettings />;
      case "legal":
        return <LegalSettings />;
      case "security":
        return <SecuritySettings />;
      case "advanced":
        return <PremiumSettings />;
      default:
        return (
          <div className="space-y-6">
            <AccountSettings />
            <LogoutSection />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => onNavigate("home")}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            {t('back')}
          </Button>
          <h1 className="text-lg font-semibold text-gray-900">
            {t('settings')}
          </h1>
          <div className="w-16"></div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <SettingsNavigation 
        activeSection={activeSection} 
        onSectionChange={setActiveSection} 
      />

      {/* Content */}
      <div className="max-w-md mx-auto p-4 pb-20">
        {renderSettingsContent()}
      </div>

      {/* Bottom Navigation */}
      <BottomNavigation onNavigate={onNavigate} currentPage="settings" />
    </div>
  );
};

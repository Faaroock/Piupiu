
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Plus, CreditCard, Smartphone, Trash2 } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";

interface PaymentMethod {
  id: string;
  type: 'mobile' | 'card';
  provider: string;
  details: string;
  isDefault: boolean;
}

export const PaymentSettings = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [formType, setFormType] = useState<'mobile' | 'card'>('mobile');
  const [formData, setFormData] = useState({
    provider: '',
    phoneNumber: '',
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: ''
  });

  const mobileProviders = [
    { id: 'mtn', name: 'MTN Money', color: 'bg-yellow-500' },
    { id: 'wave', name: 'Wave', color: 'bg-blue-500' },
    { id: 'moov', name: 'Moov Money', color: 'bg-green-500' },
    { id: 'celtis', name: 'Celtis Cash', color: 'bg-purple-500' }
  ];

  const cardProviders = [
    { id: 'visa', name: 'Visa', color: 'bg-blue-600' },
    { id: 'mastercard', name: 'Mastercard', color: 'bg-red-500' }
  ];

  const handleAddPaymentMethod = () => {
    if (formType === 'mobile' && (!formData.provider || !formData.phoneNumber)) {
      toast({
        title: t("error"),
        description: "Veuillez remplir tous les champs",
        variant: "destructive"
      });
      return;
    }

    if (formType === 'card' && (!formData.provider || !formData.cardNumber || !formData.expiryDate || !formData.cvv || !formData.cardholderName)) {
      toast({
        title: t("error"),
        description: "Veuillez remplir tous les champs",
        variant: "destructive"
      });
      return;
    }

    const newMethod: PaymentMethod = {
      id: Date.now().toString(),
      type: formType,
      provider: formData.provider,
      details: formType === 'mobile' 
        ? formData.phoneNumber 
        : `**** **** **** ${formData.cardNumber.slice(-4)}`,
      isDefault: paymentMethods.length === 0
    };

    setPaymentMethods([...paymentMethods, newMethod]);
    setShowAddForm(false);
    setFormData({
      provider: '',
      phoneNumber: '',
      cardNumber: '',
      expiryDate: '',
      cvv: '',
      cardholderName: ''
    });

    toast({
      title: t("success"),
      description: "Méthode de paiement ajoutée avec succès"
    });
  };

  const removePaymentMethod = (id: string) => {
    setPaymentMethods(paymentMethods.filter(method => method.id !== id));
    toast({
      title: t("success"),
      description: "Méthode de paiement supprimée"
    });
  };

  const getProviderInfo = (provider: string, type: 'mobile' | 'card') => {
    const providers = type === 'mobile' ? mobileProviders : cardProviders;
    return providers.find(p => p.id === provider);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          {t("payment_methods")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Méthodes existantes */}
        {paymentMethods.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-medium">Méthodes configurées</h4>
            {paymentMethods.map((method) => {
              const providerInfo = getProviderInfo(method.provider, method.type);
              return (
                <div key={method.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    {method.type === 'mobile' ? (
                      <Smartphone className="w-5 h-5" />
                    ) : (
                      <CreditCard className="w-5 h-5" />
                    )}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{providerInfo?.name}</span>
                        {method.isDefault && (
                          <Badge variant="default" className="text-xs">Par défaut</Badge>
                        )}
                      </div>
                      <span className="text-sm text-muted-foreground">{method.details}</span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removePaymentMethod(method.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              );
            })}
          </div>
        )}

        {/* Formulaire d'ajout */}
        {!showAddForm ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Button
              variant="outline"
              onClick={() => {
                setFormType('mobile');
                setShowAddForm(true);
              }}
              className="h-16 flex flex-col gap-1"
            >
              <Smartphone className="w-5 h-5" />
              <span>{t("mobile_money")}</span>
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setFormType('card');
                setShowAddForm(true);
              }}
              className="h-16 flex flex-col gap-1"
            >
              <CreditCard className="w-5 h-5" />
              <span>{t("bank_cards")}</span>
            </Button>
          </div>
        ) : (
          <div className="space-y-4 p-4 border rounded-lg">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">
                Ajouter {formType === 'mobile' ? t("mobile_money") : t("bank_cards")}
              </h4>
              <Button variant="ghost" size="sm" onClick={() => setShowAddForm(false)}>
                {t("cancel")}
              </Button>
            </div>

            {formType === 'mobile' ? (
              <div className="space-y-4">
                <div>
                  <Label>Fournisseur</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {mobileProviders.map((provider) => (
                      <Button
                        key={provider.id}
                        variant={formData.provider === provider.id ? "default" : "outline"}
                        onClick={() => setFormData({...formData, provider: provider.id})}
                        className="h-12"
                      >
                        {provider.name}
                      </Button>
                    ))}
                  </div>
                </div>
                <div>
                  <Label htmlFor="phone">{t("phone_number")}</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phoneNumber}
                    onChange={(e) => setFormData({...formData, phoneNumber: e.target.value})}
                    placeholder="+229 XX XX XX XX"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <Label>Type de carte</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {cardProviders.map((provider) => (
                      <Button
                        key={provider.id}
                        variant={formData.provider === provider.id ? "default" : "outline"}
                        onClick={() => setFormData({...formData, provider: provider.id})}
                        className="h-12"
                      >
                        {provider.name}
                      </Button>
                    ))}
                  </div>
                </div>
                <div>
                  <Label htmlFor="cardNumber">{t("card_number")}</Label>
                  <Input
                    id="cardNumber"
                    type="text"
                    value={formData.cardNumber}
                    onChange={(e) => setFormData({...formData, cardNumber: e.target.value})}
                    placeholder="1234 5678 9012 3456"
                    maxLength={19}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expiry">{t("expiry_date")}</Label>
                    <Input
                      id="expiry"
                      type="text"
                      value={formData.expiryDate}
                      onChange={(e) => setFormData({...formData, expiryDate: e.target.value})}
                      placeholder="MM/AA"
                      maxLength={5}
                    />
                  </div>
                  <div>
                    <Label htmlFor="cvv">{t("cvv")}</Label>
                    <Input
                      id="cvv"
                      type="text"
                      value={formData.cvv}
                      onChange={(e) => setFormData({...formData, cvv: e.target.value})}
                      placeholder="123"
                      maxLength={4}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="cardholder">{t("cardholder_name")}</Label>
                  <Input
                    id="cardholder"
                    type="text"
                    value={formData.cardholderName}
                    onChange={(e) => setFormData({...formData, cardholderName: e.target.value})}
                    placeholder="John Doe"
                  />
                </div>
              </div>
            )}

            <Button onClick={handleAddPaymentMethod} className="w-full">
              <Plus className="w-4 h-4 mr-2" />
              {t("add_payment_method")}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};


import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { RefreshCw } from "lucide-react";
import { useState } from "react";

export const AutomationSettings = () => {
  const [autoContribution, setAutoContribution] = useState(false);
  const [autoRejoin, setAutoRejoin] = useState(false);
  const [autoRotation, setAutoRotation] = useState(false);
  const [contributionDay, setContributionDay] = useState("monday");
  const [contributionTime, setContributionTime] = useState("09:00");
  const [rotationDays, setRotationDays] = useState("30");

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <RefreshCw className="w-5 h-5" />
          Automatisation des actions
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Cotisations automatiques */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label htmlFor="auto-contribution">Activer les cotisations automatiques</Label>
            <Switch
              id="auto-contribution"
              checked={autoContribution}
              onCheckedChange={setAutoContribution}
            />
          </div>
          
          {autoContribution && (
            <div className="grid grid-cols-2 gap-3 pl-4 border-l-2 border-primary/20">
              <div>
                <Label className="text-sm">Jour de la semaine</Label>
                <Select value={contributionDay} onValueChange={setContributionDay}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monday">Lundi</SelectItem>
                    <SelectItem value="tuesday">Mardi</SelectItem>
                    <SelectItem value="wednesday">Mercredi</SelectItem>
                    <SelectItem value="thursday">Jeudi</SelectItem>
                    <SelectItem value="friday">Vendredi</SelectItem>
                    <SelectItem value="saturday">Samedi</SelectItem>
                    <SelectItem value="sunday">Dimanche</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-sm">Heure</Label>
                <Input
                  type="time"
                  value={contributionTime}
                  onChange={(e) => setContributionTime(e.target.value)}
                />
              </div>
            </div>
          )}
        </div>

        {/* Retour automatique */}
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="auto-rejoin">Retour automatique dans une tontine quittée</Label>
            <p className="text-sm text-muted-foreground">Rejoindre automatiquement si une place se libère</p>
          </div>
          <Switch
            id="auto-rejoin"
            checked={autoRejoin}
            onCheckedChange={setAutoRejoin}
          />
        </div>

        {/* Rotation automatique */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="auto-rotation">Rotation automatique des tontines similaires</Label>
              <p className="text-sm text-muted-foreground">Relancer automatiquement des tontines du même type</p>
            </div>
            <Switch
              id="auto-rotation"
              checked={autoRotation}
              onCheckedChange={setAutoRotation}
            />
          </div>
          
          {autoRotation && (
            <div className="pl-4 border-l-2 border-primary/20">
              <Label className="text-sm">Relancer tous les (jours)</Label>
              <Input
                type="number"
                value={rotationDays}
                onChange={(e) => setRotationDays(e.target.value)}
                placeholder="30"
                className="w-20"
              />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};


import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { BarChart3, Download } from "lucide-react";
import { useState } from "react";

export const DisplaySettings = () => {
  const [balanceMode, setBalanceMode] = useState("exact");
  const [displayPeriod, setDisplayPeriod] = useState("month");
  const [detailedReports, setDetailedReports] = useState(false);
  const [performanceTracking, setPerformanceTracking] = useState(false);

  const handleDownloadReport = () => {
    console.log("Téléchargement du rapport mensuel...");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <BarChart3 className="w-5 h-5" />
          Modes d'affichage / Statistiques
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Mode d'affichage du solde */}
        <div>
          <Label className="text-sm font-medium mb-3 block">Mode d'affichage du solde</Label>
          <Select value={balanceMode} onValueChange={setBalanceMode}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="exact">Montant exact</SelectItem>
              <SelectItem value="rounded">Montant arrondi</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Période d'affichage */}
        <div>
          <Label className="text-sm font-medium mb-3 block">Période d'affichage</Label>
          <Select value={displayPeriod} onValueChange={setDisplayPeriod}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Par semaine</SelectItem>
              <SelectItem value="month">Par mois</SelectItem>
              <SelectItem value="quarter">Par trimestre</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Rapports détaillés */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="detailed-reports">Rapports détaillés</Label>
              <p className="text-sm text-muted-foreground">PDF ou résumé mensuel</p>
            </div>
            <Switch
              id="detailed-reports"
              checked={detailedReports}
              onCheckedChange={setDetailedReports}
            />
          </div>
          
          {detailedReports && (
            <div className="pl-4 border-l-2 border-primary/20">
              <Button onClick={handleDownloadReport} variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Télécharger le rapport mensuel
              </Button>
            </div>
          )}
        </div>

        {/* Suivi de performance */}
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="performance-tracking">Suivi de performance personnelle</Label>
            <p className="text-sm text-muted-foreground">Graphiques privés de cotisations, retards, gains, pertes</p>
          </div>
          <Switch
            id="performance-tracking"
            checked={performanceTracking}
            onCheckedChange={setPerformanceTracking}
          />
        </div>
      </CardContent>
    </Card>
  );
};

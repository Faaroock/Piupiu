
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, UserCheck, Vote, MessageSquare } from "lucide-react";
import { useState } from "react";

export const CommunitySettings = () => {
  const [privateNetwork, setPrivateNetwork] = useState(false);
  const [addModerators, setAddModerators] = useState(false);
  const [democraticVoting, setDemocraticVoting] = useState(false);
  const [miniForum, setMiniForum] = useState(false);
  const [voteThreshold, setVoteThreshold] = useState("70");
  const [networkName, setNetworkName] = useState("");

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          Interactions communautaires avancées
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Réseau privé */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="private-network">Réseau privé de tontine</Label>
              <p className="text-sm text-muted-foreground">Accès sur invitation uniquement</p>
            </div>
            <Switch
              id="private-network"
              checked={privateNetwork}
              onCheckedChange={setPrivateNetwork}
            />
          </div>
          
          {privateNetwork && (
            <div className="pl-4 border-l-2 border-primary/20">
              <Label className="text-sm">Nom du réseau</Label>
              <Input
                value={networkName}
                onChange={(e) => setNetworkName(e.target.value)}
                placeholder="Mon réseau de confiance"
              />
            </div>
          )}
        </div>

        {/* Modérateurs */}
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="add-moderators">Ajouter des modérateurs</Label>
            <p className="text-sm text-muted-foreground">À une tontine ou groupe</p>
          </div>
          <Switch
            id="add-moderators"
            checked={addModerators}
            onCheckedChange={setAddModerators}
          />
        </div>

        {/* Vote démocratique */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="democratic-voting">Vote démocratique</Label>
              <p className="text-sm text-muted-foreground">Ex: 70% doivent valider un retrait exceptionnel</p>
            </div>
            <Switch
              id="democratic-voting"
              checked={democraticVoting}
              onCheckedChange={setDemocraticVoting}
            />
          </div>
          
          {democraticVoting && (
            <div className="pl-4 border-l-2 border-primary/20">
              <Label className="text-sm">Seuil de validation (%)</Label>
              <Select value={voteThreshold} onValueChange={setVoteThreshold}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="50">50%</SelectItem>
                  <SelectItem value="60">60%</SelectItem>
                  <SelectItem value="70">70%</SelectItem>
                  <SelectItem value="80">80%</SelectItem>
                  <SelectItem value="90">90%</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        {/* Mini-forum */}
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="mini-forum">Mini-forum</Label>
            <p className="text-sm text-muted-foreground">Mur de discussion entre membres d'une tontine</p>
          </div>
          <Switch
            id="mini-forum"
            checked={miniForum}
            onCheckedChange={setMiniForum}
          />
        </div>
      </CardContent>
    </Card>
  );
};


import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Gift, Trophy, Target, Sparkles } from "lucide-react";
import { useState } from "react";

export const PremiumSettings = () => {
  const [internalLottery, setInternalLottery] = useState(false);
  const [goalGallery, setGoalGallery] = useState(false);
  const [privateProgress, setPrivateProgress] = useState(false);
  const [dreamGoal, setDreamGoal] = useState("");

  const mockAchievements = [
    { goal: "Moto Yamaha", amount: "500,000 F", achieved: true },
    { goal: "Terrain 500m²", amount: "2,500,000 F", achieved: false },
    { goal: "Stock de Maïs", amount: "150,000 F", achieved: true }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5" />
          Expériences Premium ou Bonus
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Tirages internes */}
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="internal-lottery">Tirages internes</Label>
            <p className="text-sm text-muted-foreground">Réservés aux cotiseurs actifs</p>
          </div>
          <Switch
            id="internal-lottery"
            checked={internalLottery}
            onCheckedChange={setInternalLottery}
          />
        </div>

        {/* Galerie des objectifs */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="goal-gallery">Galerie des objectifs atteints</Label>
              <p className="text-sm text-muted-foreground">Inspiration communautaire</p>
            </div>
            <Switch
              id="goal-gallery"
              checked={goalGallery}
              onCheckedChange={setGoalGallery}
            />
          </div>
          
          {goalGallery && (
            <div className="pl-4 border-l-2 border-primary/20 space-y-2">
              {mockAchievements.map((achievement, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-muted rounded-lg">
                  <div className="flex items-center gap-2">
                    <Trophy className="w-4 h-4" />
                    <div>
                      <p className="text-sm font-medium">{achievement.goal}</p>
                      <p className="text-xs text-muted-foreground">{achievement.amount}</p>
                    </div>
                  </div>
                  <Badge variant={achievement.achieved ? "default" : "secondary"}>
                    {achievement.achieved ? "Atteint" : "En cours"}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Suivi privé de progrès */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="private-progress">Suivi privé de progrès</Label>
              <p className="text-sm text-muted-foreground">Sur vos propres rêves (Moto, Maïs, Terrain)</p>
            </div>
            <Switch
              id="private-progress"
              checked={privateProgress}
              onCheckedChange={setPrivateProgress}
            />
          </div>
          
          {privateProgress && (
            <div className="pl-4 border-l-2 border-primary/20">
              <Label className="text-sm">Mon objectif de rêve</Label>
              <Input
                value={dreamGoal}
                onChange={(e) => setDreamGoal(e.target.value)}
                placeholder="Ex: Ma propre boutique"
              />
            </div>
          )}
        </div>

        {/* Actions Premium */}
        <div className="flex gap-2 flex-wrap">
          <Button variant="outline" size="sm">
            <Gift className="w-4 h-4 mr-2" />
            Participer au tirage
          </Button>
          <Button variant="outline" size="sm">
            <Target className="w-4 h-4 mr-2" />
            Voir mes objectifs
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

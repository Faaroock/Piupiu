
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Recycle } from "lucide-react";
import { useState } from "react";

export const SmartRecyclingSettings = () => {
  const [autoReuseGains, setAutoReuseGains] = useState(false);
  const [reinvestReferrals, setReinvestReferrals] = useState(false);
  const [autoTransferToGoal, setAutoTransferToGoal] = useState(false);
  const [selectedTontineType, setSelectedTontineType] = useState("");
  const [goalAmount, setGoalAmount] = useState("");

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Recycle className="w-5 h-5" />
          Recyclage intelligent
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Réutiliser les gains */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="auto-reuse-gains">Réutiliser automatiquement mes gains</Label>
              <p className="text-sm text-muted-foreground">Dans une autre tontine du même type</p>
            </div>
            <Switch
              id="auto-reuse-gains"
              checked={autoReuseGains}
              onCheckedChange={setAutoReuseGains}
            />
          </div>
          
          {autoReuseGains && (
            <div className="pl-4 border-l-2 border-primary/20">
              <Label className="text-sm">Type de tontine préféré</Label>
              <Select value={selectedTontineType} onValueChange={setSelectedTontineType}>
                <SelectTrigger>
                  <SelectValue placeholder="Choisir un type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="wedding">Mariage</SelectItem>
                  <SelectItem value="business">Commerce</SelectItem>
                  <SelectItem value="education">Éducation</SelectItem>
                  <SelectItem value="agriculture">Agriculture</SelectItem>
                  <SelectItem value="savings">Épargne libre</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        {/* Réinvestir les bénéfices de parrainage */}
        <div className="flex items-center justify-between">
          <div>
            <Label htmlFor="reinvest-referrals">Réinvestir mes bénéfices de parrainage</Label>
            <p className="text-sm text-muted-foreground">Dans une tontine communautaire</p>
          </div>
          <Switch
            id="reinvest-referrals"
            checked={reinvestReferrals}
            onCheckedChange={setReinvestReferrals}
          />
        </div>

        {/* Transfert automatique vers objectif */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="auto-transfer-goal">Transférer automatiquement vers un objectif</Label>
              <p className="text-sm text-muted-foreground">Mon solde disponible vers un but précis</p>
            </div>
            <Switch
              id="auto-transfer-goal"
              checked={autoTransferToGoal}
              onCheckedChange={setAutoTransferToGoal}
            />
          </div>
          
          {autoTransferToGoal && (
            <div className="pl-4 border-l-2 border-primary/20">
              <Label className="text-sm">Montant objectif (FCFA)</Label>
              <Input
                type="number"
                value={goalAmount}
                onChange={(e) => setGoalAmount(e.target.value)}
                placeholder="100000"
              />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

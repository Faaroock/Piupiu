
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Paintbrush, Upload } from "lucide-react";
import { useState } from "react";

export const DeepCustomizationSettings = () => {
  const [appTheme, setAppTheme] = useState("light");
  const [customIcon, setCustomIcon] = useState(false);
  const [customRules, setCustomRules] = useState(false);
  const [publicAlias, setPublicAlias] = useState(false);
  const [aliasName, setAliasName] = useState("");
  const [ruleName, setRuleName] = useState("");

  const handleIconUpload = () => {
    console.log("Upload d'icône personnalisée...");
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Paintbrush className="w-5 h-5" />
          Personnalisation profonde
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Thème de l'app */}
        <div>
          <Label className="text-sm font-medium mb-3 block">Thème de l'application</Label>
          <Select value={appTheme} onValueChange={setAppTheme}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="light">Clair</SelectItem>
              <SelectItem value="dark">Sombre</SelectItem>
              <SelectItem value="silver">Argenté</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Icône personnalisée */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="custom-icon">Icône personnalisée</Label>
              <p className="text-sm text-muted-foreground">Uniquement sur Android</p>
            </div>
            <Switch
              id="custom-icon"
              checked={customIcon}
              onCheckedChange={setCustomIcon}
            />
          </div>
          
          {customIcon && (
            <div className="pl-4 border-l-2 border-primary/20">
              <Button onClick={handleIconUpload} variant="outline" size="sm">
                <Upload className="w-4 h-4 mr-2" />
                Choisir une icône
              </Button>
              <p className="text-xs text-muted-foreground mt-1">Format PNG, 512x512px maximum</p>
            </div>
          )}
        </div>

        {/* Règles personnalisées */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="custom-rules">Nommer mes propres règles de tontine</Label>
              <p className="text-sm text-muted-foreground">Ex: "Règle d'Or", "Anti-retard"</p>
            </div>
            <Switch
              id="custom-rules"
              checked={customRules}
              onCheckedChange={setCustomRules}
            />
          </div>
          
          {customRules && (
            <div className="pl-4 border-l-2 border-primary/20">
              <Label className="text-sm">Nom de ma règle</Label>
              <Input
                value={ruleName}
                onChange={(e) => setRuleName(e.target.value)}
                placeholder="Ma règle personnalisée"
              />
            </div>
          )}
        </div>

        {/* Pseudo alias public */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <Label htmlFor="public-alias">Pseudo alias public</Label>
              <p className="text-sm text-muted-foreground">Visible au lieu de votre vrai nom</p>
            </div>
            <Switch
              id="public-alias"
              checked={publicAlias}
              onCheckedChange={setPublicAlias}
            />
          </div>
          
          {publicAlias && (
            <div className="pl-4 border-l-2 border-primary/20">
              <Label className="text-sm">Votre pseudo</Label>
              <Input
                value={aliasName}
                onChange={(e) => setAliasName(e.target.value)}
                placeholder="MonPseudo123"
              />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};


import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Shield, Key, Smartphone, AlertTriangle } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { ConnectionHistory } from "../ConnectionHistory";

export const SecuritySettings = () => {
  const { t } = useLanguage();

  return (
    <div className="space-y-6">
      {/* Historique des connexions */}
      <ConnectionHistory />
      
      {/* Configuration PIN */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Key className="w-5 h-5" />
            {t('pin_access')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            {t('pin_access_description')}
          </p>
          
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">{t('pin_access')}</span>
            <Switch />
          </div>
          
          <Button variant="outline" className="w-full">
            <Key className="w-4 h-4 mr-2" />
            Configurer le PIN
          </Button>
        </CardContent>
      </Card>

      {/* Authentification à deux facteurs */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            Authentification à deux facteurs
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-muted-foreground">
            Ajoutez une couche de sécurité supplémentaire à votre compte
          </p>
          
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">2FA activé</span>
            <Switch />
          </div>
          
          <Button variant="outline" className="w-full">
            <Smartphone className="w-4 h-4 mr-2" />
            Configurer 2FA
          </Button>
        </CardContent>
      </Card>

      {/* Alertes de sécurité */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            Alertes de sécurité
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Notifications de connexion</span>
            <Switch defaultChecked />
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Alertes de nouveau appareil</span>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

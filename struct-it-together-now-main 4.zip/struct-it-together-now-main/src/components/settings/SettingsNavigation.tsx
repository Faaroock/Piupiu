
import { Button } from "@/components/ui/button";
import { User, Shield, Globe, Palette, Users, Settings, CreditCard, FileText } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

type SettingsSection = "account" | "theme" | "language" | "social" | "security" | "payments" | "legal" | "advanced";

interface SettingsNavigationProps {
  activeSection: SettingsSection;
  onSectionChange: (section: SettingsSection) => void;
}

export const SettingsNavigation = ({ activeSection, onSectionChange }: SettingsNavigationProps) => {
  const { t } = useLanguage();

  const sections = [
    { id: "account" as const, label: t("account"), icon: User },
    { id: "payments" as const, label: t("payments"), icon: CreditCard },
    { id: "theme" as const, label: t("theme"), icon: Palette },
    { id: "language" as const, label: t("language"), icon: Globe },
    { id: "social" as const, label: t("social"), icon: Users },
    { id: "legal" as const, label: "Règles & Confidentialité", icon: FileText },
    { id: "security" as const, label: t("security"), icon: Shield },
    { id: "advanced" as const, label: t("advanced"), icon: Settings },
  ];

  return (
    <div className="bg-white border-b border-border">
      <div className="flex overflow-x-auto scrollbar-hide px-4 py-2">
        {sections.map((section) => {
          const IconComponent = section.icon;
          const isActive = activeSection === section.id;
          return (
            <Button
              key={section.id}
              variant={isActive ? "default" : "ghost"}
              size="sm"
              onClick={() => onSectionChange(section.id)}
              className={`
                flex-shrink-0 mx-1 px-4 py-3 h-auto flex items-center gap-2 min-w-fit rounded-lg
                transition-all duration-200 hover:scale-105
                ${isActive 
                  ? "bg-primary text-primary-foreground shadow-md" 
                  : "hover:bg-slate-100 text-slate-600 hover:text-slate-800"
                }
              `}
            >
              <IconComponent className="w-4 h-4" />
              <span className="text-sm font-medium">{section.label}</span>
            </Button>
          );
        })}
      </div>
    </div>
  );
};

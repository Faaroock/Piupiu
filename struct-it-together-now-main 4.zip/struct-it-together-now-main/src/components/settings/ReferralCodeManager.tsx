
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Share2, Copy, Edit3, Check, X, RefreshCw, Users } from "lucide-react";
import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";

export const ReferralCodeManager = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [currentCode, setCurrentCode] = useState("R7DZPL93");
  const [customCode, setCustomCode] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [isChecking, setIsChecking] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [codeStatus, setCodeStatus] = useState<"" | "available" | "taken">("");
  const [totalReferrals, setTotalReferrals] = useState(5);
  const [totalEarnings, setTotalEarnings] = useState(12500);

  const handleCheckCode = async () => {
    if (!customCode || customCode.length < 4) {
      toast({
        title: "⚠️ Attention",
        description: "Le code doit contenir au moins 4 caractères",
        variant: "destructive"
      });
      return;
    }

    setIsChecking(true);
    setCodeStatus("");

    try {
      // Simuler la vérification d'unicité avec l'API
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simulation: vérification réelle contre la base de données
      const isAvailable = !["POPULAR", "ADMIN", "TEST", "DEMO"].includes(customCode.toUpperCase());
      setCodeStatus(isAvailable ? "available" : "taken");
      
    } catch (error) {
      toast({
        title: t("error"),
        description: "Erreur lors de la vérification. Veuillez réessayer.",
        variant: "destructive"
      });
    } finally {
      setIsChecking(false);
    }
  };

  const handleSaveCode = async () => {
    if (codeStatus !== "available") {
      toast({
        title: "⚠️ Attention",
        description: "Veuillez d'abord vérifier que le code est disponible",
        variant: "destructive"
      });
      return;
    }

    try {
      // Simuler la sauvegarde en base de données
      await new Promise(resolve => setTimeout(resolve, 1200));
      
      setCurrentCode(customCode.toUpperCase());
      setIsEditing(false);
      setCustomCode("");
      setCodeStatus("");
      
      toast({
        title: t("success"),
        description: "Code de parrainage mis à jour avec succès !"
      });
      
    } catch (error) {
      toast({
        title: t("error"),
        description: "Erreur lors de la sauvegarde. Veuillez réessayer.",
        variant: "destructive"
      });
    }
  };

  const handleGenerateNewCode = async () => {
    setIsGenerating(true);
    
    try {
      // Simuler la génération d'un nouveau code unique
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const newCode = generateRandomCode();
      setCurrentCode(newCode);
      
      toast({
        title: t("success"),
        description: `Nouveau code généré : ${newCode}`
      });
      
    } catch (error) {
      toast({
        title: t("error"),
        description: "Erreur lors de la génération. Veuillez réessayer.",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const generateRandomCode = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 8; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };

  const handleCopyCode = async () => {
    try {
      await navigator.clipboard.writeText(currentCode);
      toast({
        title: "📋 Copié",
        description: "Code copié dans le presse-papier !"
      });
    } catch (error) {
      toast({
        title: t("error"),
        description: "Erreur lors de la copie",
        variant: "destructive"
      });
    }
  };

  const handleShare = async () => {
    const shareText = `Rejoins-moi sur NONRU avec mon code de parrainage : ${currentCode}\n\nTélécharge l'app et économise avec les tontines !`;
    const shareUrl = `https://nonru.app/signup?ref=${currentCode}`;
    
    try {
      // Utiliser l'API Web Share si disponible (natif mobile)
      if (navigator.share) {
        await navigator.share({
          title: 'Rejoins NONRU !',
          text: shareText,
          url: shareUrl,
        });
        
        toast({
          title: "📱 Partagé",
          description: "Le lien a été partagé avec succès !"
        });
      } else {
        // Fallback: copier dans le presse-papier
        await navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
        toast({
          title: "📋 Copié",
          description: "Message de parrainage copié ! Partage-le avec tes amis !"
        });
      }
    } catch (error) {
      console.error('Erreur lors du partage:', error);
      
      // Fallback final: copier juste le code
      try {
        await navigator.clipboard.writeText(shareText);
        toast({
          title: "📋 Copié",
          description: "Message copié dans le presse-papier"
        });
      } catch (clipboardError) {
        toast({
          title: t("error"),
          description: "Impossible de partager. Copiez manuellement votre code.",
          variant: "destructive"
        });
      }
    }
  };

  return (
    <div className="space-y-6">
      {/* Statistiques de parrainage */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              <div>
                <p className="text-2xl font-bold">{totalReferrals}</p>
                <p className="text-sm text-muted-foreground">Parrainages réussis</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 bg-green-500 rounded-full"></div>
              <div>
                <p className="text-2xl font-bold">{totalEarnings.toLocaleString()} F</p>
                <p className="text-sm text-muted-foreground">Gains totaux</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            🎁 {t("referral_code")}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Code actuel */}
          <div className="text-center p-6 bg-primary/5 border border-primary/20 rounded-lg">
            <div className="text-sm text-muted-foreground mb-2">Votre code actuel</div>
            <div className="text-3xl font-bold text-primary mb-4 font-mono tracking-wider">
              {currentCode}
            </div>
            
            <div className="flex gap-2 justify-center">
              <Button onClick={handleCopyCode} variant="outline" size="sm">
                <Copy className="w-4 h-4 mr-2" />
                {t("copy")}
              </Button>
              <Button onClick={handleShare} size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                {t("share")}
              </Button>
            </div>
          </div>

          {/* Personnalisation */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Personnaliser mon code</h4>
              {!isEditing && (
                <Button onClick={() => setIsEditing(true)} variant="outline" size="sm">
                  <Edit3 className="w-4 h-4 mr-2" />
                  {t("edit")}
                </Button>
              )}
            </div>

            {isEditing && (
              <div className="space-y-4 p-4 border rounded-lg bg-muted/30">
                <div>
                  <label className="text-sm font-medium mb-2 block">
                    Nouveau code personnalisé
                  </label>
                  <Input
                    placeholder="Ex: ADJOBO95, MONNOM24..."
                    value={customCode}
                    onChange={(e) => {
                      const value = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
                      setCustomCode(value);
                      setCodeStatus("");
                    }}
                    maxLength={12}
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    4-12 caractères, lettres et chiffres uniquement
                  </p>
                </div>

                {customCode.length >= 4 && (
                  <div className="flex gap-2">
                    <Button 
                      onClick={handleCheckCode}
                      disabled={isChecking}
                      variant="outline"
                      size="sm"
                    >
                      {isChecking ? (
                        <>
                          <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-current mr-2"></div>
                          Vérification...
                        </>
                      ) : (
                        "Vérifier disponibilité"
                      )}
                    </Button>

                    {codeStatus === "available" && (
                      <Button onClick={handleSaveCode} size="sm">
                        <Check className="w-4 h-4 mr-2" />
                        Enregistrer
                      </Button>
                    )}

                    <Button 
                      onClick={() => {
                        setIsEditing(false);
                        setCustomCode("");
                        setCodeStatus("");
                      }}
                      variant="ghost" 
                      size="sm"
                    >
                      <X className="w-4 h-4 mr-2" />
                      {t("cancel")}
                    </Button>
                  </div>
                )}

                {codeStatus === "available" && (
                  <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">
                    <Check className="w-3 h-3 mr-1" />
                    Code disponible !
                  </Badge>
                )}

                {codeStatus === "taken" && (
                  <Badge variant="destructive">
                    <X className="w-3 h-3 mr-1" />
                    Code déjà utilisé
                  </Badge>
                )}
              </div>
            )}

            {/* Générer un nouveau code */}
            <div className="pt-4 border-t">
              <Button 
                onClick={handleGenerateNewCode}
                disabled={isGenerating}
                variant="outline"
                className="w-full"
              >
                {isGenerating ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current mr-2"></div>
                    Génération...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    {t("generate_new")}
                  </>
                )}
              </Button>
            </div>
          </div>

          {/* Informations */}
          <div className="text-xs text-muted-foreground p-3 bg-muted rounded-lg">
            <strong>💡 Astuce :</strong> Utilisez un code facile à retenir comme votre nom + année de naissance. 
            Partagez-le avec vos proches pour qu'ils bénéficient de vos recommandations !
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

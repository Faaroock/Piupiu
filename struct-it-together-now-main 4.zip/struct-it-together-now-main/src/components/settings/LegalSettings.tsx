
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Shield, Mail, Phone, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";

export const LegalSettings = () => {
  const { t } = useLanguage();

  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <FileText className="w-8 h-8 text-blue-600" />
        </div>
        <h2 className="text-xl font-semibold text-foreground">Règles & Confidentialité</h2>
        <p className="text-muted-foreground text-sm">
          Consultez nos documents légaux et conditions d'utilisation
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-primary" />
            Documents légaux
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button asChild variant="outline" className="w-full justify-between">
            <Link to="/terms" target="_blank">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Conditions d'Utilisation
              </div>
              <ExternalLink className="w-4 h-4" />
            </Link>
          </Button>
          
          <Button asChild variant="outline" className="w-full justify-between">
            <Link to="/privacy" target="_blank">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                Politique de Confidentialité
              </div>
              <ExternalLink className="w-4 h-4" />
            </Link>
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-green-50 border-green-200">
        <CardHeader>
          <CardTitle className="text-green-800">🍪 Cookies et confidentialité</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-green-700 text-sm leading-relaxed">
            NONRU utilise uniquement des cookies essentiels pour le fonctionnement du site (authentification, sécurité, session utilisateur). 
            <strong> Aucun cookie marketing, publicitaire ou de tracking tiers n'est utilisé.</strong>
          </p>
          <p className="text-green-700 text-sm leading-relaxed mt-2">
            Vous pouvez gérer vos préférences de cookies directement dans votre navigateur.
          </p>
        </CardContent>
      </Card>

      <Card className="bg-primary/5 border-primary/20">
        <CardHeader>
          <CardTitle className="text-primary">Support & Contact</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-sm mb-4">
            Pour toute question concernant nos conditions d'utilisation, notre politique de confidentialité ou vos données personnelles :
          </p>
          <div className="space-y-3">
            <Button asChild variant="outline" size="sm" className="w-full justify-start">
              <a href="mailto:faaroockt@gmail.com">
                <Mail className="w-4 h-4 mr-2" />
                faaroockt@gmail.com
              </a>
            </Button>
            <Button asChild variant="outline" size="sm" className="w-full justify-start">
              <a href="tel:+22901572184">
                <Phone className="w-4 h-4 mr-2" />
                +229 01 57 21 72 84
              </a>
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-blue-50 border-blue-200">
        <CardHeader>
          <CardTitle className="text-blue-800">Vos droits</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-blue-700 text-sm mb-3">
            Vous disposez des droits suivants concernant vos données personnelles :
          </p>
          <ul className="space-y-1 text-blue-700 text-sm">
            <li>• Droit d'accès à vos données</li>
            <li>• Droit de rectification</li>
            <li>• Droit à l'effacement (droit à l'oubli)</li>
            <li>• Droit à la portabilité de vos données</li>
            <li>• Droit de limiter le traitement</li>
          </ul>
          <p className="text-blue-700 text-sm mt-3">
            Pour exercer ces droits, contactez-nous à l'adresse email ci-dessus.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

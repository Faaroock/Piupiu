
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Palette, X, Sparkles } from "lucide-react";
import { predefinedThemes } from "@/lib/themes";
import { useTheme } from "@/contexts/ThemeContext";
import { useLanguage } from "@/contexts/LanguageContext";

interface CustomThemeCreatorProps {
  onApplyTheme: (customTheme: CustomTheme) => void;
  isOpen: boolean;
  onClose: () => void;
}

export interface CustomTheme {
  name: string;
  colors: {
    primary: string;
    secondary: string;
    background: string;
    foreground: string;
    accent: string;
  };
  cssVars: {
    [key: string]: string;
  };
}

export const CustomThemeCreator = ({ onApplyTheme, isOpen, onClose }: CustomThemeCreatorProps) => {
  const { customTheme } = useTheme();
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<"predefined" | "custom">("predefined");
  const [customColors, setCustomColors] = useState({
    primary: "#00B894",
    secondary: "#fab005", 
    background: "#ffffff",
    foreground: "#222222",
    accent: "#3498db"
  });

  const handleColorChange = (colorKey: string, value: string) => {
    setCustomColors(prev => ({
      ...prev,
      [colorKey]: value
    }));
  };

  const convertHexToHsl = (hex: string): string => {
    const r = parseInt(hex.slice(1, 3), 16) / 255;
    const g = parseInt(hex.slice(3, 5), 16) / 255;
    const b = parseInt(hex.slice(5, 7), 16) / 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);

      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }

    return `${Math.round(h * 360)} ${Math.round(s * 100)}% ${Math.round(l * 100)}%`;
  };

  const applyPredefinedTheme = (theme: any) => {
    const customTheme: CustomTheme = {
      name: theme.name,
      colors: theme.colors,
      cssVars: theme.cssVars
    };
    onApplyTheme(customTheme);
    onClose();
  };

  const applyCustomTheme = () => {
    const customTheme: CustomTheme = {
      name: t("my_custom_theme") || "Mon thème personnalisé",
      colors: customColors,
      cssVars: {
        "--primary": convertHexToHsl(customColors.primary),
        "--secondary": convertHexToHsl(customColors.secondary),
        "--background": convertHexToHsl(customColors.background),
        "--foreground": convertHexToHsl(customColors.foreground),
        "--accent": convertHexToHsl(customColors.accent),
      }
    };

    onApplyTheme(customTheme);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <Card className="bg-card border-border mt-4">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-foreground">
            <Palette className="w-5 h-5" />
            {t("themes_customization") || "Thèmes et personnalisation"}
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Navigation des onglets */}
        <div className="flex space-x-1 bg-muted p-1 rounded-lg">
          <Button
            variant={activeTab === "predefined" ? "default" : "ghost"}
            size="sm"
            onClick={() => setActiveTab("predefined")}
            className="flex-1"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            {t("predefined_themes") || "Thèmes prédéfinis"}
          </Button>
          <Button
            variant={activeTab === "custom" ? "default" : "ghost"}
            size="sm"
            onClick={() => setActiveTab("custom")}
            className="flex-1"
          >
            <Palette className="w-4 h-4 mr-2" />
            {t("custom") || "Personnalisé"}
          </Button>
        </div>

        {/* Thème actuel */}
        {customTheme && (
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center gap-3">
              <Palette className="w-5 h-5 text-blue-600" />
              <div>
                <div className="font-medium text-blue-700">{t("current_theme") || "Thème actuel"}</div>
                <div className="text-sm text-blue-600">{customTheme.name}</div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "predefined" ? (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {t("choose_predefined_theme") || "Choisissez parmi nos thèmes soigneusement conçus"}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {predefinedThemes.map((theme) => (
                <Card key={theme.name} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4" onClick={() => applyPredefinedTheme(theme)}>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <h4 className="font-medium">{theme.name}</h4>
                        <div className="flex gap-1">
                          <div
                            className="w-4 h-4 rounded-full border border-border"
                            style={{ backgroundColor: theme.colors.primary }}
                          />
                          <div
                            className="w-4 h-4 rounded-full border border-border"
                            style={{ backgroundColor: theme.colors.secondary }}
                          />
                          <div
                            className="w-4 h-4 rounded-full border border-border"
                            style={{ backgroundColor: theme.colors.accent }}
                          />
                        </div>
                      </div>
                      <div className="text-xs text-muted-foreground space-y-1">
                        <div className="flex justify-between">
                          <span>{t("primary") || "Primaire"}:</span>
                          <span>{theme.colors.primary}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>{t("secondary") || "Secondaire"}:</span>
                          <span>{theme.colors.secondary}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {t("create_custom_palette") || "Créez votre propre palette de couleurs"}
            </p>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  {t("primary_color") || "Couleur primaire"}
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={customColors.primary}
                    onChange={(e) => handleColorChange('primary', e.target.value)}
                    className="w-12 h-8 rounded border border-border cursor-pointer"
                  />
                  <span className="text-sm text-muted-foreground">{customColors.primary}</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  {t("secondary_color") || "Couleur secondaire"}
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={customColors.secondary}
                    onChange={(e) => handleColorChange('secondary', e.target.value)}
                    className="w-12 h-8 rounded border border-border cursor-pointer"
                  />
                  <span className="text-sm text-muted-foreground">{customColors.secondary}</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  {t("background_color") || "Couleur de fond"}
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={customColors.background}
                    onChange={(e) => handleColorChange('background', e.target.value)}
                    className="w-12 h-8 rounded border border-border cursor-pointer"
                  />
                  <span className="text-sm text-muted-foreground">{customColors.background}</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  {t("text_color") || "Couleur des textes"}
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={customColors.foreground}
                    onChange={(e) => handleColorChange('foreground', e.target.value)}
                    className="w-12 h-8 rounded border border-border cursor-pointer"
                  />
                  <span className="text-sm text-muted-foreground">{customColors.foreground}</span>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  {t("accent_color") || "Couleur d'accent"}
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={customColors.accent}
                    onChange={(e) => handleColorChange('accent', e.target.value)}
                    className="w-12 h-8 rounded border border-border cursor-pointer"
                  />
                  <span className="text-sm text-muted-foreground">{customColors.accent}</span>
                </div>
              </div>
            </div>

            {/* Aperçu du thème */}
            <div>
              <h4 className="text-sm font-medium text-foreground mb-2">{t("preview") || "Aperçu"}</h4>
              <div className="border border-border rounded-lg p-4" style={{
                backgroundColor: customColors.background,
                color: customColors.foreground
              }}>
                <div className="space-y-3">
                  <Button style={{ backgroundColor: customColors.primary }} className="w-full text-white">
                    {t("primary_button") || "Bouton principal"}
                  </Button>
                  <p style={{ color: customColors.foreground }}>
                    {t("sample_text") || "Exemple de texte avec cette couleur"}
                  </p>
                  <Badge style={{ backgroundColor: customColors.accent }} className="text-white">
                    {t("accent_badge") || "Badge d'accent"}
                  </Badge>
                </div>
              </div>
            </div>

            <Button onClick={applyCustomTheme} className="w-full">
              {t("apply_theme") || "Appliquer mon thème"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

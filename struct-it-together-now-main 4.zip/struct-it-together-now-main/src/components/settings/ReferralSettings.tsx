
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Gift } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { ReferralSystemCard } from "@/components/referral/ReferralSystemCard";
import { ReferralEarningsCard } from "@/components/referral/ReferralEarningsCard";
import { useReferralSystem } from "@/hooks/useReferralSystem";
import { useReferralEarnings } from "@/hooks/useReferralEarnings";

export const ReferralSettings = () => {
  const { t } = useLanguage();
  const { referralData, loading: referralLoading } = useReferralSystem();
  const { earnings, totalEarnings, loading: earningsLoading } = useReferralEarnings();

  if (referralLoading || earningsLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-32 bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            {t('referral_program') || 'Programme de parrainage'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-blue-50 p-4 rounded-lg mb-4">
            <div className="flex items-center gap-2 mb-2">
              <Gift className="w-5 h-5 text-blue-600" />
              <h3 className="font-medium text-blue-900">
                {t('how_it_works') || 'Comment ça marche'}
              </h3>
            </div>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• {t('referral_step_1') || 'Invitez vos amis à rejoindre NONRU'}</li>
              <li>• {t('referral_step_2') || 'Ils créent une tontine et la complètent'}</li>
              <li>• {t('referral_step_3') || 'Vous gagnez 1% de leurs contributions totales'}</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <ReferralSystemCard />
      
      <ReferralEarningsCard 
        earnings={earnings} 
        totalEarnings={totalEarnings} 
      />
    </div>
  );
};

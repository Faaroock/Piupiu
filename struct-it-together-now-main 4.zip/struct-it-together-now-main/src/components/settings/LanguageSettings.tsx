
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, Globe } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

export const LanguageSettings = () => {
  const { language, setLanguage, t, availableLanguages } = useLanguage();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Globe className="w-5 h-5" />
          {t('language')}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          {t('change_interface_language')}
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {availableLanguages.map((lang) => (
            <Button
              key={lang.code}
              variant={language === lang.code ? "default" : "outline"}
              className="w-full justify-between h-auto p-4"
              onClick={() => setLanguage(lang.code)}
            >
              <div className="flex items-center gap-3">
                <span className="text-2xl">{lang.flag}</span>
                <div className="text-left">
                  <span className="font-medium block">{lang.nativeName}</span>
                  <span className="text-xs text-muted-foreground">{lang.name}</span>
                </div>
              </div>
              {language === lang.code && <Check className="w-4 h-4" />}
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

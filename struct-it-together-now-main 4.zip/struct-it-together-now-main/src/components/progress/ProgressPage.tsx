
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Coins, Target, Calendar, CheckCircle, Clock } from "lucide-react";
import { NavigationPage } from "../dashboard/Dashboard";

interface ProgressPageProps {
  onNavigate: (page: NavigationPage) => void;
}

export const ProgressPage = ({ onNavigate }: ProgressPageProps) => {
  // Données d'exemple simplifiées
  const stats = {
    totalSaved: 65000,
    targetAmount: 100000,
    activeTontines: 2,
    completedTontines: 1
  };

  const progressPercentage = (stats.totalSaved / stats.targetAmount) * 100;

  return (
    <div className="min-h-screen bg-background p-4 pb-24">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-foreground mb-2">📈 Mon Progrès</h1>
        <p className="text-muted-foreground">Suivez facilement vos économies et vos objectifs</p>
      </div>
      
      {/* Main Progress Card */}
      <Card className="mb-6 bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-primary">
            <Target className="w-6 h-6" />
            🎯 Épargne Totale
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {/* Montant principal */}
            <div className="text-center">
              <div className="text-4xl font-bold text-primary mb-2">
                {stats.totalSaved.toLocaleString()} F
              </div>
              <div className="text-lg text-muted-foreground">
                sur {stats.targetAmount.toLocaleString()} F
              </div>
            </div>
            
            {/* Barre de progression améliorée */}
            <div className="space-y-3">
              <Progress 
                value={progressPercentage} 
                className="h-4 bg-muted"
              />
              
              {/* Indicateurs visuels */}
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-primary rounded-full"></div>
                  <span className="text-sm text-muted-foreground">Économisé</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-muted rounded-full"></div>
                  <span className="text-sm text-muted-foreground">Restant</span>
                </div>
              </div>
            </div>
            
            {/* Badge de progression */}
            <div className="text-center">
              <Badge variant="secondary" className="text-lg px-6 py-3 bg-primary/10 text-primary border-primary/20">
                <CheckCircle className="w-5 h-5 mr-2" />
                {Math.round(progressPercentage)}% ACCOMPLI
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Cards avec icônes améliorées */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <Card className="border-green-200 bg-green-50/50">
          <CardContent className="p-4 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-green-100 rounded-full mb-3">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
            <div className="text-2xl font-bold text-green-700">{stats.activeTontines}</div>
            <div className="text-sm text-green-600 font-medium">Tontines actives</div>
            <div className="text-xs text-muted-foreground mt-1">En cours</div>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-blue-50/50">
          <CardContent className="p-4 text-center">
            <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full mb-3">
              <CheckCircle className="w-6 h-6 text-blue-600" />
            </div>
            <div className="text-2xl font-bold text-blue-700">{stats.completedTontines}</div>
            <div className="text-sm text-blue-600 font-medium">Tontines terminées</div>
            <div className="text-xs text-muted-foreground mt-1">Succès !</div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity avec meilleurs visuels */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-accent" />
            📋 Activité Récente
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between items-center p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <Coins className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <div className="font-medium text-green-800">Paiement tontine mariage</div>
                  <div className="text-sm text-green-600">Il y a 2 jours</div>
                </div>
              </div>
              <div className="text-green-700 font-bold text-lg">+5,000 F</div>
            </div>
            
            <div className="flex justify-between items-center p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Coins className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <div className="font-medium text-blue-800">Paiement tontine riz</div>
                  <div className="text-sm text-blue-600">Il y a 1 semaine</div>
                </div>
              </div>
              <div className="text-blue-700 font-bold text-lg">+2,500 F</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Message d'encouragement amélioré */}
      <Card className="mt-6 bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
        <CardContent className="p-6 text-center">
          <div className="text-2xl mb-3">🎉</div>
          <div className="text-lg font-medium mb-2 text-orange-800">Excellent travail !</div>
          <div className="text-sm text-orange-700 leading-relaxed">
            Vous avez déjà économisé <strong>{Math.round(progressPercentage)}%</strong> de votre objectif. 
            <br/>Continuez comme ça, vous êtes sur la bonne voie ! 💪
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

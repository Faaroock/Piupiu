
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Lock, Unlock, Plus } from "lucide-react";
import { useFrozenBalance } from "@/hooks/useFrozenBalance";
import { useState } from "react";
import { FreezeBalanceModal } from "./FreezeBalanceModal";

export const FrozenBalanceCard = () => {
  const { 
    frozenBalances, 
    totalFrozenAmount, 
    availableBalance, 
    loading, 
    unfreezeFunds 
  } = useFrozenBalance();
  const [showFreezeModal, setShowFreezeModal] = useState(false);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-8 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR').format(amount) + ' F';
  };

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Fonds confinés
            </CardTitle>
            <Button 
              size="sm" 
              onClick={() => setShowFreezeModal(true)}
              className="bg-[#00B894] hover:bg-[#00B894]/90"
            >
              <Plus className="w-4 h-4 mr-2" />
              Confiner
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Résumé des balances */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-red-50 p-3 rounded-lg">
              <p className="text-sm text-red-600 font-medium">Fonds confinés</p>
              <p className="text-lg font-bold text-red-700">
                {formatCurrency(totalFrozenAmount)}
              </p>
            </div>
            
            <div className="bg-green-50 p-3 rounded-lg">
              <p className="text-sm text-green-600 font-medium">Balance disponible</p>
              <p className="text-lg font-bold text-green-700">
                {formatCurrency(availableBalance)}
              </p>
            </div>
          </div>

          {/* Liste des fonds confinés */}
          {frozenBalances.length > 0 ? (
            <div className="space-y-3">
              <h4 className="font-semibold text-sm">Fonds confinés actifs</h4>
              {frozenBalances.map((frozen) => (
                <div key={frozen.id} className="border rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge variant="destructive" className="text-xs">
                        {formatCurrency(frozen.amount)}
                      </Badge>
                      <span className="text-sm font-medium">{frozen.reason}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => unfreezeFunds(frozen.id)}
                    >
                      <Unlock className="w-3 h-3 mr-1" />
                      Libérer
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Confiné le {new Date(frozen.created_at).toLocaleDateString('fr-FR')}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6">
              <Lock className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">Aucun fonds confiné</p>
              <p className="text-sm text-muted-foreground">
                Confinez des fonds pour les mettre de côté en sécurité
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <FreezeBalanceModal
        isOpen={showFreezeModal}
        onClose={() => setShowFreezeModal(false)}
        availableBalance={availableBalance}
      />
    </>
  );
};

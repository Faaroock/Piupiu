
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { X, Lock } from "lucide-react";
import { useFrozenBalance } from "@/hooks/useFrozenBalance";

interface FreezeBalanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  availableBalance: number;
}

export const FreezeBalanceModal = ({ isOpen, onClose, availableBalance }: FreezeBalanceModalProps) => {
  const { freezeFunds } = useFrozenBalance();
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const numAmount = parseFloat(amount);
    if (numAmount <= 0 || numAmount > availableBalance) {
      return;
    }

    setLoading(true);
    try {
      await freezeFunds(numAmount, reason);
      setAmount("");
      setReason("");
      onClose();
    } catch (error) {
      console.error('Erreur confinement:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR').format(amount) + ' F';
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              Confiner des fonds
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            Balance disponible: {formatCurrency(availableBalance)}
          </p>
        </CardHeader>
        
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="amount">Montant à confiner</Label>
              <Input
                id="amount"
                type="number"
                placeholder="Montant en francs"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                max={availableBalance}
                min="1"
                required
              />
              <p className="text-xs text-muted-foreground mt-1">
                Maximum: {formatCurrency(availableBalance)}
              </p>
            </div>

            <div>
              <Label htmlFor="reason">Raison du confinement</Label>
              <Textarea
                id="reason"
                placeholder="Pourquoi confinez-vous ces fonds ?"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                required
                rows={3}
              />
            </div>

            <div className="bg-yellow-50 p-3 rounded-lg">
              <p className="text-sm text-yellow-800">
                ⚠️ Une fois confinés, ces fonds ne pourront plus être utilisés pour les contributions ou transfers jusqu'à leur libération.
              </p>
            </div>

            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                Annuler
              </Button>
              <Button 
                type="submit" 
                disabled={loading || !amount || !reason}
                className="flex-1"
              >
                {loading ? "Confinement..." : "Confiner"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

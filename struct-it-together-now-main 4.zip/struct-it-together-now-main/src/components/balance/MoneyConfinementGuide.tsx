
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Lock, Shield, Clock, AlertTriangle, CheckCircle } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

export const MoneyConfinementGuide = () => {
  const { t } = useLanguage();

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Lock className="w-4 h-4 mr-2" />
          {t('what_is_confinement') || 'Qu\'est-ce que le confinement ?'}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary" />
            {t('money_confinement_guide') || 'Guide du confinement d\'argent'}
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Introduction */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                {t('what_is_confinement') || 'Qu\'est-ce que le confinement ?'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700">
                {t('confinement_explanation') || 
                'Le confinement d\'argent est un mécanisme de sécurité qui bloque temporairement une partie de vos fonds pour garantir vos engagements dans les tontines ou pour des raisons de sécurité.'}
              </p>
            </CardContent>
          </Card>

          {/* Comment ça marche */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Clock className="w-5 h-5" />
                {t('how_it_works') || 'Comment ça marche'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-semibold">1</span>
                </div>
                <div>
                  <h4 className="font-medium">
                    {t('confinement_step_1') || 'Engagement dans une tontine'}
                  </h4>
                  <p className="text-sm text-gray-600">
                    {t('confinement_step_1_desc') || 
                    'Quand vous rejoignez une tontine, le montant de votre contribution est automatiquement confiné.'}
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                  <span className="text-yellow-600 font-semibold">2</span>
                </div>
                <div>
                  <h4 className="font-medium">
                    {t('confinement_step_2') || 'Fonds bloqués'}
                  </h4>
                  <p className="text-sm text-gray-600">
                    {t('confinement_step_2_desc') || 
                    'L\'argent confiné reste dans votre compte mais ne peut pas être retiré ou utilisé ailleurs.'}
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                </div>
                <div>
                  <h4 className="font-medium">
                    {t('confinement_step_3') || 'Libération automatique'}
                  </h4>
                  <p className="text-sm text-gray-600">
                    {t('confinement_step_3_desc') || 
                    'Les fonds sont automatiquement libérés quand la tontine se termine ou en cas d\'annulation.'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Types de confinement */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">
                {t('confinement_types') || 'Types de confinement'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                <Shield className="w-5 h-5 text-blue-600" />
                <div>
                  <h4 className="font-medium text-blue-900">
                    {t('tontine_commitment') || 'Engagement tontine'}
                  </h4>
                  <p className="text-sm text-blue-700">
                    {t('tontine_commitment_desc') || 'Garantit votre participation jusqu\'à la fin'}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-3 p-3 bg-yellow-50 rounded-lg">
                <AlertTriangle className="w-5 h-5 text-yellow-600" />
                <div>
                  <h4 className="font-medium text-yellow-900">
                    {t('security_measure') || 'Mesure de sécurité'}
                  </h4>
                  <p className="text-sm text-yellow-700">
                    {t('security_measure_desc') || 'Protection contre les activités suspectes'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Avantages */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg text-green-700">
                {t('confinement_benefits') || 'Avantages du confinement'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  {t('benefit_1') || 'Garantit la stabilité des tontines'}
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  {t('benefit_2') || 'Protège contre les retraits impulsifs'}
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  {t('benefit_3') || 'Renforce la confiance entre participants'}
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  {t('benefit_4') || 'Sécurise votre épargne'}
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
};

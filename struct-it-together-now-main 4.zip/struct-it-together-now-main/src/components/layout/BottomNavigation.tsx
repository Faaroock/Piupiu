
import { Home, Users, Plus, MessageCircle, Settings } from "lucide-react";
import { NavigationPage } from "@/pages/Dashboard";
import { useLanguage } from "@/contexts/LanguageContext";

interface BottomNavigationProps {
  currentPage: NavigationPage;
  onNavigate: (page: NavigationPage) => void;
}

export const BottomNavigation = ({ currentPage, onNavigate }: BottomNavigationProps) => {
  const { t } = useLanguage();
  
  const navItems = [
    { id: "home" as NavigationPage, icon: Home, label: "Accueil" },
    { id: "tontines" as NavigationPage, icon: Users, label: t("tontines") || "Tontines" },
    { id: "create" as NavigationPage, icon: Plus, label: t("create") || "Créer" },
    { id: "messages" as NavigationPage, icon: MessageCircle, label: "Messages" },
    { id: "settings" as NavigationPage, icon: Settings, label: t("settings") || "Paramètres" },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 shadow-lg z-50 safe-area-pb">
      <div className="grid grid-cols-5 gap-1 px-2 py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPage === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => {
                console.log(`Navigation vers: ${item.id}`);
                onNavigate(item.id);
              }}
              className={`flex flex-col items-center py-2 px-1 rounded-lg transition-all duration-200 ${
                isActive 
                  ? "bg-[#00B894] text-white shadow-sm scale-105" 
                  : "text-gray-600 dark:text-gray-400 hover:text-[#00B894] hover:bg-[#00B894]/10 dark:hover:bg-[#00B894]/20"
              }`}
            >
              <Icon size={isActive ? 24 : 20} className="transition-all duration-200" />
              <span className={`text-xs mt-1 font-medium transition-all duration-200 ${
                isActive ? "text-white" : ""
              }`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

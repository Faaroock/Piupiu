
import { useEffect, useRef } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { MessageBubble } from "./MessageBubble";
import { MessageInput } from "./MessageInput";
import { Message } from "@/hooks/useMessages";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MessageCircle, Users } from "lucide-react";

interface ChatWindowProps {
  messages: Message[];
  onSendMessage: (content: string) => void;
  conversationName?: string;
  conversationType?: 'private' | 'tontine_group';
  isLoading?: boolean;
}

export const ChatWindow = ({ 
  messages, 
  onSendMessage, 
  conversationName,
  conversationType,
  isLoading 
}: ChatWindowProps) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const shouldShowAvatar = (message: Message, index: number) => {
    if (index === 0) return true;
    const prevMessage = messages[index - 1];
    return prevMessage.sender_id !== message.sender_id;
  };

  return (
    <div className="flex flex-col h-full">
      {/* Chat Header */}
      <div className="flex items-center gap-3 p-4 border-b bg-background">
        <Avatar className="h-10 w-10">
          <AvatarFallback className="bg-primary/10">
            {conversationType === 'tontine_group' ? (
              <Users className="w-5 h-5" />
            ) : (
              <MessageCircle className="w-5 h-5" />
            )}
          </AvatarFallback>
        </Avatar>
        <div>
          <h2 className="font-semibold text-foreground">
            {conversationName || 'Conversation'}
          </h2>
          <p className="text-sm text-muted-foreground">
            {conversationType === 'tontine_group' ? 'Groupe Tontine' : 'Conversation privée'}
          </p>
        </div>
      </div>

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.length === 0 ? (
            <div className="text-center py-8">
              <MessageCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">Aucun message pour le moment</p>
              <p className="text-sm text-muted-foreground mt-1">
                Envoyez le premier message pour commencer la conversation
              </p>
            </div>
          ) : (
            messages.map((message, index) => (
              <MessageBubble
                key={message.id}
                message={message}
                showAvatar={shouldShowAvatar(message, index)}
              />
            ))
          )}
          {isLoading && (
            <div className="text-center py-4">
              <p className="text-sm text-muted-foreground">Chargement...</p>
            </div>
          )}
        </div>
        <div ref={messagesEndRef} />
      </ScrollArea>

      {/* Message Input */}
      <MessageInput onSendMessage={onSendMessage} disabled={isLoading} />
    </div>
  );
};

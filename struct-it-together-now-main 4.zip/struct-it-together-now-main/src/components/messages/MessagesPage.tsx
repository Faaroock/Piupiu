
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, MessageCircle, Plus } from "lucide-react";
import { NavigationPage } from "@/pages/Dashboard";
import { useMessages } from "@/hooks/useMessages";
import { ConversationList } from "./ConversationList";
import { ChatWindow } from "./ChatWindow";
import { useLanguage } from "@/contexts/LanguageContext";

interface MessagesPageProps {
  onNavigate: (page: NavigationPage) => void;
}

export const MessagesPage = ({ onNavigate }: MessagesPageProps) => {
  const { t } = useLanguage();
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  
  const {
    conversations,
    messages,
    isLoading,
    fetchMessages,
    sendMessage
  } = useMessages();

  const selectedConversation = conversations.find(conv => conv.id === selectedConversationId);

  const handleSelectConversation = async (conversationId: string) => {
    setSelectedConversationId(conversationId);
    await fetchMessages(conversationId);
  };

  const handleSendMessage = async (content: string) => {
    if (selectedConversationId) {
      await sendMessage(selectedConversationId, content);
    }
  };

  const handleBack = () => {
    setSelectedConversationId(null);
  };

  // Mobile view: show conversation list or chat window
  const isMobile = window.innerWidth < 768;

  if (isMobile && selectedConversationId) {
    return (
      <div className="min-h-screen bg-background pb-20">
        <div className="flex items-center gap-3 p-4 border-b bg-background">
          <Button variant="ghost" size="sm" onClick={handleBack}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <h1 className="text-lg font-semibold">Retour aux conversations</h1>
        </div>
        
        <div className="h-[calc(100vh-160px)]">
          <ChatWindow
            messages={messages}
            onSendMessage={handleSendMessage}
            conversationName={
              selectedConversation?.type === 'tontine_group'
                ? selectedConversation.name
                : selectedConversation?.participants?.find(p => p.user_id !== selectedConversation.participants?.[0]?.user_id)?.profile
                  ? `${selectedConversation.participants.find(p => p.user_id !== selectedConversation.participants?.[0]?.user_id)?.profile?.first_name} ${selectedConversation.participants.find(p => p.user_id !== selectedConversation.participants?.[0]?.user_id)?.profile?.last_name}`
                  : 'Conversation'
            }
            conversationType={selectedConversation?.type}
            isLoading={isLoading}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 pb-20">
      <div className="mb-6 flex items-center gap-3">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => onNavigate("home")}
          className="text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Retour
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-foreground mb-2">Messages</h1>
          <p className="text-muted-foreground">Communication avec les membres</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-[calc(100vh-280px)]">
        {/* Conversations List */}
        <div className="md:col-span-1">
          <Card className="h-full">
            <CardContent className="p-4 h-full">
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-semibold">Conversations</h2>
                <Button size="sm" variant="outline">
                  <Plus className="w-4 h-4 mr-2" />
                  Nouveau
                </Button>
              </div>
              
              <div className="h-[calc(100%-60px)] overflow-y-auto">
                <ConversationList
                  conversations={conversations}
                  onSelectConversation={handleSelectConversation}
                  selectedConversationId={selectedConversationId}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Chat Window */}
        <div className="md:col-span-2">
          <Card className="h-full">
            {selectedConversationId ? (
              <ChatWindow
                messages={messages}
                onSendMessage={handleSendMessage}
                conversationName={
                  selectedConversation?.type === 'tontine_group'
                    ? selectedConversation.name
                    : selectedConversation?.participants?.find(p => p.user_id !== selectedConversation.participants?.[0]?.user_id)?.profile
                      ? `${selectedConversation.participants.find(p => p.user_id !== selectedConversation.participants?.[0]?.user_id)?.profile?.first_name} ${selectedConversation.participants.find(p => p.user_id !== selectedConversation.participants?.[0]?.user_id)?.profile?.last_name}`
                      : 'Conversation'
                }
                conversationType={selectedConversation?.type}
                isLoading={isLoading}
              />
            ) : (
              <CardContent className="p-8 h-full flex items-center justify-center">
                <div className="text-center">
                  <MessageCircle className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    Sélectionnez une conversation
                  </h3>
                  <p className="text-muted-foreground">
                    Choisissez une conversation dans la liste pour commencer à discuter
                  </p>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

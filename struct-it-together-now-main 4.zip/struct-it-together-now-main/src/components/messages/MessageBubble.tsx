
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { Message } from "@/hooks/useMessages";
import { useAuth } from "@/contexts/AuthContext";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

interface MessageBubbleProps {
  message: Message;
  showAvatar?: boolean;
}

export const MessageBubble = ({ message, showAvatar = true }: MessageBubbleProps) => {
  const { user } = useAuth();
  const isOwnMessage = message.sender_id === user?.id;

  return (
    <div className={cn(
      "flex gap-3 max-w-[80%]",
      isOwnMessage ? "ml-auto flex-row-reverse" : "mr-auto"
    )}>
      {showAvatar && !isOwnMessage && (
        <Avatar className="h-8 w-8 flex-shrink-0">
          <AvatarImage src={message.sender_profile?.avatar_url} />
          <AvatarFallback className="bg-primary/10 text-xs">
            {message.sender_profile ? 
              `${message.sender_profile.first_name[0]}${message.sender_profile.last_name[0]}`.toUpperCase() :
              '?'
            }
          </AvatarFallback>
        </Avatar>
      )}
      
      <div className={cn(
        "flex flex-col gap-1",
        isOwnMessage ? "items-end" : "items-start"
      )}>
        {!isOwnMessage && showAvatar && message.sender_profile && (
          <span className="text-xs font-medium text-muted-foreground">
            {message.sender_profile.first_name} {message.sender_profile.last_name}
          </span>
        )}
        
        <div className={cn(
          "rounded-lg px-3 py-2 max-w-full break-words",
          isOwnMessage 
            ? "bg-primary text-primary-foreground" 
            : "bg-muted text-foreground"
        )}>
          <p className="text-sm">{message.content}</p>
        </div>
        
        <span className="text-xs text-muted-foreground">
          {formatDistanceToNow(new Date(message.created_at), {
            addSuffix: true,
            locale: fr
          })}
        </span>
      </div>
    </div>
  );
};

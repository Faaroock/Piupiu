
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { MessageCircle, Users } from "lucide-react";
import { Conversation } from "@/hooks/useMessages";
import { formatDistanceToNow } from "date-fns";
import { fr } from "date-fns/locale";

interface ConversationListProps {
  conversations: Conversation[];
  onSelectConversation: (conversationId: string) => void;
  selectedConversationId?: string;
}

export const ConversationList = ({ 
  conversations, 
  onSelectConversation, 
  selectedConversationId 
}: ConversationListProps) => {
  const getConversationName = (conversation: Conversation) => {
    if (conversation.type === 'tontine_group') {
      return conversation.name || 'Groupe Tontine';
    }
    
    // For private conversations, show the other participant's name
    const otherParticipant = conversation.participants?.find(p => p.user_id !== conversation.participants?.[0]?.user_id);
    if (otherParticipant?.profile) {
      return `${otherParticipant.profile.first_name} ${otherParticipant.profile.last_name}`;
    }
    
    return 'Conversation privée';
  };

  const getConversationAvatar = (conversation: Conversation) => {
    if (conversation.type === 'tontine_group') {
      return undefined; // Will show fallback with Users icon
    }
    
    const otherParticipant = conversation.participants?.find(p => p.user_id !== conversation.participants?.[0]?.user_id);
    return otherParticipant?.profile?.avatar_url;
  };

  const getAvatarFallback = (conversation: Conversation) => {
    if (conversation.type === 'tontine_group') {
      return <Users className="w-4 h-4" />;
    }
    
    const otherParticipant = conversation.participants?.find(p => p.user_id !== conversation.participants?.[0]?.user_id);
    if (otherParticipant?.profile) {
      return `${otherParticipant.profile.first_name[0]}${otherParticipant.profile.last_name[0]}`.toUpperCase();
    }
    
    return <MessageCircle className="w-4 h-4" />;
  };

  if (conversations.length === 0) {
    return (
      <div className="text-center py-8">
        <MessageCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-foreground mb-2">Aucune conversation</h3>
        <p className="text-muted-foreground">Vos conversations apparaîtront ici</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {conversations.map((conversation) => (
        <Card 
          key={conversation.id}
          className={`cursor-pointer transition-colors hover:bg-muted/50 ${
            selectedConversationId === conversation.id ? 'bg-muted border-primary' : ''
          }`}
          onClick={() => onSelectConversation(conversation.id)}
        >
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10">
                <AvatarImage src={getConversationAvatar(conversation)} />
                <AvatarFallback className="bg-primary/10">
                  {getAvatarFallback(conversation)}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-foreground truncate">
                    {getConversationName(conversation)}
                  </h3>
                  <div className="flex items-center gap-2">
                    {conversation.unread_count && conversation.unread_count > 0 && (
                      <Badge variant="destructive" className="h-5 min-w-5 text-xs">
                        {conversation.unread_count > 99 ? '99+' : conversation.unread_count}
                      </Badge>
                    )}
                    {conversation.last_message && (
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(conversation.last_message.created_at), {
                          addSuffix: true,
                          locale: fr
                        })}
                      </span>
                    )}
                  </div>
                </div>
                
                {conversation.last_message && (
                  <p className="text-sm text-muted-foreground truncate mt-1">
                    {conversation.last_message.sender_profile && (
                      <span className="font-medium">
                        {conversation.last_message.sender_profile.first_name}: 
                      </span>
                    )}
                    {conversation.last_message.content}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

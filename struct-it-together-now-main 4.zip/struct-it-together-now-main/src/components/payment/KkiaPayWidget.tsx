
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { KkiaPayService } from '@/services/kkiapay/kkiaPayService';

interface KkiaPayWidgetProps {
  onPaymentSuccess?: (data: any) => void;
  onPaymentError?: (error: any) => void;
}

export const KkiaPayWidget = ({ onPaymentSuccess, onPaymentError }: KkiaPayWidgetProps) => {
  const { toast } = useToast();
  const [amount, setAmount] = useState('100');
  const [reason, setReason] = useState('Test paiement NONRU');
  const [loading, setLoading] = useState(false);
  const [sdkLoaded, setSdkLoaded] = useState(false);

  useEffect(() => {
    // Vérifier si le SDK KkiaPay est chargé
    const checkSDK = () => {
      if (KkiaPayService.isAvailable()) {
        setSdkLoaded(true);
      } else {
        setTimeout(checkSDK, 1000);
      }
    };
    checkSDK();
  }, []);

  const handlePayment = async () => {
    if (!sdkLoaded) {
      toast({
        title: "Erreur",
        description: "SDK KkiaPay non chargé. Veuillez actualiser la page.",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const callbackUrl = KkiaPayService.generateCallbackUrl();
      
      await KkiaPayService.initializePayment({
        amount: parseInt(amount),
        reason: reason,
        callback: callbackUrl,
        data: {
          test: true,
          timestamp: Date.now()
        }
      });

      toast({
        title: "Paiement KkiaPay initié",
        description: `Montant: ${amount} XOF - ${reason}`
      });

    } catch (error) {
      toast({
        title: "Erreur paiement KkiaPay",
        description: `${error}`,
        variant: "destructive"
      });
      onPaymentError?.(error);
    } finally {
      setLoading(false);
    }
  };

  // Écouter les messages de callback KkiaPay
  useEffect(() => {
    const handleKkiaPayCallback = (event: MessageEvent) => {
      if (event.data && event.data.type === 'kkiapay_callback') {
        console.log('Callback KkiaPay reçu:', event.data);
        KkiaPayService.handleCallback(event.data.response);
        onPaymentSuccess?.(event.data.response);
        
        toast({
          title: "Paiement traité",
          description: `Statut: ${event.data.response.status}`,
          variant: event.data.response.status === 'SUCCESS' ? 'default' : 'destructive'
        });
      }
    };

    window.addEventListener('message', handleKkiaPayCallback);
    return () => window.removeEventListener('message', handleKkiaPayCallback);
  }, [onPaymentSuccess, toast]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          🟢 KkiaPay
          <Badge variant="secondary">Sandbox</Badge>
          {!sdkLoaded && <Badge variant="destructive">SDK non chargé</Badge>}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="kkiapay-amount">Montant (XOF)</Label>
          <Input
            id="kkiapay-amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="100"
            type="number"
            min="1"
          />
        </div>

        <div>
          <Label htmlFor="kkiapay-reason">Motif du paiement</Label>
          <Input
            id="kkiapay-reason"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Paiement test NONRU"
          />
        </div>

        <div className="text-sm text-muted-foreground">
          <p><strong>Clé publique:</strong> de9979e04a7311f09b9e233509c54e45</p>
          <p><strong>Mode:</strong> Sandbox</p>
          <p><strong>Pays supportés:</strong> BJ, CI, BF, TG, SN, NE, ML</p>
        </div>

        <Button 
          onClick={handlePayment} 
          disabled={loading || !sdkLoaded || !amount} 
          className="w-full"
        >
          {loading ? 'Paiement en cours...' : `Payer ${amount} XOF avec KkiaPay`}
        </Button>

        {!sdkLoaded && (
          <div className="text-sm text-yellow-600 bg-yellow-50 p-2 rounded">
            ⚠️ Le SDK KkiaPay est en cours de chargement...
          </div>
        )}
      </CardContent>
    </Card>
  );
};

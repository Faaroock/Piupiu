import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { MtnAuthService } from '@/services/mtn/mtnAuth';
import { MtnPaymentService } from '@/services/mtn/mtnPayment';
import { MoovPaymentService } from '@/services/moov/moovPayment';
import { KkiaPayWidget } from './KkiaPayWidget';
import { SUPPORTED_COUNTRIES } from '@/services/paymentManager';

export const PaymentTestInterface = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any>(null);

  // États MTN
  const [mtnCountry, setMtnCountry] = useState('bj');
  const [mtnApiKey, setMtnApiKey] = useState('');
  const [mtnAmount, setMtnAmount] = useState('100');
  const [mtnPhone, setMtnPhone] = useState('22966666666');

  // États Moov
  const [moovAmount, setMoovAmount] = useState('100');
  const [moovSenderPhone, setMoovSenderPhone] = useState('22966666666');
  const [moovRecipientPhone, setMoovRecipientPhone] = useState('22977777777');

  const generateMtnApiKey = async () => {
    setLoading(true);
    try {
      const apiKey = await MtnAuthService.generateApiKey(mtnCountry);
      setMtnApiKey(apiKey);
      toast({
        title: "Succès",
        description: `API Key MTN générée pour ${mtnCountry.toUpperCase()}: ${apiKey.substring(0, 10)}...`
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: `Impossible de générer l'API Key: ${error}`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const testMtnPayment = async () => {
    if (!mtnApiKey) {
      toast({
        title: "Erreur",
        description: "Veuillez d'abord générer une API Key MTN",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const paymentRequest = {
        amount: mtnAmount,
        currency: 'XOF',
        externalId: `test_${Date.now()}`,
        payer: {
          partyIdType: 'MSISDN',
          partyId: mtnPhone
        },
        payerMessage: 'Test de paiement NONRU',
        payeeNote: 'Paiement sandbox MTN MoMo'
      };

      const result = await MtnPaymentService.requestToPay(mtnCountry, mtnApiKey, paymentRequest);
      setResults({ type: 'mtn_payment', data: result });
      
      toast({
        title: "Paiement MTN initié",
        description: `Référence: ${result.referenceId}`
      });

      // Vérifier le statut après 5 secondes
      setTimeout(async () => {
        try {
          const status = await MtnPaymentService.getPaymentStatus(mtnCountry, mtnApiKey, result.referenceId);
          setResults({ type: 'mtn_status', data: status });
        } catch (error) {
          console.error('Erreur vérification statut:', error);
        }
      }, 5000);

    } catch (error) {
      toast({
        title: "Erreur paiement MTN",
        description: `${error}`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const testMoovTransfer = async () => {
    setLoading(true);
    try {
      const transferRequest = {
        amount: parseInt(moovAmount),
        currency: 'XOF',
        description: 'Test transfert NONRU',
        reference: `moov_test_${Date.now()}`,
        recipient: {
          phone: moovRecipientPhone,
          name: 'Test Recipient'
        },
        sender: {
          phone: moovSenderPhone,
          name: 'Test Sender'
        }
      };

      const result = await MoovPaymentService.initializeTransfer(transferRequest);
      setResults({ type: 'moov_transfer', data: result });
      
      toast({
        title: "Transfert Moov initié",
        description: `Transaction ID: ${result.transactionId}`
      });

    } catch (error) {
      toast({
        title: "Erreur transfert Moov",
        description: `${error}`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const testMoovBalance = async () => {
    setLoading(true);
    try {
      const balance = await MoovPaymentService.getAccountBalance();
      setResults({ type: 'moov_balance', data: balance });
      
      toast({
        title: "Balance Moov récupérée",
        description: "Voir les détails ci-dessous"
      });

    } catch (error) {
      toast({
        title: "Erreur balance Moov",
        description: `${error}`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleKkiaPaySuccess = (data: any) => {
    setResults({ type: 'kkiapay_success', data });
    toast({
      title: "Paiement KkiaPay réussi",
      description: `Transaction ID: ${data.transactionId}`
    });
  };

  const handleKkiaPayError = (error: any) => {
    setResults({ type: 'kkiapay_error', data: error });
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            🧪 Interface de Test des Paiements
            <Badge variant="secondary">Sandbox</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="kkiapay" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="kkiapay">KkiaPay</TabsTrigger>
              <TabsTrigger value="mtn">MTN MoMo</TabsTrigger>
              <TabsTrigger value="moov">Moov Money</TabsTrigger>
            </TabsList>

            <TabsContent value="kkiapay" className="space-y-4">
              <KkiaPayWidget 
                onPaymentSuccess={handleKkiaPaySuccess}
                onPaymentError={handleKkiaPayError}
              />
            </TabsContent>

            <TabsContent value="mtn" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="mtn-country">Pays</Label>
                  <Select value={mtnCountry} onValueChange={setMtnCountry}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SUPPORTED_COUNTRIES.MTN.map(country => (
                        <SelectItem key={country} value={country}>
                          {country.toUpperCase()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="mtn-amount">Montant (XOF)</Label>
                  <Input
                    id="mtn-amount"
                    value={mtnAmount}
                    onChange={(e) => setMtnAmount(e.target.value)}
                    placeholder="100"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="mtn-phone">Numéro de téléphone</Label>
                <Input
                  id="mtn-phone"
                  value={mtnPhone}
                  onChange={(e) => setMtnPhone(e.target.value)}
                  placeholder="22966666666"
                />
              </div>

              <div>
                <Label htmlFor="mtn-apikey">API Key MTN</Label>
                <div className="flex gap-2">
                  <Input
                    id="mtn-apikey"
                    value={mtnApiKey}
                    onChange={(e) => setMtnApiKey(e.target.value)}
                    placeholder="Générer ou saisir une API Key"
                    type="password"
                  />
                  <Button onClick={generateMtnApiKey} disabled={loading} variant="outline">
                    Générer
                  </Button>
                </div>
              </div>

              <Button onClick={testMtnPayment} disabled={loading || !mtnApiKey} className="w-full">
                {loading ? 'Test en cours...' : 'Tester Paiement MTN'}
              </Button>
            </TabsContent>

            <TabsContent value="moov" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="moov-amount">Montant (XOF)</Label>
                  <Input
                    id="moov-amount"
                    value={moovAmount}
                    onChange={(e) => setMoovAmount(e.target.value)}
                    placeholder="100"
                  />
                </div>
                <div>
                  <Label htmlFor="moov-sender">Téléphone expéditeur</Label>
                  <Input
                    id="moov-sender"
                    value={moovSenderPhone}
                    onChange={(e) => setMoovSenderPhone(e.target.value)}
                    placeholder="22966666666"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="moov-recipient">Téléphone destinataire</Label>
                <Input
                  id="moov-recipient"
                  value={moovRecipientPhone}
                  onChange={(e) => setMoovRecipientPhone(e.target.value)}
                  placeholder="22977777777"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Button onClick={testMoovTransfer} disabled={loading} className="w-full">
                  {loading ? 'Transfert en cours...' : 'Tester Transfert Moov'}
                </Button>
                <Button onClick={testMoovBalance} disabled={loading} variant="outline" className="w-full">
                  {loading ? 'Chargement...' : 'Vérifier Balance'}
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {results && (
        <Card>
          <CardHeader>
            <CardTitle>Résultats du Test</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-muted p-4 rounded-lg">
              <Badge className="mb-2">{results.type}</Badge>
              <pre className="text-sm overflow-auto">
                {JSON.stringify(results.data, null, 2)}
              </pre>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

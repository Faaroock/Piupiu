
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, Users, Activity, Crown } from 'lucide-react';
import { UserRoleManager } from './UserRoleManager';
import { AdminActivityLogs } from './AdminActivityLogs';
import { useUserRoles } from '@/hooks/useUserRoles';

export const AdminDashboard = () => {
  const { currentUserRoles, hasPermissionLevel } = useUserRoles();

  if (!hasPermissionLevel('admin')) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-center text-red-600">Accès refusé</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-center text-muted-foreground">
              Vous n'avez pas les permissions nécessaires pour accéder à cette page.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getUserRoleBadges = () => {
    return currentUserRoles.map((roleObj) => {
      const roleColors = {
        super_admin: 'bg-purple-100 text-purple-800 border-purple-200',
        admin: 'bg-red-100 text-red-800 border-red-200',
        moderator: 'bg-blue-100 text-blue-800 border-blue-200',
        developer: 'bg-green-100 text-green-800 border-green-200',
        user: 'bg-gray-100 text-gray-800 border-gray-200'
      };

      const roleIcons = {
        super_admin: Crown,
        admin: Shield,
        moderator: Users,
        developer: Activity,
        user: Users
      };

      const IconComponent = roleIcons[roleObj.role] || Users;

      return (
        <Badge key={roleObj.id} className={`${roleColors[roleObj.role]} flex items-center gap-1`}>
          <IconComponent className="w-3 h-3" />
          {roleObj.role}
        </Badge>
      );
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Administration NONRU
          </h1>
          <div className="flex items-center gap-2">
            <p className="text-muted-foreground">Vos rôles:</p>
            <div className="flex gap-1">
              {getUserRoleBadges()}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Gestionnaire de rôles utilisateurs */}
          <div className="lg:col-span-2">
            <UserRoleManager />
          </div>

          {/* Journal d'activité */}
          <div className="lg:col-span-2">
            <AdminActivityLogs />
          </div>
        </div>
      </div>
    </div>
  );
};

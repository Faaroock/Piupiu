
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { UserPlus, UserMinus, Shield, Users, Settings, Code, Crown } from 'lucide-react';
import { useUserRoles, UserWithRole } from '@/hooks/useUserRoles';
import { useToast } from '@/hooks/use-toast';

type RoleType = 'super_admin' | 'admin' | 'moderator' | 'developer' | 'user';

const roleIcons = {
  super_admin: Crown,
  admin: Shield,
  moderator: Users,
  developer: Code,
  user: Settings
};

const roleColors = {
  super_admin: 'bg-purple-100 text-purple-800 border-purple-200',
  admin: 'bg-red-100 text-red-800 border-red-200',
  moderator: 'bg-blue-100 text-blue-800 border-blue-200',
  developer: 'bg-green-100 text-green-800 border-green-200',
  user: 'bg-gray-100 text-gray-800 border-gray-200'
};

export const UserRoleManager = () => {
  const { users, loading, hasRole, assignRole, removeRole } = useUserRoles();
  const { toast } = useToast();
  const [selectedRole, setSelectedRole] = useState<RoleType | ''>('');
  const [actionLoading, setActionLoading] = useState(false);

  const isSuperAdmin = hasRole('super_admin');

  const handleAssignRole = async (userId: string, role: RoleType) => {
    if (!isSuperAdmin) {
      toast({
        title: "Accès refusé",
        description: "Seuls les super administrateurs peuvent assigner des rôles",
        variant: "destructive"
      });
      return;
    }

    try {
      setActionLoading(true);
      await assignRole(userId, role);
      toast({
        title: "Rôle assigné",
        description: `Le rôle ${role} a été assigné avec succès`,
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: error instanceof Error ? error.message : "Erreur lors de l'assignation du rôle",
        variant: "destructive"
      });
    } finally {
      setActionLoading(false);
    }
  };

  const handleRemoveRole = async (userId: string, role: RoleType) => {
    if (!isSuperAdmin) {
      toast({
        title: "Accès refusé",
        description: "Seuls les super administrateurs peuvent retirer des rôles",
        variant: "destructive"
      });
      return;
    }

    try {
      setActionLoading(true);
      await removeRole(userId, role);
      toast({
        title: "Rôle retiré",
        description: `Le rôle ${role} a été retiré avec succès`,
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: error instanceof Error ? error.message : "Erreur lors du retrait du rôle",
        variant: "destructive"
      });
    } finally {
      setActionLoading(false);
    }
  };

  const RoleBadge = ({ role }: { role: string }) => {
    const IconComponent = roleIcons[role as RoleType] || Settings;
    return (
      <Badge className={`${roleColors[role as RoleType]} flex items-center gap-1`}>
        <IconComponent className="w-3 h-3" />
        {role}
      </Badge>
    );
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Gestion des rôles utilisateurs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
              <p className="text-muted-foreground">Chargement des utilisateurs...</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          Gestion des rôles utilisateurs
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {users.map((user) => (
            <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex-1">
                <div className="flex items-center gap-3">
                  <div>
                    <h4 className="font-medium">
                      {user.first_name} {user.last_name}
                    </h4>
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                  </div>
                  <div className="flex gap-1 flex-wrap">
                    {user.roles.map((roleObj) => (
                      <div key={roleObj.id} className="flex items-center gap-1">
                        <RoleBadge role={roleObj.role} />
                        {isSuperAdmin && roleObj.role !== 'super_admin' && (
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                                <UserMinus className="w-3 h-3" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Retirer le rôle</AlertDialogTitle>
                                <AlertDialogDescription>
                                  Êtes-vous sûr de vouloir retirer le rôle "{roleObj.role}" de {user.first_name} {user.last_name} ?
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Annuler</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleRemoveRole(user.id, roleObj.role as RoleType)}
                                  disabled={actionLoading}
                                >
                                  Retirer
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              {isSuperAdmin && (
                <div className="flex items-center gap-2">
                  <Select value={selectedRole} onValueChange={(value) => setSelectedRole(value as RoleType)}>
                    <SelectTrigger className="w-32">
                      <SelectValue placeholder="Rôle" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">Admin</SelectItem>
                      <SelectItem value="moderator">Moderator</SelectItem>
                      <SelectItem value="developer">Developer</SelectItem>
                      <SelectItem value="user">User</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button
                    size="sm"
                    onClick={() => selectedRole && handleAssignRole(user.id, selectedRole as RoleType)}
                    disabled={!selectedRole || actionLoading}
                  >
                    <UserPlus className="w-4 h-4 mr-1" />
                    Assigner
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

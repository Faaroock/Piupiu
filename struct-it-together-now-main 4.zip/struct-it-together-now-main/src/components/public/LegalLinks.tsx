
import { useLanguage } from "@/contexts/LanguageContext";

export const LegalLinks = () => {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col sm:flex-row gap-4 text-sm text-gray-600">
      <a 
        href="/terms" 
        className="hover:text-primary transition-colors"
      >
        {t('terms_of_service') || 'Conditions d\'utilisation'}
      </a>
      <a 
        href="/privacy" 
        className="hover:text-primary transition-colors"
      >
        {t('privacy_policy') || 'Politique de confidentialité'}
      </a>
      <a 
        href="#" 
        className="hover:text-primary transition-colors"
      >
        {t('user_guide') || 'Guide d\'utilisation'}
      </a>
    </div>
  );
};

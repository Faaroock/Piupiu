
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Shield, Users, Target, TrendingUp, Star, CheckCircle } from "lucide-react";

interface PublicHomeProps {
  onShowLogin: () => void;
}

export const PublicHome = ({ onShowLogin }: PublicHomeProps) => {
  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-xl font-bold">💰</span>
              </div>
              <span className="text-2xl font-bold text-slate-800">NONRU</span>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={onShowLogin}>
                Connexion
              </Button>
              <Button onClick={onShowLogin} className="bg-green-600 hover:bg-green-700">
                Créer un compte
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-green-50 to-green-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-slate-800 mb-6">
            L'épargne en groupe, <span className="text-green-600">simplifiée</span>
          </h1>
          <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto">
            NONRU, la plateforme de tontines digitales pour l'Afrique. 
            Rejoignez une communauté d'épargnants et atteignez vos objectifs ensemble.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={onShowLogin}
              size="lg" 
              className="bg-green-600 hover:bg-green-700 text-lg px-8"
            >
              Créer un compte
              <ArrowRight className="ml-2" size={20} />
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="text-lg px-8 border-green-600 text-green-600 hover:bg-green-50"
            >
              Explorer les tontines
            </Button>
          </div>
        </div>
      </section>

      {/* Comment ça marche */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">
              Comment ça marche ?
            </h2>
            <p className="text-xl text-slate-600">
              4 étapes simples pour commencer votre épargne collective
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-green-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">1. Crée un compte</h3>
              <p className="text-slate-600">Inscription rapide et sécurisée en quelques clics</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="text-green-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">2. Rejoins une tontine</h3>
              <p className="text-slate-600">Trouve une tontine qui correspond à tes objectifs</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="text-green-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">3. Épargne régulièrement</h3>
              <p className="text-slate-600">Cotise chaque semaine ou mois selon ton rythme</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="text-green-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">4. Atteins tes objectifs</h3>
              <p className="text-slate-600">Réalise tes projets avec la force du groupe</p>
            </div>
          </div>
        </div>
      </section>

      {/* Exemples de tontines */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">
              Exemples de tontines populaires
            </h2>
            <p className="text-xl text-slate-600">
              Découvrez les types de tontines que nos membres adorent
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-white border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Achat groupé de riz
                </h3>
                <p className="text-slate-600 mb-4">
                  Économisons ensemble sur l'achat de sacs de riz de qualité
                </p>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Cotisation</span>
                    <span className="font-semibold">2 500 F / semaine</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Membres</span>
                    <span className="font-semibold">12 / 15</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: "80%" }}></div>
                  </div>
                  <p className="text-sm text-slate-600">80% de l'objectif atteint</p>
                </div>
                <Button 
                  onClick={onShowLogin}
                  className="w-full mt-4 bg-green-600 hover:bg-green-700"
                >
                  Rejoindre
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-white border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Épargne mariage
                </h3>
                <p className="text-slate-600 mb-4">
                  Préparons nos mariages ensemble avec une épargne collective
                </p>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Cotisation</span>
                    <span className="font-semibold">5 000 F / mois</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Membres</span>
                    <span className="font-semibold">8 / 10</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: "65%" }}></div>
                  </div>
                  <p className="text-sm text-slate-600">65% de l'objectif atteint</p>
                </div>
                <Button 
                  onClick={onShowLogin}
                  className="w-full mt-4 bg-green-600 hover:bg-green-700"
                >
                  Rejoindre
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-white border-slate-200 hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Investissement petit commerce
                </h3>
                <p className="text-slate-600 mb-4">
                  Lançons nos petits commerces avec un fonds commun
                </p>
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Cotisation</span>
                    <span className="font-semibold">10 000 F / mois</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-slate-600">Membres</span>
                    <span className="font-semibold">6 / 8</span>
                  </div>
                  <div className="w-full bg-slate-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{ width: "90%" }}></div>
                  </div>
                  <p className="text-sm text-slate-600">90% de l'objectif atteint</p>
                </div>
                <Button 
                  onClick={onShowLogin}
                  className="w-full mt-4 bg-green-600 hover:bg-green-700"
                >
                  Rejoindre
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Témoignages */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">
              Ce que disent nos membres
            </h2>
            <p className="text-xl text-slate-600">
              Des témoignages authentiques de notre communauté
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-slate-50 border-slate-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-slate-700 mb-4 italic">
                  "Grâce à NONRU, j'ai pu économiser pour mon mariage sans stress. 
                  La communauté m'a vraiment aidée à rester disciplinée !"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold mr-3">
                    AF
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800">Aminata Fall</p>
                    <p className="text-sm text-slate-600">Dakar, Sénégal</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-50 border-slate-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-slate-700 mb-4 italic">
                  "J'ai lancé mon petit commerce grâce aux fonds de notre tontine. 
                  L'application est simple et sécurisée, je recommande !"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold mr-3">
                    KD
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800">Koffi Dosseh</p>
                    <p className="text-sm text-slate-600">Lomé, Togo</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-50 border-slate-200">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-slate-700 mb-4 italic">
                  "Enfin une solution moderne pour les tontines ! Plus besoin de 
                  compter l'argent à la main, tout est transparent et automatique."
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center text-white font-semibold mr-3">
                    MK
                  </div>
                  <div>
                    <p className="font-semibold text-slate-800">Marie Kone</p>
                    <p className="text-sm text-slate-600">Abidjan, Côte d'Ivoire</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Section sécurité */}
      <section className="py-20 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">
              Votre sécurité, notre priorité
            </h2>
            <p className="text-xl text-slate-600">
              Épargneez en toute confiance avec nos garanties de sécurité
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                Argent sécurisé
              </h3>
              <p className="text-slate-600">
                Tous vos fonds sont protégés par des systèmes de sécurité bancaire
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                Transferts contrôlés
              </h3>
              <p className="text-slate-600">
                Chaque transaction est vérifiée et validée par notre système
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                Retrait flexible
              </h3>
              <p className="text-slate-600">
                Possibilité de retrait selon les règles définies par votre groupe
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to action final */}
      <section className="py-20 bg-green-600">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Prêt à commencer votre épargne collective ?
          </h2>
          <p className="text-xl text-green-100 mb-8">
            Rejoignez des milliers d'Africains qui atteignent leurs objectifs avec NONRU
          </p>
          <Button 
            onClick={onShowLogin}
            size="lg" 
            className="bg-white text-green-600 hover:bg-gray-100 text-lg px-8"
          >
            Créer mon compte gratuitement
            <ArrowRight className="ml-2" size={20} />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                  <span className="text-lg font-bold">💰</span>
                </div>
                <span className="text-xl font-bold">NONRU</span>
              </div>
              <p className="text-slate-400">
                La plateforme de tontines digitales pour l'Afrique
              </p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Liens utiles</h3>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-white">À propos</a></li>
                <li><a href="#" className="hover:text-white">Comment ça marche</a></li>
                <li><a href="#" className="hover:text-white">Sécurité</a></li>
                <li><a href="#" className="hover:text-white">Support</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Légal</h3>
              <ul className="space-y-2 text-slate-400">
                <li><a href="#" className="hover:text-white">Mentions légales</a></li>
                <li><a href="#" className="hover:text-white">Politique de confidentialité</a></li>
                <li><a href="#" className="hover:text-white">Conditions d'utilisation</a></li>
                <li><a href="#" className="hover:text-white">Contact</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Contact</h3>
              <ul className="space-y-2 text-slate-400">
                <li>support@nonru.com</li>
                <li>+229 XX XX XX XX</li>
                <li>Cotonou, Bénin</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-700 mt-8 pt-8 text-center text-slate-400">
            <p>&copy; 2024 NONRU. Tous droits réservés.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

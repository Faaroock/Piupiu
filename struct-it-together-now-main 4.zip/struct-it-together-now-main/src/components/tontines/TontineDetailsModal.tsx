
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, Users, Calendar, DollarSign, Clock, Share, Copy } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";

interface TontineDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  tontine: any;
  onJoinRequest?: () => void;
  isOwner?: boolean;
}

export const TontineDetailsModal = ({ 
  isOpen, 
  onClose, 
  tontine, 
  onJoinRequest,
  isOwner = false 
}: TontineDetailsModalProps) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [showShareOptions, setShowShareOptions] = useState(false);

  if (!isOpen || !tontine) return null;

  const shareLink = `${window.location.origin}/tontine/${tontine.id}`;

  const copyShareLink = async () => {
    try {
      await navigator.clipboard.writeText(shareLink);
      toast({
        title: t("success"),
        description: t("link_copied")
      });
    } catch (error) {
      console.error('Erreur copie du lien:', error);
      toast({
        title: t("error"),
        description: "Impossible de copier le lien",
        variant: "destructive"
      });
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR').format(amount) + ' F';
  };

  const getProgressPercentage = (current: number, goal: number) => {
    return Math.min((current / goal) * 100, 100);
  };

  const getFrequencyText = (frequency: string) => {
    const frequencyMap: Record<string, string> = {
      'weekly': `${t('weekly')} ${t('weekly_explanation')}`,
      'monthly': `${t('monthly')} ${t('monthly_explanation')}`,
      'quarterly': `${t('quarterly')} ${t('quarterly_explanation')}`,
      'custom': `${t('custom_explanation')}`
    };
    return frequencyMap[frequency] || frequency;
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <CardTitle className="text-xl mb-2">{tontine.name}</CardTitle>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant="secondary">{tontine.category || 'Général'}</Badge>
                <Badge variant={tontine.status === 'active' ? 'default' : 'secondary'}>
                  {tontine.status === 'active' ? 'Active' : 'Inactive'}
                </Badge>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => setShowShareOptions(!showShareOptions)}
              >
                <Share className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          {showShareOptions && (
            <div className="bg-slate-50 rounded-lg p-3 mt-3">
              <h4 className="font-medium mb-2">{t("share")} cette tontine</h4>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={shareLink}
                  readOnly
                  className="flex-1 px-3 py-2 border rounded-md text-sm bg-white"
                />
                <Button size="sm" onClick={copyShareLink}>
                  <Copy className="w-4 h-4 mr-1" />
                  {t("copy_link")}
                </Button>
              </div>
            </div>
          )}
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Photo de la tontine */}
          {tontine.photo_url && (
            <div className="aspect-video w-full rounded-lg overflow-hidden">
              <img 
                src={tontine.photo_url}
                alt={tontine.name}
                className="w-full h-full object-cover"
              />
            </div>
          )}
          
          {/* Description */}
          {tontine.description && (
            <div>
              <h4 className="font-semibold mb-2">{t("description")}</h4>
              <p className="text-slate-600">{tontine.description}</p>
            </div>
          )}
          
          {/* Informations principales */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-green-600" />
                <div>
                  <p className="text-sm text-slate-600">{t("contribution_amount")}</p>
                  <p className="font-semibold">{formatCurrency(parseInt(tontine.contribution_amount))}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="text-sm text-slate-600">{t("frequency")}</p>
                  <p className="font-semibold">{getFrequencyText(tontine.frequency)}</p>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="text-sm text-slate-600">{t("members")}</p>
                  <p className="font-semibold">{tontine.participants} {t("members").toLowerCase()}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-orange-600" />
                <div>
                  <p className="text-sm text-slate-600">Créée le</p>
                  <p className="font-semibold">
                    {new Date(tontine.created_at).toLocaleDateString('fr-FR')}
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Progrès */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-slate-600">{t("current_amount")}</span>
              <span className="font-semibold text-green-600">
                {formatCurrency(tontine.current_amount)}
              </span>
            </div>
            <div className="flex justify-between items-center mb-3">
              <span className="text-sm text-slate-600">{t("goal_amount")}</span>
              <span className="font-semibold">
                {formatCurrency(tontine.goal_amount)}
              </span>
            </div>
            
            <div className="w-full bg-slate-200 rounded-full h-3">
              <div 
                className="bg-green-500 h-3 rounded-full transition-all duration-300" 
                style={{ width: `${getProgressPercentage(tontine.current_amount, tontine.goal_amount)}%` }}
              ></div>
            </div>
            <p className="text-sm text-slate-600 mt-2 text-center">
              {getProgressPercentage(tontine.current_amount, tontine.goal_amount).toFixed(1)}% {t("progress")}
            </p>
          </div>
          
          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button variant="outline" onClick={onClose} className="flex-1">
              {t("cancel")}
            </Button>
            {!isOwner && onJoinRequest && (
              <Button 
                onClick={onJoinRequest}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                {t("join_tontine")}
              </Button>
            )}
            {isOwner && (
              <Button 
                onClick={copyShareLink}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                <Share className="w-4 h-4 mr-2" />
                {t("share")}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};


import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Check, X, User, Calendar, MessageSquare } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface TontineRequest {
  id: string;
  requester: {
    id: string;
    name: string;
    avatar?: string;
    joinedDate: string;
    completedTontines: number;
  };
  tontine: {
    id: string;
    name: string;
  };
  message?: string;
  createdAt: string;
  status: "pending" | "approved" | "rejected";
}

export const TontineRequestsManager = () => {
  const [requests, setRequests] = useState<TontineRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    // Simuler des demandes en attente
    const mockRequests: TontineRequest[] = [
      {
        id: "req1",
        requester: {
          id: "user1",
          name: "Marie Kouassi",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=marie",
          joinedDate: "2024-01-15",
          completedTontines: 3
        },
        tontine: {
          id: "tontine1",
          name: "Épargne Mariage"
        },
        message: "Bonjour, je souhaite rejoindre votre tontine pour préparer mon mariage prévu en décembre.",
        createdAt: "2025-06-15T10:30:00Z",
        status: "pending"
      },
      {
        id: "req2",
        requester: {
          id: "user2",
          name: "Jean Baptiste",
          avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=jean",
          joinedDate: "2024-03-20",
          completedTontines: 1
        },
        tontine: {
          id: "tontine2",
          name: "Achat Groupé Riz"
        },
        createdAt: "2025-06-15T09:15:00Z",
        status: "pending"
      }
    ];
    
    setRequests(mockRequests);
  };

  const handleRequest = async (requestId: string, action: "approve" | "reject") => {
    setLoading(true);
    try {
      // Simuler le traitement de la demande
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setRequests(prev => 
        prev.map(req => 
          req.id === requestId 
            ? { ...req, status: action === "approve" ? "approved" : "rejected" }
            : req
        )
      );
      
      toast({
        title: action === "approve" ? "Demande acceptée" : "Demande refusée",
        description: action === "approve" 
          ? "Le membre a été ajouté à la tontine"
          : "La demande a été refusée"
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de traiter la demande",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const pendingRequests = requests.filter(req => req.status === "pending");

  if (pendingRequests.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">
            <User className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Aucune demande en attente</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Demandes de participation ({pendingRequests.length})</h3>
      
      {pendingRequests.map((request) => (
        <Card key={request.id}>
          <CardContent className="p-4">
            <div className="flex items-start space-x-4">
              <Avatar className="w-12 h-12">
                <AvatarImage src={request.requester.avatar} />
                <AvatarFallback>
                  {request.requester.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold">{request.requester.name}</h4>
                    <p className="text-sm text-muted-foreground">
                      Souhaite rejoindre: {request.tontine.name}
                    </p>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline" className="mb-1">
                      <Calendar className="w-3 h-3 mr-1" />
                      Membre depuis {new Date(request.requester.joinedDate).toLocaleDateString('fr-FR', { month: 'short', year: 'numeric' })}
                    </Badge>
                    <p className="text-xs text-muted-foreground">
                      {request.requester.completedTontines} tontines terminées
                    </p>
                  </div>
                </div>
                
                {request.message && (
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-2 mb-1">
                      <MessageSquare className="w-4 h-4" />
                      <span className="text-sm font-medium">Message:</span>
                    </div>
                    <p className="text-sm">{request.message}</p>
                  </div>
                )}
                
                <div className="flex gap-2 pt-2">
                  <Button
                    size="sm"
                    onClick={() => handleRequest(request.id, "approve")}
                    disabled={loading}
                  >
                    <Check className="w-4 h-4 mr-1" />
                    Accepter
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleRequest(request.id, "reject")}
                    disabled={loading}
                  >
                    <X className="w-4 h-4 mr-1" />
                    Refuser
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

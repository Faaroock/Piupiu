
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Calendar, Activity } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

interface TontineHistoryEntry {
  id: string;
  action: string;
  details: any;
  created_at: string;
  user_name?: string;
}

interface TontineHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  tontineName: string;
  history: TontineHistoryEntry[];
}

export const TontineHistoryModal = ({ 
  isOpen, 
  onClose, 
  tontineName, 
  history 
}: TontineHistoryModalProps) => {
  const { t } = useLanguage();

  const getActionColor = (action: string) => {
    switch (action) {
      case 'created': return 'bg-green-100 text-green-800';
      case 'joined': return 'bg-blue-100 text-blue-800';
      case 'payment': return 'bg-purple-100 text-purple-800';
      case 'completed': return 'bg-yellow-100 text-yellow-800';
      case 'left': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const formatAction = (action: string) => {
    const actions: Record<string, string> = {
      created: t('action_created') || 'Tontine créée',
      joined: t('action_joined') || 'Membre rejoint',
      payment: t('action_payment') || 'Paiement effectué',
      completed: t('action_completed') || 'Tontine terminée',
      left: t('action_left') || 'Membre parti'
    };
    return actions[action] || action;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Activity className="w-5 h-5" />
            {t('tontine_history') || 'Historique de la tontine'}: {tontineName}
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="h-96">
          <div className="space-y-4">
            {history.length === 0 ? (
              <p className="text-center text-gray-500 py-8">
                {t('no_history') || 'Aucun historique disponible'}
              </p>
            ) : (
              history.map((entry) => (
                <div key={entry.id} className="flex items-start gap-3 p-4 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge className={getActionColor(entry.action)}>
                        {formatAction(entry.action)}
                      </Badge>
                      {entry.user_name && (
                        <span className="text-sm text-gray-600">
                          {t('by') || 'par'} {entry.user_name}
                        </span>
                      )}
                    </div>
                    
                    {entry.details && (
                      <div className="text-sm text-gray-700 mb-2">
                        {typeof entry.details === 'object' ? (
                          <pre className="whitespace-pre-wrap font-mono text-xs bg-gray-50 p-2 rounded">
                            {JSON.stringify(entry.details, null, 2)}
                          </pre>
                        ) : (
                          entry.details
                        )}
                      </div>
                    )}
                    
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <Calendar className="w-3 h-3" />
                      {new Date(entry.created_at).toLocaleString()}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};


import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/contexts/LanguageContext";

interface TontineRequestModalProps {
  isOpen: boolean;
  onClose: () => void;
  tontine: {
    id: string;
    name: string;
    description: string;
    contribution_amount: string;
  };
}

export const TontineRequestModal = ({ isOpen, onClose, tontine }: TontineRequestModalProps) => {
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { t } = useLanguage();

  const handleSubmit = async () => {
    setLoading(true);
    try {
      // Simuler l'envoi de la demande
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: t("success"),
        description: "Votre demande a été envoyée au créateur de la tontine"
      });
      
      onClose();
      setMessage("");
    } catch (error) {
      toast({
        title: t("error"),
        description: "Erreur lors de l'envoi de la demande",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Demande de participation</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="p-4 bg-muted rounded-lg">
            <h4 className="font-semibold">{tontine.name}</h4>
            <p className="text-sm text-muted-foreground mt-1">{tontine.description}</p>
            <p className="text-sm font-medium mt-2">
              Cotisation: {tontine.contribution_amount}
            </p>
          </div>
          
          <div>
            <Label htmlFor="message">Message (optionnel)</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Présentez-vous brièvement au créateur de la tontine..."
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            {t("cancel")}
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading ? "Envoi..." : "Envoyer la demande"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Upload, X } from "lucide-react";
import { NavigationPage } from "../dashboard/Dashboard";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { useNotifications } from "@/hooks/useNotifications";

interface CreateTontinePageProps {
  onNavigate: (page: NavigationPage) => void;
}

export const CreateTontinePage = ({ onNavigate }: CreateTontinePageProps) => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const { addTontineCreatedNotification } = useNotifications();
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    participants: "",
    amount: "",
    frequency: "",
    customFrequency: "",
    penaltyRate: "2",
    maxMissedPayments: "3"
  });
  const [images, setImages] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);

  const frequencies = [
    { value: "weekly", label: `${t("weekly")} ${t("weekly_explanation")}` },
    { value: "monthly", label: `${t("monthly")} ${t("monthly_explanation")}` },
    { value: "quarterly", label: `${t("quarterly")} ${t("quarterly_explanation")}` },
    { value: "custom", label: `Personnalisée ${t("custom_explanation")}` }
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (files.length + images.length > 3) {
      toast({
        title: t("error"),
        description: "Maximum 3 images autorisées",
        variant: "destructive"
      });
      return;
    }
    setImages([...images, ...files]);
  };

  const removeImage = (index: number) => {
    setImages(images.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      console.log("Soumission du formulaire avec:", { formData, imagesCount: images.length });
      console.log("Création de la tontine...");
      
      // Simuler la création
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Calculer l'objectif total basé sur les participants et le montant
      const totalGoal = parseInt(formData.participants) * parseInt(formData.amount) * 12; // Exemple: 12 cycles
      
      // Générer l'URL de la photo si une image est uploadée
      let photoUrl = null;
      if (images.length > 0) {
        // Dans un vrai système, on uploadrait l'image et récupérerait l'URL
        // Ici on simule avec une URL de placeholder
        photoUrl = `https://images.unsplash.com/photo-1649972904349-6e44c42644a7?auto=format&fit=crop&w=400&q=80`;
      }
      
      // Créer l'objet tontine avec lien de partage
      const shareId = Math.random().toString(36).substr(2, 9);
      const newTontine = {
        id: Date.now().toString(),
        name: formData.name,
        description: formData.description,
        contribution_amount: formData.amount,
        frequency: formData.frequency,
        created_at: new Date().toISOString(),
        participants: parseInt(formData.participants),
        current_amount: 0,
        goal_amount: totalGoal,
        photo_url: photoUrl,
        share_id: shareId,
        share_link: `${window.location.origin}/join/${shareId}`,
        canModify: true,
        modificationDeadline: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString() // 24h
      };
      
      // Sauvegarder dans localStorage
      const existingTontines = JSON.parse(localStorage.getItem('userTontines') || '[]');
      existingTontines.push(newTontine);
      localStorage.setItem('userTontines', JSON.stringify(existingTontines));
      
      // Compter le nombre de tontines créées pour la notification
      const tontineCount = existingTontines.length;
      
      console.log("✅ Tontine créée avec succès:", {
        name: formData.name,
        participants: formData.participants,
        amount: formData.amount,
        frequency: formData.frequency,
        images: images.length,
        shareLink: newTontine.share_link
      });
      
      // Ajouter notification de création
      addTontineCreatedNotification(formData.name, tontineCount);
      
      toast({
        title: t("success"),
        description: `Tontine "${formData.name}" créée avec succès ! Lien de partage: ${newTontine.share_link}`
      });
      
      // Réinitialiser le formulaire
      setFormData({
        name: "",
        description: "",
        participants: "",
        amount: "",
        frequency: "",
        customFrequency: "",
        penaltyRate: "2",
        maxMissedPayments: "3"
      });
      setImages([]);
      
      // Rediriger vers les tontines après 1 seconde
      setTimeout(() => {
        onNavigate("tontines");
      }, 1000);
      
    } catch (error) {
      console.error("Erreur création tontine:", error);
      toast({
        title: t("error"),
        description: "Erreur lors de la création de la tontine",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <div className="bg-white p-4">
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => {
              console.log("Retour aux tontines");
              onNavigate("tontines");
            }}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="text-slate-800" size={20} />
          </button>
          <div>
            <h1 className="text-xl font-bold text-slate-800">{t("create_tontine")}</h1>
            <p className="text-sm text-slate-600">Configurez votre nouvelle tontine avec tous les détails</p>
          </div>
        </div>
      </div>

      {/* Formulaire */}
      <div className="p-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white">Informations de base</CardTitle>
            <p className="text-slate-400 text-sm">
              Remplissez tous les détails pour créer votre tontine. Vous aurez 24h pour modifier après création.
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Nom et description */}
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-white">{t("tontine_name")} *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    placeholder="Ex: Épargne pour mon mariage"
                    className="bg-slate-700 border-slate-600 text-white"
                    required
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Choisissez un nom clair et attractif pour votre tontine
                  </p>
                </div>

                <div>
                  <Label htmlFor="description" className="text-white">{t("description")}</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                    placeholder="Décrivez l'objectif de votre tontine et pourquoi les gens devraient la rejoindre..."
                    className="bg-slate-700 border-slate-600 text-white"
                    rows={3}
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Une bonne description aide les membres à comprendre l'objectif
                  </p>
                </div>
              </div>

              {/* Participants et montant */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="participants" className="text-white">Nombre de participants *</Label>
                  <Input
                    id="participants"
                    type="number"
                    value={formData.participants}
                    onChange={(e) => {
                      console.log("Participants modifiés:", e.target.value);
                      setFormData({...formData, participants: e.target.value});
                    }}
                    placeholder="4"
                    className="bg-slate-700 border-slate-600 text-white"
                    min="2"
                    max="20"
                    required
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Entre 2 et 20 participants recommandés
                  </p>
                </div>

                <div>
                  <Label htmlFor="amount" className="text-white">{t("contribution_amount")} (F CFA) *</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={formData.amount}
                    onChange={(e) => {
                      console.log("Montant modifié:", e.target.value);
                      setFormData({...formData, amount: e.target.value});
                    }}
                    placeholder="5000"
                    className="bg-slate-700 border-slate-600 text-white"
                    min="1000"
                    required
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Montant que chaque membre doit cotiser
                  </p>
                </div>
              </div>

              {/* Fréquence avec explications détaillées */}
              <div>
                <Label className="text-white">{t("frequency")} *</Label>
                <Select 
                  value={formData.frequency} 
                  onValueChange={(value) => {
                    console.log("Fréquence modifiée:", value);
                    setFormData({...formData, frequency: value});
                  }}
                >
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue placeholder={`Choisir la ${t("frequency").toLowerCase()}`} />
                  </SelectTrigger>
                  <SelectContent>
                    {frequencies.map((freq) => (
                      <SelectItem key={freq.value} value={freq.value}>
                        {freq.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="mt-2 p-3 bg-slate-700/50 rounded-lg">
                  <p className="text-xs text-slate-300">
                    <strong>Fréquences disponibles :</strong><br/>
                    • <strong>Hebdomadaire</strong> : Cotisation chaque semaine (idéal pour petits montants)<br/>
                    • <strong>Mensuel</strong> : Cotisation chaque mois (le plus courant)<br/>
                    • <strong>Trimestriel</strong> : Cotisation tous les 3 mois (pour gros montants)<br/>
                    • <strong>Personnalisée</strong> : Définissez votre propre rythme
                  </p>
                </div>
              </div>

              {formData.frequency === "custom" && (
                <div>
                  <Label htmlFor="customFrequency" className="text-white">Fréquence personnalisée (jours) *</Label>
                  <Input
                    id="customFrequency"
                    type="number"
                    value={formData.customFrequency}
                    onChange={(e) => setFormData({...formData, customFrequency: e.target.value})}
                    placeholder="15"
                    className="bg-slate-700 border-slate-600 text-white"
                    min="1"
                    max="365"
                  />
                  <p className="text-xs text-slate-400 mt-1">
                    Nombre de jours entre chaque cotisation (ex: 15 = toutes les 2 semaines)
                  </p>
                </div>
              )}

              {/* Paramètres avancés */}
              <div className="border-t border-slate-600 pt-6">
                <h4 className="text-white font-semibold mb-4">Paramètres avancés</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="penaltyRate" className="text-white">Taux de pénalité (%)</Label>
                    <Input
                      id="penaltyRate"
                      type="number"
                      value={formData.penaltyRate}
                      onChange={(e) => setFormData({...formData, penaltyRate: e.target.value})}
                      className="bg-slate-700 border-slate-600 text-white"
                      min="0"
                      max="20"
                    />
                    <p className="text-xs text-slate-400 mt-1">
                      Pénalité appliquée en cas de retard de paiement
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="maxMissedPayments" className="text-white">Cotisations manquées max</Label>
                    <Input
                      id="maxMissedPayments"
                      type="number"
                      value={formData.maxMissedPayments}
                      onChange={(e) => setFormData({...formData, maxMissedPayments: e.target.value})}
                      className="bg-slate-700 border-slate-600 text-white"
                      min="1"
                      max="10"
                    />
                    <p className="text-xs text-slate-400 mt-1">
                      Nombre de cotisations manquées avant exclusion
                    </p>
                  </div>
                </div>
              </div>

              {/* Upload d'images */}
              <div>
                <Label className="text-white">Photo de la tontine (optionnel - max 3)</Label>
                <div className="mt-2">
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleImageUpload}
                    className="hidden"
                    id="image-upload"
                  />
                  <Label
                    htmlFor="image-upload"
                    className="flex items-center justify-center w-full h-32 border-2 border-dashed border-slate-600 rounded-lg cursor-pointer hover:border-slate-500 transition-colors"
                  >
                    <div className="text-center">
                      <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                      <span className="text-slate-400">Cliquez pour ajouter des images</span>
                      <p className="text-xs text-slate-500 mt-1">
                        Ajoutez des images pour rendre votre tontine plus attractive
                      </p>
                    </div>
                  </Label>
                </div>
                
                {images.length > 0 && (
                  <div className="mt-4 grid grid-cols-3 gap-2">
                    {images.map((image, index) => (
                      <div key={index} className="relative">
                        <img
                          src={URL.createObjectURL(image)}
                          alt={`Preview ${index}`}
                          className="w-full h-20 object-cover rounded-lg"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600"
                        >
                          <X size={12} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Résumé de la tontine */}
              {formData.name && formData.participants && formData.amount && (
                <div className="bg-slate-700/50 rounded-lg p-4">
                  <h4 className="text-white font-semibold mb-2">📋 Résumé de votre tontine</h4>
                  <div className="text-sm text-slate-300 space-y-1">
                    <p><strong>Nom :</strong> {formData.name}</p>
                    <p><strong>Participants :</strong> {formData.participants} membres</p>
                    <p><strong>Cotisation :</strong> {parseInt(formData.amount).toLocaleString()} F CFA {formData.frequency && `(${frequencies.find(f => f.value === formData.frequency)?.label})`}</p>
                    {formData.participants && formData.amount && (
                      <p><strong>Objectif total :</strong> {(parseInt(formData.participants) * parseInt(formData.amount) * 12).toLocaleString()} F CFA</p>
                    )}
                  </div>
                </div>
              )}

              {/* Boutons */}
              <div className="flex gap-4 pt-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
                  onClick={() => onNavigate("tontines")}
                >
                  {t("cancel")}
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-white text-slate-900 hover:bg-slate-100"
                  disabled={loading}
                >
                  {loading ? "Création..." : t("create_tontine")}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};


import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { X, Copy, Share, QrCode } from "lucide-react";
import { useTontineShare } from "@/hooks/useTontineShare";

interface TontineShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  tontineId: string;
  tontineName: string;
}

export const TontineShareModal = ({ isOpen, onClose, tontineId, tontineName }: TontineShareModalProps) => {
  const { shareLink, isGenerating, generateShareLink, copyShareLink } = useTontineShare();
  const [currentLink, setCurrentLink] = useState<string>("");

  if (!isOpen) return null;

  const handleGenerateLink = async () => {
    const link = await generateShareLink(tontineId);
    if (link) {
      setCurrentLink(link);
    }
  };

  const handleCopyLink = () => {
    if (currentLink) {
      copyShareLink(currentLink, tontineName);
    }
  };

  const qrCodeUrl = currentLink 
    ? `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(currentLink)}`
    : "";

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">Partager la tontine</CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">"{tontineName}"</p>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {!currentLink ? (
            <div className="text-center">
              <Button 
                onClick={handleGenerateLink}
                disabled={isGenerating}
                className="w-full"
              >
                <Share className="w-4 h-4 mr-2" />
                {isGenerating ? "Génération..." : "Générer le lien de partage"}
              </Button>
            </div>
          ) : (
            <>
              <div className="space-y-2">
                <label className="text-sm font-medium">Lien de partage</label>
                <div className="flex gap-2">
                  <Input
                    value={currentLink}
                    readOnly
                    className="text-sm"
                  />
                  <Button size="sm" onClick={handleCopyLink}>
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {qrCodeUrl && (
                <div className="text-center space-y-2">
                  <div className="flex items-center justify-center gap-2">
                    <QrCode className="w-4 h-4" />
                    <span className="text-sm font-medium">Code QR</span>
                  </div>
                  <div className="flex justify-center">
                    <img 
                      src={qrCodeUrl}
                      alt="QR Code de partage"
                      className="w-32 h-32 border rounded-lg"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Scannez ce code pour rejoindre la tontine
                  </p>
                </div>
              )}

              <div className="flex gap-2">
                <Button variant="outline" onClick={onClose} className="flex-1">
                  Fermer
                </Button>
                <Button 
                  onClick={() => {
                    if (navigator.share) {
                      navigator.share({
                        title: `Rejoindre la tontine: ${tontineName}`,
                        text: `Rejoignez ma tontine "${tontineName}" sur NONRU`,
                        url: currentLink
                      });
                    } else {
                      copyShareLink(currentLink, tontineName);
                    }
                  }}
                  className="flex-1"
                >
                  <Share className="w-4 h-4 mr-2" />
                  Partager
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

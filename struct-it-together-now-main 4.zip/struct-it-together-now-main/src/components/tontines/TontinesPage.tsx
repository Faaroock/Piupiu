
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Plus, Users, Share, Eye } from "lucide-react";
import { NavigationPage } from "../dashboard/Dashboard";
import { useLanguage } from "@/contexts/LanguageContext";
import { TontineRequestsManager } from "./TontineRequestsManager";
import { TontineDetailsModal } from "./TontineDetailsModal";
import { NotificationBell } from "../notifications/NotificationBell";
import { NotificationCenter } from "../notifications/NotificationCenter";

interface TontinesPageProps {
  onNavigate: (page: NavigationPage) => void;
}

interface Tontine {
  id: string;
  name: string;
  description: string;
  contribution_amount: string;
  frequency: string;
  created_at: string;
  participants: number;
  current_amount: number;
  goal_amount: number;
  photo_url?: string;
  share_link?: string;
}

export const TontinesPage = ({ onNavigate }: TontinesPageProps) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<"mes-tontines" | "explorer" | "favoris" | "demandes">("mes-tontines");
  const [userTontines, setUserTontines] = useState<Tontine[]>([]);
  const [selectedTontine, setSelectedTontine] = useState<Tontine | null>(null);
  const [showTontineDetails, setShowTontineDetails] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    // Charger les tontines de l'utilisateur depuis le localStorage
    const savedTontines = localStorage.getItem('userTontines');
    if (savedTontines) {
      setUserTontines(JSON.parse(savedTontines));
    }
  }, []);

  const tabs = [
    { id: "mes-tontines" as const, label: t("my_tontines") },
    { id: "demandes" as const, label: t("requests") },
    { id: "explorer" as const, label: t("explore") },
    { id: "favoris" as const, label: t("favorites") },
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-FR').format(amount) + ' F';
  };

  const getProgressPercentage = (current: number, goal: number) => {
    return Math.min((current / goal) * 100, 100);
  };

  const handleTontineClick = (tontine: Tontine) => {
    setSelectedTontine(tontine);
    setShowTontineDetails(true);
  };

  const copyShareLink = async (shareLink: string, tontineName: string) => {
    try {
      await navigator.clipboard.writeText(shareLink);
      // Toast notification would go here
      console.log(`Lien copié pour ${tontineName}: ${shareLink}`);
    } catch (error) {
      console.error('Erreur copie du lien:', error);
    }
  };

  return (
    <div className="min-h-screen bg-slate-900">
      {/* Header */}
      <div className="bg-white p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => onNavigate("home")}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <ArrowLeft className="text-slate-800" size={20} />
            </button>
            <div>
              <h1 className="text-xl font-bold text-slate-800">{t("tontines")}</h1>
              <p className="text-sm text-slate-600">{t("manage")} {t("explore").toLowerCase()} {t("tontines").toLowerCase()}</p>
            </div>
          </div>
          
          {/* Notification Bell */}
          <NotificationBell onClick={() => setShowNotifications(true)} />
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-slate-800 mx-4 mt-4 rounded-lg p-1 flex">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition-colors ${
              activeTab === tab.id
                ? "bg-slate-700 text-white"
                : "text-slate-400 hover:text-white"
            }`}
          >
            {tab.label}
          </button>
        ))}
        <button 
          onClick={() => onNavigate("create")}
          className="p-2 text-slate-400 hover:text-white ml-2"
        >
          <Plus size={20} />
        </button>
      </div>

      {/* Content */}
      <div className="p-4">
        {activeTab === "mes-tontines" && (
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader>
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white">{t("my_tontines")}</h3>
                <Button 
                  onClick={() => onNavigate("create")}
                  className="bg-white text-slate-900 hover:bg-slate-100"
                  size="sm"
                >
                  <Plus size={16} className="mr-2" />
                  {t("create")}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {userTontines.length === 0 ? (
                <div className="text-center py-8">
                  <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                  <p className="text-slate-400 mb-4">{t("no_tontines")}</p>
                  <Button 
                    onClick={() => onNavigate("create")}
                    className="bg-white text-slate-900 hover:bg-slate-100"
                  >
                    {t("create_first_tontine")}
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {userTontines.map((tontine) => (
                    <div key={tontine.id} className="bg-slate-700 rounded-lg p-4 cursor-pointer hover:bg-slate-600 transition-colors">
                      {/* Photo de la tontine */}
                      {tontine.photo_url && (
                        <div className="mb-4">
                          <img
                            src={tontine.photo_url}
                            alt={tontine.name}
                            className="w-full h-32 object-cover rounded-lg"
                          />
                        </div>
                      )}
                      
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1" onClick={() => handleTontineClick(tontine)}>
                          <h4 className="text-white font-semibold text-lg">{tontine.name}</h4>
                          <p className="text-slate-300 text-sm">{tontine.description}</p>
                        </div>
                        <div className="flex items-center gap-2 ml-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleTontineClick(tontine);
                            }}
                            className="text-slate-400 hover:text-white"
                          >
                            <Eye size={16} />
                          </Button>
                          {tontine.share_link && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                copyShareLink(tontine.share_link!, tontine.name);
                              }}
                              className="text-slate-400 hover:text-white"
                            >
                              <Share size={16} />
                            </Button>
                          )}
                          <div className="text-right">
                            <p className="text-slate-400 text-xs">{tontine.participants} {t("members")}</p>
                            <p className="text-slate-400 text-xs">{t(tontine.frequency)}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-400">{t("contribution_amount")}</span>
                          <span className="text-white font-medium">{formatCurrency(parseInt(tontine.contribution_amount))}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-400">{t("current_amount")}</span>
                          <span className="text-green-400 font-medium">{formatCurrency(tontine.current_amount)}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-400">{t("goal_amount")}</span>
                          <span className="text-white font-medium">{formatCurrency(tontine.goal_amount)}</span>
                        </div>
                        
                        <div className="w-full bg-slate-600 rounded-full h-2 mt-3">
                          <div 
                            className="bg-green-500 h-2 rounded-full transition-all duration-300" 
                            style={{ width: `${getProgressPercentage(tontine.current_amount, tontine.goal_amount)}%` }}
                          ></div>
                        </div>
                        <p className="text-xs text-slate-400 mt-1">
                          {getProgressPercentage(tontine.current_amount, tontine.goal_amount).toFixed(1)}% {t("progress")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {activeTab === "demandes" && (
          <div className="bg-slate-800 border-slate-700 rounded-lg p-6">
            <TontineRequestsManager />
          </div>
        )}

        {activeTab === "explorer" && (
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="text-center py-8">
                <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400 mb-4">{t("no_public_tontines")}</p>
                <p className="text-sm text-slate-500">{t("created_tontines_appear_here")}</p>
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === "favoris" && (
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="p-6">
              <div className="text-center py-8">
                <Users className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                <p className="text-slate-400 mb-4">{t("no_favorite_tontines")}</p>
                <p className="text-sm text-slate-500">{t("add_tontines_to_favorites")}</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Modals */}
      <TontineDetailsModal
        isOpen={showTontineDetails}
        onClose={() => {
          setShowTontineDetails(false);
          setSelectedTontine(null);
        }}
        tontine={selectedTontine}
        isOwner={true}
      />

      <NotificationCenter
        isOpen={showNotifications}
        onClose={() => setShowNotifications(false)}
      />
    </div>
  );
};

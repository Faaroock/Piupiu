
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { AlertCircle, CheckCircle2, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const EmailVerificationBanner = () => {
  const [isEmailConfirmed, setIsEmailConfirmed] = useState<boolean | null>(null);
  const [isResending, setIsResending] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    const checkEmailConfirmation = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setIsEmailConfirmed(user.email_confirmed_at ? true : false);
      }
    };

    checkEmailConfirmation();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (session?.user) {
          setIsEmailConfirmed(session.user.email_confirmed_at ? true : false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const resendConfirmation = async () => {
    setIsResending(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user?.email) {
        const { error } = await supabase.auth.resend({
          type: 'signup',
          email: user.email,
          options: {
            emailRedirectTo: `${window.location.origin}/dashboard`
          }
        });

        if (error) {
          throw error;
        }

        toast({
          title: "Email de confirmation renvoyé",
          description: "Vérifiez votre boîte mail pour confirmer votre compte.",
          duration: 5000,
        });
      }
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: "Impossible de renvoyer l'email de confirmation.",
        variant: "destructive",
      });
    } finally {
      setIsResending(false);
    }
  };

  if (isEmailConfirmed === null) return null;

  if (isEmailConfirmed) {
    return (
      <Alert className="border-green-200 bg-green-50">
        <CheckCircle2 className="h-4 w-4 text-green-600" />
        <AlertDescription className="text-green-800">
          Votre adresse email est confirmée ✓
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Alert className="border-orange-200 bg-orange-50">
      <AlertCircle className="h-4 w-4 text-orange-600" />
      <AlertDescription className="text-orange-800 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Mail className="h-4 w-4" />
          <span>
            Veuillez confirmer votre adresse email pour accéder à toutes les fonctionnalités.
          </span>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={resendConfirmation}
          disabled={isResending}
          className="ml-4 border-orange-300 text-orange-700 hover:bg-orange-100"
        >
          {isResending ? "Envoi..." : "Renvoyer"}
        </Button>
      </AlertDescription>
    </Alert>
  );
};


import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Eye, EyeOff } from "lucide-react";

interface LoginFormProps {
  onLogin: () => void;
}

export const LoginForm = ({ onLogin }: LoginFormProps) => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLogin) {
      setShowSuccess(true);
      setTimeout(() => {
        onLogin();
      }, 2000);
    } else {
      setIsLogin(true);
    }
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <Card className="w-full max-w-md bg-slate-800 border-slate-700 animate-fade-in">
          <CardHeader className="text-center">
            <h2 className="text-xl font-semibold text-white">Connexion réussie</h2>
            <p className="text-slate-400">Bienvenue sur NONRU !</p>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6 animate-fade-in">
        {!isLogin && (
          <Card className="bg-slate-800 border-slate-700">
            <CardHeader className="text-center">
              <h2 className="text-xl font-semibold text-white">Déconnexion</h2>
              <p className="text-slate-400">Vous avez été déconnecté avec succès</p>
            </CardHeader>
          </Card>
        )}
        
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader className="text-center space-y-4">
            <div className="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mx-auto">
              <span className="text-2xl">💰</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">NONRU</h1>
              <p className="text-slate-400">Connectez-vous à votre compte</p>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-white mb-2">
                  Email
                </label>
                <Input
                  type="email"
                  placeholder="votre@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-yellow-500"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-white mb-2">
                  Mot de passe
                </label>
                <div className="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="bg-slate-700 border-slate-600 text-white placeholder-slate-400 focus:border-yellow-500 pr-10"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                  </button>
                </div>
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-white text-slate-900 hover:bg-slate-100 font-medium"
              >
                Se connecter
              </Button>
            </form>
            
            <div className="text-center space-y-2">
              <button className="text-slate-400 hover:text-white text-sm">
                Mot de passe oublié ?
              </button>
              <div>
                <button 
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-slate-400 hover:text-white text-sm"
                >
                  Pas de compte ? S'inscrire
                </button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

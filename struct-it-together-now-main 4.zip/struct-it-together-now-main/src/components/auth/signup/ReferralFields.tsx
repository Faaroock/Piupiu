
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertCircle } from "lucide-react";

interface ReferralFieldsProps {
  referralSource: string;
  referralOther: string;
  referralCode?: string;
  errors: { [key: string]: string };
  onSelectChange: (value: string) => void;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const referralSources = [
  { value: "friend", label: "Un ami/proche" },
  { value: "social_media", label: "Réseaux sociaux (Facebook, Instagram, etc.)" },
  { value: "google", label: "Recherche Google" },
  { value: "advertisement", label: "Publicité" },
  { value: "word_of_mouth", label: "Bouche à oreille" },
  { value: "event", label: "Événement/Conférence" },
  { value: "other", label: "Autre" },
];

export const ReferralFields = ({ 
  referralSource, 
  referralOther, 
  referralCode,
  errors, 
  onSelectChange, 
  onChange 
}: ReferralFieldsProps) => {
  return (
    <>
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Comment avez-vous connu NONRU ? *
        </label>
        <Select value={referralSource} onValueChange={onSelectChange}>
          <SelectTrigger className={errors.referralSource ? "border-red-500 focus:border-red-500" : ""}>
            <SelectValue placeholder="Sélectionnez une option" />
          </SelectTrigger>
          <SelectContent>
            {referralSources.map((source) => (
              <SelectItem key={source.value} value={source.value}>
                {source.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.referralSource && (
          <p className="text-red-500 text-xs mt-1 flex items-center">
            <AlertCircle className="w-3 h-3 mr-1" />
            {errors.referralSource}
          </p>
        )}
      </div>

      {referralSource === "other" && (
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Précisez *
          </label>
          <Input
            name="referralOther"
            type="text"
            placeholder="Décrivez comment vous avez connu NONRU"
            value={referralOther}
            onChange={onChange}
            className={errors.referralOther ? "border-red-500 focus:border-red-500" : ""}
          />
          {errors.referralOther && (
            <p className="text-red-500 text-xs mt-1 flex items-center">
              <AlertCircle className="w-3 h-3 mr-1" />
              {errors.referralOther}
            </p>
          )}
        </div>
      )}

      {referralCode && (
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Code de parrainage (facultatif)
          </label>
          <Input
            name="referralCode"
            type="text"
            placeholder="Entrez le code de parrainage"
            value={referralCode}
            onChange={onChange}
            className="bg-green-50 border-green-200"
            readOnly
          />
          <p className="text-green-600 text-xs mt-1">
            ✓ Code de parrainage détecté automatiquement
          </p>
        </div>
      )}
    </>
  );
};

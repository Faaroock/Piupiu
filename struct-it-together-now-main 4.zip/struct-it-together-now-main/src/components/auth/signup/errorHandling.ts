
export const getSignUpErrorMessage = (error: any, t: (key: string) => string): string => {
  let errorMessage = t('technical_error') || "Une erreur s'est produite lors de l'inscription.";
  
  console.log('🔍 [ERROR HANDLING] Type d\'erreur détecté:', error);
  
  // Messages d'erreur spécifiques basés sur le type d'erreur
  if (error.message?.includes("User already registered") || 
      error.message?.includes("already registered") ||
      error.message?.includes("email_address_already_registered") ||
      error.message?.includes("already_in_use")) {
    errorMessage = t('email_already_used') || "Cette adresse email est déjà utilisée.";
    console.log('⚠️ [INSCRIPTION] Erreur: Email déjà utilisé');
  } else if (error.message?.includes("Password") || 
             error.message?.includes("password") ||
             error.message?.includes("weak_password")) {
    errorMessage = t('password_security_error') || "Le mot de passe ne respecte pas les critères de sécurité.";
    console.log('⚠️ [INSCRIPTION] Erreur: Mot de passe invalide');
  } else if (error.message?.includes("âge requis") || 
             error.message?.includes("age") ||
             error.message?.includes("invalid_age")) {
    errorMessage = t('age_minimum') || "Vous n'avez pas l'âge requis pour vous inscrire sur Nonru";
    console.log('⚠️ [INSCRIPTION] Erreur: Âge insuffisant');
  } else if (error.message?.includes("reCAPTCHA") || 
             error.message?.includes("robot") || 
             error.message?.includes("vérification") || 
             error.message?.includes("captcha") ||
             error.message?.includes("verification_failed")) {
    errorMessage = t('recaptcha_failed') || "Vérification de sécurité échouée. Merci de cocher la case pour confirmer que vous n'êtes pas un robot.";
    console.log('⚠️ [INSCRIPTION] Erreur: Validation reCAPTCHA échouée');
  } else if (error.message?.includes("notifications") || 
             error.message?.includes("foreign key") ||
             error.message?.includes("constraint") ||
             error.message?.includes("violates") ||
             error.message?.includes("database") ||
             error.message?.includes("Database error")) {
    errorMessage = "Erreur temporaire du système. Votre compte a peut-être été créé avec succès, veuillez vérifier votre email.";
    console.log('⚠️ [INSCRIPTION] Erreur: Problème de base de données (probablement résolu)');
  } else if (error.message?.includes("network") || 
             error.message?.includes("fetch") ||
             error.message?.includes("NetworkError")) {
    errorMessage = "Erreur de connexion. Vérifiez votre connexion internet et réessayez.";
    console.log('⚠️ [INSCRIPTION] Erreur: Problème de réseau');
  } else if (error.message?.includes("rate") || 
             error.message?.includes("limit")) {
    errorMessage = "Trop de tentatives. Veuillez attendre quelques minutes avant de réessayer.";
    console.log('⚠️ [INSCRIPTION] Erreur: Limite de taux atteinte');
  } else if (error.message?.includes("unexpected_failure") ||
             error.message?.includes("500")) {
    errorMessage = "Erreur temporaire du serveur. Veuillez réessayer dans quelques instants.";
    console.log('⚠️ [INSCRIPTION] Erreur: Erreur serveur 500');
  } else if (error.message) {
    errorMessage = error.message;
    console.log('⚠️ [INSCRIPTION] Erreur personnalisée:', error.message);
  }
  
  return errorMessage;
};

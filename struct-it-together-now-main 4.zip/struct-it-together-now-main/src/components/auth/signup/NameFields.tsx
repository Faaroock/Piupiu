
import { Input } from "@/components/ui/input";
import { AlertCircle } from "lucide-react";

interface NameFieldsProps {
  firstName: string;
  lastName: string;
  errors: { [key: string]: string };
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const NameFields = ({ firstName, lastName, errors, onChange }: NameFieldsProps) => {
  return (
    <div className="grid grid-cols-2 gap-4">
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Prénom *
        </label>
        <Input
          name="firstName"
          type="text"
          placeholder="Votre prénom"
          value={firstName}
          onChange={onChange}
          className={errors.firstName ? "border-red-500 focus:border-red-500" : ""}
        />
        {errors.firstName && (
          <p className="text-red-500 text-xs mt-1 flex items-center">
            <AlertCircle className="w-3 h-3 mr-1" />
            {errors.firstName}
          </p>
        )}
      </div>
      
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Nom *
        </label>
        <Input
          name="lastName"
          type="text"
          placeholder="Votre nom"
          value={lastName}
          onChange={onChange}
          className={errors.lastName ? "border-red-500 focus:border-red-500" : ""}
        />
        {errors.lastName && (
          <p className="text-red-500 text-xs mt-1 flex items-center">
            <AlertCircle className="w-3 h-3 mr-1" />
            {errors.lastName}
          </p>
        )}
      </div>
    </div>
  );
};

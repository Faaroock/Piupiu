
import { Input } from "@/components/ui/input";
import { AlertCircle } from "lucide-react";

interface EmailFieldProps {
  email: string;
  errors: { [key: string]: string };
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const EmailField = ({ email, errors, onChange }: EmailFieldProps) => {
  return (
    <div>
      <label className="block text-sm font-medium text-foreground mb-2">
        Email *
      </label>
      <Input
        name="email"
        type="email"
        placeholder="votre@email.com"
        value={email}
        onChange={onChange}
        className={errors.email ? "border-red-500 focus:border-red-500" : ""}
      />
      {errors.email && (
        <p className="text-red-500 text-xs mt-1 flex items-center">
          <AlertCircle className="w-3 h-3 mr-1" />
          {errors.email}
        </p>
      )}
    </div>
  );
};

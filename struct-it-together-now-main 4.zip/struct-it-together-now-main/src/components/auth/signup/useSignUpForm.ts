
import { useState } from 'react';
import { validateSignUpForm, FormData } from './validation';
import { getSignUpErrorMessage } from './errorHandling';
import { authService } from '@/services/authService';
import { useLanguage } from '@/contexts/LanguageContext';
import { toast } from 'sonner';

export const useSignUpForm = () => {
  const { t } = useLanguage();
  
  const [formData, setFormData] = useState<FormData>({
    firstName: '',
    lastName: '',
    email: '',
    age: '',
    password: '',
    confirmPassword: '',
    referralSource: '',
    referralOther: '',
    referralCode: '',
    termsAccepted: false,
    privacyAccepted: false,
  });

  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [isLoading, setIsLoading] = useState(false);
  const [generalError, setGeneralError] = useState<string | null>(null);
  const [recaptchaToken, setRecaptchaToken] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
    // Clear errors when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSelectChange = (value: string) => {
    setFormData(prev => ({
      ...prev,
      referralSource: value,
      referralOther: value === 'other' ? prev.referralOther : ''
    }));
    // Clear errors when user makes selection
    if (errors.referralSource) {
      setErrors(prev => ({ ...prev, referralSource: '' }));
    }
  };

  const handleTermsChange = (checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      termsAccepted: checked,
    }));
    // Clear errors when user accepts terms
    if (errors.termsAccepted) {
      setErrors(prev => ({ ...prev, termsAccepted: '' }));
    }
  };

  const handlePrivacyChange = (checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      privacyAccepted: checked,
    }));
    // Clear errors when user accepts privacy
    if (errors.privacyAccepted) {
      setErrors(prev => ({ ...prev, privacyAccepted: '' }));
    }
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    
    console.log('🚀 [INSCRIPTION] Début de la soumission du formulaire');
    
    // Reset previous errors
    setErrors({});
    setGeneralError(null);

    // Validation du formulaire
    const validationResult = validateSignUpForm(formData, t);
    
    if (!validationResult.isValid) {
      console.log('❌ [INSCRIPTION] Validation échouée:', validationResult.errors);
      setErrors(validationResult.errors);
      
      // Message spécial pour l'acceptation des conditions
      if (validationResult.errors.termsAccepted || validationResult.errors.privacyAccepted) {
        toast.error('Vous devez accepter les Conditions d\'Utilisation et la Politique de Confidentialité pour créer votre compte');
      } else {
        toast.error(t('form_validation_error') || 'Veuillez corriger les erreurs du formulaire');
      }
      return;
    }

    // Vérifier que reCAPTCHA est valide
    if (!recaptchaToken) {
      const errorMsg = t('recaptcha_required') || 'Veuillez confirmer que vous n\'êtes pas un robot';
      setGeneralError(errorMsg);
      toast.error(errorMsg);
      return;
    }

    setIsLoading(true);

    try {
      console.log('👤 [INSCRIPTION] Appel du service d\'inscription...');

      // Préparer les métadonnées utilisateur
      const metadata = {
        first_name: formData.firstName.trim(),
        last_name: formData.lastName.trim(),
        age: parseInt(formData.age),
        referral_source: formData.referralSource,
        referral_other: formData.referralOther.trim(),
        referral_code: formData.referralCode?.trim() || null,
        terms_accepted: formData.termsAccepted,
        privacy_accepted: formData.privacyAccepted,
        terms_accepted_at: new Date().toISOString(),
        privacy_accepted_at: new Date().toISOString(),
      };

      // Appeler le service d'inscription directement
      await authService.signup(
        formData.email.trim(),
        formData.password,
        `${formData.firstName.trim()} ${formData.lastName.trim()}`,
        metadata
      );

      console.log('✅ [INSCRIPTION] Inscription réussie');
      
      toast.success(t('account_created_success') || 'Compte créé avec succès ! Vérifiez votre email.');
      
      // Réinitialiser le formulaire
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        age: '',
        password: '',
        confirmPassword: '',
        referralSource: '',
        referralOther: '',
        referralCode: '',
        termsAccepted: false,
        privacyAccepted: false,
      });
      
      setRecaptchaToken(null);

    } catch (error: any) {
      console.error('❌ [INSCRIPTION] Erreur lors de l\'inscription:', error);
      
      const errorMessage = getSignUpErrorMessage(error, t);
      setGeneralError(errorMessage);
      toast.error(errorMessage);
      
      // Réinitialiser le reCAPTCHA en cas d'erreur
      setRecaptchaToken(null);
      
      // Reset reCAPTCHA widget if available
      if (window.grecaptcha) {
        window.grecaptcha.reset();
      }
    } finally {
      setIsLoading(false);
    }
  };

  return {
    formData,
    errors,
    isLoading,
    loading: isLoading, // Alias pour compatibilité
    generalError,
    recaptchaToken,
    setRecaptchaToken,
    handleChange,
    handleSelectChange,
    handleTermsChange,
    handlePrivacyChange,
    handleSubmit,
  };
};


export interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  age: string;
  password: string;
  confirmPassword: string;
  referralSource: string;
  referralOther: string;
  referralCode?: string;
  termsAccepted: boolean;
  privacyAccepted: boolean;
}

export interface ValidationResult {
  isValid: boolean;
  errors: { [key: string]: string };
}

export const validateSignUpForm = (
  formData: FormData,
  t: (key: string) => string
): ValidationResult => {
  const errors: { [key: string]: string } = {};

  // Validation prénom
  if (!formData.firstName.trim()) {
    errors.firstName = t('first_name_required') || 'Le prénom est requis';
  } else if (formData.firstName.trim().length < 2) {
    errors.firstName = t('first_name_too_short') || 'Le prénom doit contenir au moins 2 caractères';
  }

  // Validation nom
  if (!formData.lastName.trim()) {
    errors.lastName = t('last_name_required') || 'Le nom est requis';
  } else if (formData.lastName.trim().length < 2) {
    errors.lastName = t('last_name_too_short') || 'Le nom doit contenir au moins 2 caractères';
  }

  // Validation email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!formData.email.trim()) {
    errors.email = t('email_required') || 'L\'email est requis';
  } else if (!emailRegex.test(formData.email.trim())) {
    errors.email = t('email_invalid') || 'Format d\'email invalide';
  }

  // Validation âge
  const age = parseInt(formData.age);
  if (!formData.age.trim()) {
    errors.age = t('age_required') || 'L\'âge est requis';
  } else if (isNaN(age) || age < 13 || age > 100) {
    errors.age = t('age_invalid') || 'L\'âge doit être entre 13 et 100 ans';
  }

  // Validation mot de passe
  if (!formData.password) {
    errors.password = t('password_required') || 'Le mot de passe est requis';
  } else if (formData.password.length < 8) {
    errors.password = t('password_too_short') || 'Le mot de passe doit contenir au moins 8 caractères';
  }

  // Validation confirmation mot de passe
  if (!formData.confirmPassword) {
    errors.confirmPassword = t('confirm_password_required') || 'La confirmation du mot de passe est requise';
  } else if (formData.password !== formData.confirmPassword) {
    errors.confirmPassword = t('passwords_dont_match') || 'Les mots de passe ne correspondent pas';
  }

  // Validation source de parrainage
  if (!formData.referralSource) {
    errors.referralSource = t('referral_source_required') || 'Veuillez indiquer comment vous avez connu NONRU';
  }

  // Validation "autre" si sélectionné
  if (formData.referralSource === 'other' && !formData.referralOther.trim()) {
    errors.referralOther = t('referral_other_required') || 'Veuillez préciser comment vous avez connu NONRU';
  }

  // Validation acceptation des conditions d'utilisation
  if (!formData.termsAccepted) {
    errors.termsAccepted = t('terms_acceptance_required') || 'Vous devez accepter les Conditions d\'Utilisation pour continuer';
  }

  // Validation acceptation de la politique de confidentialité
  if (!formData.privacyAccepted) {
    errors.privacyAccepted = t('privacy_acceptance_required') || 'Vous devez accepter la Politique de Confidentialité pour continuer';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

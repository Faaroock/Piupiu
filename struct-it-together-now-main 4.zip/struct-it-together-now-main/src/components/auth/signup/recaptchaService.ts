
import { supabase } from "@/integrations/supabase/client";

export const verifyRecaptcha = async (token: string) => {
  try {
    console.log('🔐 [RECAPTCHA] Début de la vérification côté serveur');
    
    const { data, error } = await supabase.functions.invoke('verify-recaptcha', {
      body: { token }
    });

    console.log('🔐 [RECAPTCHA] Réponse de la fonction edge:', { data, error });

    if (error) {
      console.error('❌ [RECAPTCHA] Erreur lors de l\'appel à la fonction verify-recaptcha:', error);
      throw new Error(`Erreur de vérification reCAPTCHA: ${error.message}`);
    }

    if (!data || !data.success) {
      console.error('❌ [RECAPTCHA] Validation échouée:', data);
      throw new Error('Vérification reCAPTCHA échouée');
    }

    console.log('✅ [RECAPTCHA] Validation réussie');
    return true;
  } catch (error) {
    console.error('💥 [RECAPTCHA] Erreur critique lors de la vérification:', error);
    throw error;
  }
};

export const getRecaptchaToken = () => {
  return window.grecaptcha ? window.grecaptcha.getResponse() : null;
};

export const resetRecaptcha = () => {
  if (window.grecaptcha) {
    window.grecaptcha.reset();
  }
};

export const executeReCaptcha = async (): Promise<string | null> => {
  return new Promise((resolve) => {
    const token = getRecaptchaToken();
    if (token) {
      resolve(token);
    } else {
      resolve(null);
    }
  });
};

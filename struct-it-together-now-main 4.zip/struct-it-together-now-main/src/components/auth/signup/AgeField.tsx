
import { Input } from "@/components/ui/input";
import { AlertCircle } from "lucide-react";

interface AgeFieldProps {
  age: string;
  errors: { [key: string]: string };
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export const AgeField = ({ age, errors, onChange }: AgeFieldProps) => {
  const handleAgeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Complètement désactiver la validation HTML5
    e.target.setCustomValidity('');
    onChange(e);
  };

  const handleInvalid = (e: React.InvalidEvent<HTMLInputElement>) => {
    // Empêcher complètement le message de validation HTML5
    e.preventDefault();
    e.target.setCustomValidity('');
  };

  return (
    <div>
      <label className="block text-sm font-medium text-foreground mb-2">
        Âge *
      </label>
      <Input
        name="age"
        type="number"
        placeholder="Votre âge"
        value={age}
        onChange={handleAgeChange}
        onInvalid={handleInvalid}
        // Désactiver complètement la validation HTML5 avec noValidate
        data-no-validate="true"
        style={{ WebkitAppearance: 'textfield' }}
        className={errors.age ? "border-red-500 focus:border-red-500" : ""}
        // Supprimer les attributs min/max qui déclenchent la validation HTML5
      />
      {errors.age && (
        <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-600 text-sm flex items-start">
            <AlertCircle className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
            {errors.age}
          </p>
        </div>
      )}
    </div>
  );
};

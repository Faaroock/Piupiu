
import { FormData } from "./validation";

export const createInitialFormData = (): FormData => ({
  firstName: "",
  lastName: "",
  email: "",
  age: "",
  password: "",
  confirmPassword: "",
  referralSource: "",
  referralOther: "",
  referralCode: "",
  termsAccepted: false,
  privacyAccepted: false,
});

export const prepareUserMetadata = (formData: FormData) => {
  return {
    first_name: formData.firstName,
    last_name: formData.lastName,
    age: parseInt(formData.age),
    referral_source: formData.referralSource,
    referral_other: formData.referralSource === "other" ? formData.referralOther : null,
    referral_code: formData.referralCode || null,
    is_new_user: true,
  };
};

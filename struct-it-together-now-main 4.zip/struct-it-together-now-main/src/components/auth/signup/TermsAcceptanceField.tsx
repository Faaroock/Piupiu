
import { Checkbox } from "@/components/ui/checkbox";
import { AlertCircle } from "lucide-react";
import { Link } from "react-router-dom";

interface TermsAcceptanceFieldProps {
  termsAccepted: boolean;
  privacyAccepted: boolean;
  errors: { [key: string]: string };
  onTermsChange: (checked: boolean) => void;
  onPrivacyChange: (checked: boolean) => void;
}

export const TermsAcceptanceField = ({ 
  termsAccepted, 
  privacyAccepted, 
  errors, 
  onTermsChange, 
  onPrivacyChange 
}: TermsAcceptanceFieldProps) => {
  return (
    <div className="space-y-4">
      {/* Case à cocher principale - obligatoire */}
      <div className="border rounded-lg p-4 bg-blue-50 border-blue-200">
        <div className="flex items-start space-x-3">
          <Checkbox
            id="terms-main"
            checked={termsAccepted && privacyAccepted}
            onCheckedChange={(checked) => {
              const isChecked = checked === true;
              onTermsChange(isChecked);
              onPrivacyChange(isChecked);
            }}
            className="mt-1"
          />
          <div className="flex-1">
            <label htmlFor="terms-main" className="text-sm font-medium text-blue-900 cursor-pointer">
              Je certifie avoir lu et accepté les{" "}
              <Link 
                to="/terms" 
                target="_blank"
                className="text-blue-600 hover:text-blue-800 underline"
              >
                Conditions d'Utilisation
              </Link>
              {" "}et la{" "}
              <Link 
                to="/privacy" 
                target="_blank"
                className="text-blue-600 hover:text-blue-800 underline"
              >
                Politique de Confidentialité
              </Link>
              {" "}de NONRU. *
            </label>
            <p className="text-xs text-blue-700 mt-1">
              Cette case est obligatoire pour créer votre compte.
            </p>
          </div>
        </div>
        {(errors.termsAccepted || errors.privacyAccepted) && (
          <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded">
            <p className="text-red-600 text-xs flex items-center">
              <AlertCircle className="w-3 h-3 mr-1" />
              {errors.termsAccepted || errors.privacyAccepted}
            </p>
          </div>
        )}
      </div>

      {/* Cases à cocher détaillées */}
      <div className="space-y-3 bg-gray-50 p-3 rounded-lg">
        <p className="text-xs text-gray-600 font-medium">Détail de l'acceptation :</p>
        
        <div className="flex items-start space-x-3">
          <Checkbox
            id="terms-detailed"
            checked={termsAccepted}
            onCheckedChange={(checked) => onTermsChange(checked === true)}
          />
          <label htmlFor="terms-detailed" className="text-xs text-gray-700 cursor-pointer">
            ✅ J'ai lu et j'accepte les{" "}
            <Link 
              to="/terms" 
              target="_blank"
              className="text-primary hover:underline"
            >
              Conditions Générales d'Utilisation
            </Link>
          </label>
        </div>
        
        <div className="flex items-start space-x-3">
          <Checkbox
            id="privacy-detailed"
            checked={privacyAccepted}
            onCheckedChange={(checked) => onPrivacyChange(checked === true)}
          />
          <label htmlFor="privacy-detailed" className="text-xs text-gray-700 cursor-pointer">
            ✅ J'ai lu et j'accepte la{" "}
            <Link 
              to="/privacy" 
              target="_blank"
              className="text-primary hover:underline"
            >
              Politique de Confidentialité
            </Link>
          </label>
        </div>
      </div>

      {/* Message d'information sur les cookies */}
      <div className="bg-green-50 border border-green-200 rounded-lg p-3">
        <p className="text-green-800 text-xs">
          🍪 <strong>Cookies :</strong> NONRU utilise uniquement des cookies essentiels pour le fonctionnement du site (authentification, sécurité). Aucun cookie marketing ou de tracking n'est utilisé.
        </p>
      </div>
    </div>
  );
};

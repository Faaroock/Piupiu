
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, ArrowLeft, AlertCircle, Shield } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { RecaptchaWrapper } from "./RecaptchaWrapper";

const EnhancedSignUp = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [recaptchaToken, setRecaptchaToken] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    age: "",
    password: "",
    confirmPassword: "",
    referralSource: "",
    referralOther: "",
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  
  const { signup } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const referralSources = [
    { value: "friend", label: "Un ami/proche" },
    { value: "social_media", label: "Réseaux sociaux (Facebook, Instagram, etc.)" },
    { value: "google", label: "Recherche Google" },
    { value: "advertisement", label: "Publicité" },
    { value: "word_of_mouth", label: "Bouche à oreille" },
    { value: "event", label: "Événement/Conférence" },
    { value: "other", label: "Autre" },
  ];

  const validateForm = () => {
    const newErrors: {[key: string]: string} = {};

    // Validation nom et prénom
    if (!formData.firstName.trim()) {
      newErrors.firstName = "Le prénom est obligatoire";
    }
    if (!formData.lastName.trim()) {
      newErrors.lastName = "Le nom est obligatoire";
    }

    // Validation email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email) {
      newErrors.email = "L'email est obligatoire";
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = "Format d'email invalide";
    }

    // Validation âge avec message professionnel et empathique
    const age = parseInt(formData.age);
    if (!formData.age) {
      newErrors.age = "L'âge est obligatoire";
    } else if (age < 15) {
      newErrors.age = "Nous comprenons votre intérêt pour NONRU, mais notre plateforme est réservée aux personnes âgées d'au moins 15 ans pour des raisons légales et de sécurité.";
    } else if (age > 120) {
      newErrors.age = "Âge invalide";
    }

    // Validation mot de passe renforcée
    if (!formData.password) {
      newErrors.password = "Le mot de passe est obligatoire";
    } else if (formData.password.length < 8) {
      newErrors.password = "Le mot de passe doit contenir au moins 8 caractères";
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(formData.password)) {
      newErrors.password = "Le mot de passe doit contenir au moins une majuscule, une minuscule et un chiffre";
    }

    // Validation confirmation mot de passe
    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Les mots de passe ne correspondent pas";
    }

    // Validation source de parrainage
    if (!formData.referralSource) {
      newErrors.referralSource = "Veuillez indiquer comment vous avez connu NONRU";
    }

    // Si "Autre" est sélectionné, vérifier le champ libre
    if (formData.referralSource === "other" && !formData.referralOther.trim()) {
      newErrors.referralOther = "Veuillez préciser comment vous avez connu NONRU";
    }

    // Validation reCAPTCHA
    if (!recaptchaToken) {
      newErrors.recaptcha = "Veuillez compléter la vérification de sécurité";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    
    // Effacer l'erreur du champ modifié
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: "" }));
    }
  };

  const handleSelectChange = (value: string) => {
    setFormData(prev => ({ ...prev, referralSource: value }));
    if (errors.referralSource) {
      setErrors(prev => ({ ...prev, referralSource: "" }));
    }
    
    // Reset referralOther si on ne sélectionne pas "Autre"
    if (value !== "other") {
      setFormData(prev => ({ ...prev, referralOther: "" }));
    }
  };

  const handleRecaptchaVerify = (token: string) => {
    setRecaptchaToken(token);
    if (errors.recaptcha) {
      setErrors(prev => ({ ...prev, recaptcha: "" }));
    }
  };

  const handleRecaptchaExpired = () => {
    setRecaptchaToken(null);
    setErrors(prev => ({ ...prev, recaptcha: "La vérification a expiré, veuillez recommencer" }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      // Afficher l'erreur d'âge de manière prominente si elle existe
      if (errors.age && parseInt(formData.age) < 15) {
        toast({
          title: "Âge insuffisant",
          description: "Nous comprenons votre intérêt pour NONRU, mais notre plateforme est réservée aux personnes âgées d'au moins 15 ans pour des raisons légales et de sécurité.",
          variant: "destructive",
          duration: 8000,
        });
      } else {
        toast({
          title: "Erreur de validation",
          description: "Veuillez corriger les erreurs dans le formulaire.",
          variant: "destructive",
        });
      }
      return;
    }

    setLoading(true);
    
    try {
      // Préparer les métadonnées utilisateur
      const userMetadata = {
        first_name: formData.firstName,
        last_name: formData.lastName,
        age: parseInt(formData.age),
        referral_source: formData.referralSource,
        referral_other: formData.referralSource === "other" ? formData.referralOther : null,
        is_new_user: true,
        recaptcha_token: recaptchaToken,
      };

      await signup(formData.email, formData.password, formData.firstName, userMetadata);
      
      toast({
        title: "Inscription réussie !",
        description: "Un email de confirmation vous a été envoyé. Vérifiez votre boîte mail pour activer votre compte.",
        duration: 8000,
      });
      
      navigate("/dashboard");
    } catch (error: any) {
      let errorMessage = "Une erreur s'est produite lors de l'inscription.";
      
      if (error.message?.includes("User already registered")) {
        errorMessage = "Cette adresse email est déjà utilisée.";
      } else if (error.message?.includes("Password")) {
        errorMessage = "Le mot de passe ne respecte pas les critères de sécurité.";
      } else if (error.message?.includes("âge")) {
        errorMessage = "Nous comprenons votre intérêt pour NONRU, mais notre plateforme est réservée aux personnes âgées d'au moins 15 ans pour des raisons légales et de sécurité.";
      }
      
      toast({
        title: "Erreur d'inscription",
        description: errorMessage,
        variant: "destructive",
        duration: 6000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6 animate-fade-in">
        <Button variant="ghost" asChild className="mb-4">
          <Link to="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour à l'accueil
          </Link>
        </Button>

        <Card className="border-border">
          <CardHeader className="text-center space-y-4">
            <div className="w-16 h-16 bg-[#fab005] rounded-full flex items-center justify-center mx-auto">
              <span className="text-2xl">💰</span>
            </div>
            <div>
              <CardTitle className="text-2xl font-bold text-foreground">NONRU</CardTitle>
              <p className="text-muted-foreground">Créez votre compte sécurisé</p>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Nom et Prénom */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Prénom *
                  </label>
                  <Input
                    name="firstName"
                    type="text"
                    placeholder="Votre prénom"
                    value={formData.firstName}
                    onChange={handleChange}
                    className={errors.firstName ? "border-red-500 focus:border-red-500" : ""}
                  />
                  {errors.firstName && (
                    <p className="text-red-500 text-xs mt-1 flex items-center">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      {errors.firstName}
                    </p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Nom *
                  </label>
                  <Input
                    name="lastName"
                    type="text"
                    placeholder="Votre nom"
                    value={formData.lastName}
                    onChange={handleChange}
                    className={errors.lastName ? "border-red-500 focus:border-red-500" : ""}
                  />
                  {errors.lastName && (
                    <p className="text-red-500 text-xs mt-1 flex items-center">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      {errors.lastName}
                    </p>
                  )}
                </div>
              </div>

              {/* Âge */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Âge *
                </label>
                <Input
                  name="age"
                  type="number"
                  min="15"
                  max="120"
                  placeholder="Votre âge"
                  value={formData.age}
                  onChange={handleChange}
                  className={errors.age ? "border-red-500 focus:border-red-500" : ""}
                />
                {errors.age && (
                  <div className="mt-2 p-3 bg-red-50 border border-red-200 rounded-md">
                    <p className="text-red-600 text-sm flex items-start">
                      <AlertCircle className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0" />
                      {errors.age}
                    </p>
                  </div>
                )}
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Email *
                </label>
                <Input
                  name="email"
                  type="email"
                  placeholder="votre@email.com"
                  value={formData.email}
                  onChange={handleChange}
                  className={errors.email ? "border-red-500 focus:border-red-500" : ""}
                />
                {errors.email && (
                  <p className="text-red-500 text-xs mt-1 flex items-center">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    {errors.email}
                  </p>
                )}
              </div>
              
              {/* Mot de passe */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Mot de passe *
                </label>
                <div className="relative">
                  <Input
                    name="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={handleChange}
                    className={`pr-10 ${errors.password ? "border-red-500 focus:border-red-500" : ""}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Minimum 8 caractères avec majuscule, minuscule et chiffre
                </p>
                {errors.password && (
                  <p className="text-red-500 text-xs mt-1 flex items-center">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    {errors.password}
                  </p>
                )}
              </div>

              {/* Confirmation mot de passe */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Confirmer le mot de passe *
                </label>
                <div className="relative">
                  <Input
                    name="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={handleChange}
                    className={`pr-10 ${errors.confirmPassword ? "border-red-500 focus:border-red-500" : ""}`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {errors.confirmPassword && (
                  <p className="text-red-500 text-xs mt-1 flex items-center">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    {errors.confirmPassword}
                  </p>
                )}
              </div>

              {/* Source de parrainage */}
              <div>
                <label className="block text-sm font-medium text-foreground mb-2">
                  Comment avez-vous connu NONRU ? *
                </label>
                <Select value={formData.referralSource} onValueChange={handleSelectChange}>
                  <SelectTrigger className={errors.referralSource ? "border-red-500 focus:border-red-500" : ""}>
                    <SelectValue placeholder="Sélectionnez une option" />
                  </SelectTrigger>
                  <SelectContent>
                    {referralSources.map((source) => (
                      <SelectItem key={source.value} value={source.value}>
                        {source.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.referralSource && (
                  <p className="text-red-500 text-xs mt-1 flex items-center">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    {errors.referralSource}
                  </p>
                )}
              </div>

              {/* Champ libre si "Autre" est sélectionné */}
              {formData.referralSource === "other" && (
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Précisez *
                  </label>
                  <Input
                    name="referralOther"
                    type="text"
                    placeholder="Décrivez comment vous avez connu NONRU"
                    value={formData.referralOther}
                    onChange={handleChange}
                    className={errors.referralOther ? "border-red-500 focus:border-red-500" : ""}
                  />
                  {errors.referralOther && (
                    <p className="text-red-500 text-xs mt-1 flex items-center">
                      <AlertCircle className="w-3 h-3 mr-1" />
                      {errors.referralOther}
                    </p>
                  )}
                </div>
              )}

              {/* reCAPTCHA */}
              <div>
                <div className="flex items-center space-x-2 mb-2">
                  <Shield className="w-4 h-4 text-muted-foreground" />
                  <label className="text-sm font-medium text-foreground">
                    Vérification de sécurité *
                  </label>
                </div>
                <RecaptchaWrapper 
                  onVerify={handleRecaptchaVerify}
                  onExpired={handleRecaptchaExpired}
                />
                {errors.recaptcha && (
                  <p className="text-red-500 text-xs mt-1 flex items-center">
                    <AlertCircle className="w-3 h-3 mr-1" />
                    {errors.recaptcha}
                  </p>
                )}
              </div>

              {/* Message informatif sur la vérification email */}
              <div className="bg-blue-50 border border-blue-200 rounded-md p-3">
                <p className="text-blue-800 text-sm">
                  📧 Un email de confirmation sera envoyé pour activer votre compte. Vérifiez votre boîte mail après l'inscription.
                </p>
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-[#00B894] hover:bg-[#00B894]/90"
                disabled={loading || !recaptchaToken}
              >
                {loading ? "Création en cours..." : "Créer mon compte sécurisé"}
              </Button>
            </form>
            
            <div className="text-center">
              <span className="text-muted-foreground text-sm">Déjà un compte ? </span>
              <Link 
                to="/signin"
                className="text-[#00B894] hover:text-[#00B894]/80 text-sm font-medium"
              >
                Se connecter
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EnhancedSignUp;


import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LogOut, Shield } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export const LogoutSection = () => {
  const { t } = useLanguage();
  const { signOut, user } = useAuth();

  const handleLogout = async () => {
    try {
      await signOut();
      toast.success(t('logout_success') || 'Déconnexion réussie');
    } catch (error) {
      console.error('Erreur lors de la déconnexion:', error);
      toast.error(t('logout_error') || 'Erreur lors de la déconnexion');
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="w-5 h-5" />
          {t('session_management') || 'Gestion de la session'}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          {t('session_info') || 'Connecté en tant que:'} <strong>{user?.email}</strong>
        </p>
        
        <Button
          variant="destructive"
          onClick={handleLogout}
          className="w-full flex items-center gap-2"
        >
          <LogOut className="w-4 h-4" />
          {t('logout') || 'Se déconnecter'}
        </Button>
        
        <p className="text-xs text-muted-foreground">
          {t('logout_description') || 'Vous serez déconnecté de votre compte et redirigé vers la page d\'accueil.'}
        </p>
      </CardContent>
    </Card>
  );
};

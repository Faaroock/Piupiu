
import { useEffect, useState, useRef } from "react";

interface RecaptchaWrapperProps {
  onVerify: (token: string) => void;
  onExpired?: () => void;
  siteKey?: string;
  action?: string;
}

export const RecaptchaWrapper = ({ 
  onVerify, 
  onExpired,
  siteKey,
  action = "submit"
}: RecaptchaWrapperProps) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const recaptchaRef = useRef<HTMLDivElement>(null);
  const widgetId = useRef<number | null>(null);
  const scriptLoaded = useRef(false);

  // Utiliser une clé de test pour le développement local
  const isDevelopment = window.location.hostname === 'localhost' || window.location.hostname.includes('lovableproject.com');
  const siteKeyToUse = isDevelopment ? "6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI" : "6LdR4mErAAAAAHeI6N98tBbDvRNG182mwlkDxxkv";

  useEffect(() => {
    // Éviter de charger le script plusieurs fois
    if (scriptLoaded.current) {
      if (window.grecaptcha && window.grecaptcha.render) {
        setIsLoaded(true);
      }
      return;
    }

    console.log('Chargement reCAPTCHA avec clé:', isDevelopment ? 'test' : 'production');
    
    // Vérifier si reCAPTCHA est déjà chargé
    if (window.grecaptcha && window.grecaptcha.render) {
      console.log('reCAPTCHA déjà disponible');
      setIsLoaded(true);
      scriptLoaded.current = true;
      return;
    }

    // Charger le script reCAPTCHA v2
    const script = document.createElement('script');
    script.src = 'https://www.google.com/recaptcha/api.js?onload=onRecaptchaLoad&render=explicit';
    script.async = true;
    script.defer = true;
    
    // Fonction globale appelée quand reCAPTCHA est prêt
    (window as any).onRecaptchaLoad = () => {
      console.log('reCAPTCHA chargé avec succès');
      setIsLoaded(true);
      scriptLoaded.current = true;
    };

    script.onerror = () => {
      console.error('Erreur lors du chargement du script reCAPTCHA');
      setError('Erreur de chargement du système de sécurité');
    };
    
    document.head.appendChild(script);

    return () => {
      // Nettoyer le widget si il existe
      if (widgetId.current !== null && window.grecaptcha && window.grecaptcha.reset) {
        try {
          window.grecaptcha.reset(widgetId.current);
        } catch (e) {
          console.log('Erreur lors du nettoyage reCAPTCHA:', e);
        }
      }
    };
  }, []); // Dépendances vides pour éviter les re-exécutions

  // Rendre le widget seulement quand reCAPTCHA est chargé et le ref est disponible
  useEffect(() => {
    if (!isLoaded || !window.grecaptcha || !recaptchaRef.current || widgetId.current !== null) {
      return;
    }

    try {
      console.log('Rendu du widget reCAPTCHA avec clé:', siteKeyToUse);

      widgetId.current = window.grecaptcha.render(recaptchaRef.current, {
        sitekey: siteKeyToUse,
        callback: (token: string) => {
          console.log('reCAPTCHA validé avec succès');
          onVerify(token);
          setError(null);
        },
        'expired-callback': () => {
          console.log('reCAPTCHA expiré');
          setError('La vérification a expiré, veuillez recommencer');
          if (onExpired) {
            onExpired();
          }
        },
        'error-callback': () => {
          console.error('Erreur reCAPTCHA');
          setError('Erreur de vérification, veuillez réessayer');
          if (onExpired) {
            onExpired();
          }
        },
        theme: 'light',
        size: 'normal'
      });

      console.log('Widget reCAPTCHA rendu avec ID:', widgetId.current);
    } catch (error) {
      console.error('Erreur lors du rendu reCAPTCHA:', error);
      setError('Erreur lors de l\'initialisation de la vérification');
    }
  }, [isLoaded, siteKeyToUse, onVerify, onExpired]);

  const resetRecaptcha = () => {
    if (widgetId.current !== null && window.grecaptcha) {
      window.grecaptcha.reset(widgetId.current);
    }
    setError(null);
  };

  if (error) {
    return (
      <div className="recaptcha-error p-4 border border-red-300 rounded-md bg-red-50">
        <p className="text-red-600 text-sm">{error}</p>
        <button
          onClick={resetRecaptcha}
          className="mt-2 text-blue-600 text-sm hover:underline"
        >
          Réessayer
        </button>
      </div>
    );
  }

  return (
    <div className="recaptcha-v2-container">
      {!isLoaded && (
        <div className="flex items-center space-x-2 text-muted-foreground text-sm p-4 border border-gray-200 rounded-md">
          <div className="animate-pulse rounded-full h-3 w-3 bg-gray-400"></div>
          <span>Chargement de la vérification de sécurité...</span>
        </div>
      )}
      
      <div ref={recaptchaRef} className={!isLoaded ? 'hidden' : ''}></div>
      
      <div className="text-xs text-muted-foreground mt-2">
        Ce site est protégé par reCAPTCHA et les{" "}
        <a 
          href="https://policies.google.com/privacy" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-blue-600 hover:underline"
        >
          Règles de confidentialité
        </a>{" "}
        et{" "}
        <a 
          href="https://policies.google.com/terms" 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-blue-600 hover:underline"
        >
          Conditions d'utilisation
        </a>{" "}
        de Google s'appliquent.
      </div>
    </div>
  );
};

// Extend window interface for TypeScript
declare global {
  interface Window {
    grecaptcha: any;
    onRecaptchaLoad: () => void;
    getRecaptchaToken: () => string | null;
  }
}

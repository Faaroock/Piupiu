
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useLanguage } from "@/contexts/LanguageContext";
import { ChevronDown, Globe } from "lucide-react";

interface LanguageSelectorProps {
  compact?: boolean;
}

export const LanguageSelector = ({ compact = false }: LanguageSelectorProps) => {
  const { language, setLanguage, availableLanguages } = useLanguage();
  
  const currentLanguage = availableLanguages.find(lang => lang.code === language);

  if (compact) {
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" className="border-border text-foreground">
            <Globe className="mr-2 h-4 w-4" />
            {currentLanguage?.flag}
            <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="bg-background border-border">
          {availableLanguages.map((lang) => (
            <DropdownMenuItem 
              key={lang.code}
              onClick={() => setLanguage(lang.code)}
              className="text-black hover:bg-accent"
            >
              <span className="mr-3">{lang.flag}</span>
              <div className="text-left">
                <div className="font-medium text-black">{lang.nativeName}</div>
                <div className="text-xs text-black/70">{lang.name}</div>
              </div>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="border-border text-foreground">
          <Globe className="mr-2 h-4 w-4" />
          {currentLanguage?.flag} {currentLanguage?.nativeName}
          <ChevronDown className="ml-2 h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="bg-background border-border">
        {availableLanguages.map((lang) => (
          <DropdownMenuItem 
            key={lang.code}
            onClick={() => setLanguage(lang.code)}
            className="text-black hover:bg-accent"
          >
            <span className="mr-3">{lang.flag}</span>
            <div className="text-left">
              <div className="font-medium text-black">{lang.nativeName}</div>
              <div className="text-xs text-black/70">{lang.name}</div>
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};


import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Upload, X, Image, Camera } from 'lucide-react';

interface ImageUploadProps {
  onImageSelect?: (file: File) => void;
  maxSize?: number; // en MB
  acceptedTypes?: string[];
  className?: string;
  currentImages?: File[];
  onRemoveImage?: (index: number) => void;
}

export const ImageUpload = ({ 
  onImageSelect, 
  maxSize = 5, 
  acceptedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  className = "",
  currentImages = [],
  onRemoveImage
}: ImageUploadProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    console.log('Fichier sélectionné:', file.name, file.size, file.type);
    
    // Vérifier la taille
    if (file.size > maxSize * 1024 * 1024) {
      alert(`Le fichier est trop volumineux. Taille maximale: ${maxSize}MB`);
      return;
    }

    // Vérifier le type
    if (!acceptedTypes.includes(file.type)) {
      alert('Type de fichier non supporté. Utilisez JPG, PNG, GIF ou WebP');
      return;
    }

    // Callback
    console.log('Fichier validé, envoi au parent');
    onImageSelect?.(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    console.log('Fichiers droppés:', files.length);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    console.log('Fichiers sélectionnés via input:', files?.length);
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleClick = () => {
    console.log('Clic sur upload, ouverture du sélecteur');
    fileInputRef.current?.click();
  };

  return (
    <div className={className}>
      <input
        ref={fileInputRef}
        type="file"
        accept={acceptedTypes.join(',')}
        onChange={handleFileChange}
        className="hidden"
      />
      
      {/* Affichage des images actuelles */}
      {currentImages.length > 0 && (
        <div className="grid grid-cols-2 gap-3 mb-4">
          {currentImages.map((image, index) => (
            <div key={index} className="relative group">
              <img 
                src={URL.createObjectURL(image)} 
                alt={`Photo ${index + 1}`}
                className="w-full h-32 object-cover rounded-lg border-2 border-gray-200"
              />
              <Button
                type="button"
                variant="destructive"
                size="sm"
                className="absolute top-2 right-2 opacity-80 group-hover:opacity-100 transition-opacity w-6 h-6 p-0"
                onClick={() => {
                  console.log(`Suppression image ${index}`);
                  onRemoveImage?.(index);
                }}
              >
                <X className="w-3 h-3" />
              </Button>
              <div className="absolute bottom-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded">
                Photo {index + 1}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Zone d'upload */}
      {currentImages.length < 4 && (
        <Card 
          className={`border-2 border-dashed cursor-pointer transition-colors ${
            isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-blue-400'
          }`}
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
          onDragEnter={() => setIsDragging(true)}
          onDragLeave={() => setIsDragging(false)}
          onClick={handleClick}
        >
          <CardContent className="p-6 text-center">
            <div className="flex flex-col items-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center">
                <Camera className="w-8 h-8 text-blue-500" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-700">
                  Cliquez ou glissez une image ici
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  JPG, PNG, GIF, WebP (max {maxSize}MB)
                </p>
                <p className="text-xs text-blue-600 mt-1">
                  {currentImages.length}/4 photos ajoutées
                </p>
              </div>
              <Button variant="outline" size="sm" type="button">
                <Upload className="w-4 h-4 mr-2" />
                Choisir un fichier
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

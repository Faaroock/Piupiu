
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Send, Snowflake } from 'lucide-react';
import { MoneyTransferPage } from './MoneyTransferPage';
import { FreezeFundsPage } from './FreezeFundsPage';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface WalletPageProps {
  onNavigate: (page: string) => void;
}

export const WalletPage = ({ onNavigate }: WalletPageProps) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'transfer' | 'freeze'>('overview');

  if (activeTab === 'transfer') {
    return <MoneyTransferPage onNavigate={(page) => {
      if (page === 'home') {
        setActiveTab('overview');
      } else {
        onNavigate(page);
      }
    }} />;
  }

  if (activeTab === 'freeze') {
    return <FreezeFundsPage onNavigate={(page) => {
      if (page === 'home') {
        setActiveTab('overview');
      } else {
        onNavigate(page);
      }
    }} />;
  }

  return (
    <div className="min-h-screen bg-background p-4 pb-20">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('home')}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour
          </Button>
          <h1 className="text-2xl font-bold text-foreground">
            Mon Portefeuille
          </h1>
        </div>

        {/* Actions rapides */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('transfer')}>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Send className="w-5 h-5 text-blue-500" />
                <span>Transférer de l'argent</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Envoyez de l'argent à d'autres utilisateurs NONRU
              </p>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('freeze')}>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Snowflake className="w-5 h-5 text-blue-500" />
                <span>Geler des fonds</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Mettez de côté des fonds pour éviter de les dépenser
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Informations du portefeuille */}
        <Card>
          <CardHeader>
            <CardTitle>Aperçu du portefeuille</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-4 bg-green-50 rounded-lg">
                <span className="font-medium">Solde disponible</span>
                <span className="text-2xl font-bold text-green-600">50,000 F</span>
              </div>
              
              <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
                <span className="font-medium">Fonds gelés</span>
                <span className="text-xl font-semibold text-blue-600">15,000 F</span>
              </div>
              
              <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                <span className="font-medium">Solde total</span>
                <span className="text-xl font-semibold">65,000 F</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};


import { FreezeFundsForm } from './FreezeFundsForm';
import { FrozenFundsList } from './FrozenFundsList';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

interface FreezeFundsPageProps {
  onNavigate: (page: string) => void;
}

export const FreezeFundsPage = ({ onNavigate }: FreezeFundsPageProps) => {
  return (
    <div className="min-h-screen bg-slate-900 p-4">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('home')}
            className="text-slate-400 hover:text-white"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour
          </Button>
          <h1 className="text-2xl font-bold text-white">
            Gestion des fonds gelés
          </h1>
        </div>

        {/* Description */}
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-4">
          <p className="text-slate-300 text-sm">
            Gelez une partie de vos fonds pour les sécuriser et éviter de les dépenser accidentellement. 
            Les fonds gelés ne seront pas disponibles pour les transactions jusqu'à ce que vous les dégeliez.
          </p>
        </div>

        {/* Freeze Form */}
        <FreezeFundsForm />

        {/* Frozen Funds List */}
        <FrozenFundsList />
      </div>
    </div>
  );
};

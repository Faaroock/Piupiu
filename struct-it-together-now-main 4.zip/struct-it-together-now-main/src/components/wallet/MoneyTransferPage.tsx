
import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { ArrowLeft, Send, Calculator } from 'lucide-react';
import { useMoneyTransfer } from '@/hooks/useMoneyTransfer';

interface MoneyTransferPageProps {
  onNavigate: (page: string) => void;
}

export const MoneyTransferPage = ({ onNavigate }: MoneyTransferPageProps) => {
  const [email, setEmail] = useState('');
  const [amount, setAmount] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { sendMoney, calculateTransferFees, availableBalance } = useMoneyTransfer();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const amountNum = parseFloat(amount);
    if (!amountNum || amountNum <= 0) {
      return;
    }

    if (!email.trim()) {
      return;
    }

    setIsSubmitting(true);
    const success = await sendMoney(email.trim(), amountNum, message.trim());
    
    if (success) {
      setEmail('');
      setAmount('');
      setMessage('');
    }
    
    setIsSubmitting(false);
  };

  const fees = amount ? calculateTransferFees(parseFloat(amount)) : 0;
  const total = amount ? parseFloat(amount) + fees : 0;

  return (
    <div className="min-h-screen bg-background p-4 pb-20">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onNavigate('home')}
            className="text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour
          </Button>
          <h1 className="text-2xl font-bold text-foreground">
            Transfert d'argent
          </h1>
        </div>

        {/* Solde disponible */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <span>Solde disponible</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">
              {availableBalance.toLocaleString()} F
            </div>
          </CardContent>
        </Card>

        {/* Formulaire de transfert */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Send className="w-5 h-5" />
              <span>Envoyer de l'argent</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="email">Email du destinataire *</Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="destinataire@example.com"
                  required
                  className="bg-background border-border"
                />
              </div>

              <div>
                <Label htmlFor="amount">Montant à envoyer *</Label>
                <Input
                  id="amount"
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="Ex: 10000"
                  min="1"
                  max={availableBalance}
                  required
                  className="bg-background border-border"
                />
              </div>

              <div>
                <Label htmlFor="message">Message (optionnel)</Label>
                <Textarea
                  id="message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Ex: Remboursement, cadeau..."
                  rows={3}
                  className="bg-background border-border"
                />
              </div>

              {/* Calcul des frais */}
              {amount && (
                <Card className="bg-muted/50">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-2 mb-3">
                      <Calculator className="w-4 h-4" />
                      <span className="font-medium">Détail du transfert</span>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Montant:</span>
                        <span>{parseFloat(amount).toLocaleString()} F</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Frais de transfert:</span>
                        <span>{fees.toLocaleString()} F</span>
                      </div>
                      <div className="flex justify-between font-semibold border-t pt-2">
                        <span>Total à débiter:</span>
                        <span>{total.toLocaleString()} F</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <Button
                type="submit"
                disabled={isSubmitting || !amount || !email.trim() || total > availableBalance}
                className="w-full"
              >
                {isSubmitting ? 'Envoi en cours...' : `Envoyer ${amount ? parseFloat(amount).toLocaleString() : '0'} F`}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};


import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Snowflake } from 'lucide-react';
import { useFrozenFunds } from '@/hooks/useFrozenFunds';

export const FreezeFundsForm = () => {
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { freezeFunds, availableBalance } = useFrozenFunds();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const amountNum = parseFloat(amount);
    if (!amountNum || amountNum <= 0) {
      return;
    }

    if (!reason.trim()) {
      return;
    }

    setIsSubmitting(true);
    const success = await freezeFunds(amountNum, reason.trim());
    
    if (success) {
      setAmount('');
      setReason('');
    }
    
    setIsSubmitting(false);
  };

  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-white">
          <Snowflake className="w-5 h-5 text-blue-400" />
          <span>Geler des fonds</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="available-balance" className="text-slate-300">
              Solde disponible
            </Label>
            <div className="text-2xl font-bold text-green-400">
              {availableBalance.toLocaleString()} F
            </div>
          </div>

          <div>
            <Label htmlFor="amount" className="text-slate-300">
              Montant à geler *
            </Label>
            <Input
              id="amount"
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Ex: 50000"
              min="1"
              max={availableBalance}
              required
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div>
            <Label htmlFor="reason" className="text-slate-300">
              Raison du gel *
            </Label>
            <Textarea
              id="reason"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Ex: Épargne pour achat de terrain, Fonds d'urgence..."
              required
              rows={3}
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <Button
            type="submit"
            disabled={isSubmitting || !amount || !reason.trim() || parseFloat(amount) > availableBalance}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            {isSubmitting ? 'Gel en cours...' : 'Geler les fonds'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};


import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Users, TrendingUp, Wallet, Bell } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useNotifications } from "@/hooks/useNotifications";
import { NotificationBell } from "@/components/notifications/NotificationBell";
import { NotificationCenter } from "@/components/notifications/NotificationCenter";
import { EmailVerificationBanner } from "@/components/auth/EmailVerificationBanner";

interface DashboardHomeProps {
  onNavigate: (page: string) => void;
}

export const DashboardHome = ({ onNavigate }: DashboardHomeProps) => {
  const { user } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);

  const stats = [
    {
      title: "Mes Tontines",
      value: "3",
      icon: Users,
      description: "Tontines actives",
    },
    {
      title: "Épargne Totale",
      value: "125 000 FCFA",
      icon: TrendingUp,
      description: "Montant épargné",
    },
    {
      title: "Portefeuille",
      value: "45 000 FCFA",
      icon: Wallet,
      description: "Solde disponible",
    },
  ];

  return (
    <div className="min-h-screen bg-background p-4">
      {/* Email Verification Banner */}
      <div className="mb-4">
        <EmailVerificationBanner />
      </div>

      {/* Header avec notifications */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">
            Bonjour {user?.user_metadata?.first_name || user?.email?.split('@')[0] || 'Utilisateur'} 👋
          </h1>
          <p className="text-muted-foreground">
            Gérez vos tontines et votre épargne facilement
          </p>
        </div>
        <NotificationBell onClick={() => setShowNotifications(true)} />
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {stats.map((stat, index) => {
          const IconComponent = stat.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <IconComponent className="h-5 w-5 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-foreground">{stat.value}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  {stat.description}
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <Card className="hover:shadow-lg transition-shadow cursor-pointer" 
              onClick={() => onNavigate('create')}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Créer une Tontine
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Lancez une nouvelle tontine avec vos proches
            </p>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer" 
              onClick={() => onNavigate('tontines')}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Mes Tontines
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Voir et gérer toutes vos tontines
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions Buttons */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Button 
          variant="outline" 
          className="h-20 flex-col gap-2"
          onClick={() => onNavigate('freeze')}
        >
          <Wallet className="h-6 w-6" />
          <span className="text-sm">Geler Fonds</span>
        </Button>
        
        <Button 
          variant="outline" 
          className="h-20 flex-col gap-2"
          onClick={() => onNavigate('progress')}
        >
          <TrendingUp className="h-6 w-6" />
          <span className="text-sm">Progression</span>
        </Button>
        
        <Button 
          variant="outline" 
          className="h-20 flex-col gap-2"
          onClick={() => onNavigate('messages')}
        >
          <Bell className="h-6 w-6" />
          <span className="text-sm">Messages</span>
        </Button>
        
        <Button 
          variant="outline" 
          className="h-20 flex-col gap-2"
          onClick={() => onNavigate('settings')}
        >
          <Users className="h-6 w-6" />
          <span className="text-sm">Paramètres</span>
        </Button>
      </div>

      {/* Notification Center */}
      <NotificationCenter 
        isOpen={showNotifications} 
        onClose={() => setShowNotifications(false)} 
      />
    </div>
  );
};


export type NavigationPage = "home" | "tontines" | "create" | "progress" | "settings" | "messages";

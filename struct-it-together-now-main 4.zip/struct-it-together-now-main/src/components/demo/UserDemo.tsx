
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ChevronRight, CheckCircle, Play, X } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";

interface DemoStep {
  id: number;
  title: string;
  description: string;
  action: string;
  completed: boolean;
}

interface UserDemoProps {
  onComplete: () => void;
  onSkip: () => void;
}

export const UserDemo = ({ onComplete, onSkip }: UserDemoProps) => {
  const { user } = useAuth();
  const { t } = useLanguage();
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const demoSteps: DemoStep[] = [
    {
      id: 1,
      title: t('demo_step_1_title') || 'Bienvenue sur NONRU',
      description: t('demo_step_1_desc') || 'Découvrez comment créer et gérer vos tontines facilement',
      action: t('demo_step_1_action') || 'Commencer',
      completed: false
    },
    {
      id: 2,
      title: t('demo_step_2_title') || 'Explorer les tontines',
      description: t('demo_step_2_desc') || 'Parcourez les tontines disponibles et rejoignez-en une',
      action: t('demo_step_2_action') || 'Voir les tontines',
      completed: false
    },
    {
      id: 3,
      title: t('demo_step_3_title') || 'Gérer votre portefeuille',
      description: t('demo_step_3_desc') || 'Ajoutez des fonds et suivez vos transactions',
      action: t('demo_step_3_action') || 'Ouvrir le portefeuille',
      completed: false
    },
    {
      id: 4,
      title: t('demo_step_4_title') || 'Système de parrainage',
      description: t('demo_step_4_desc') || 'Invitez vos amis et gagnez des récompenses',
      action: t('demo_step_4_action') || 'Voir le parrainage',
      completed: false
    }
  ];

  const [steps, setSteps] = useState(demoSteps);

  const markStepCompleted = async (stepId: number) => {
    if (!user) return;

    try {
      await supabase
        .from('user_demo_progress')
        .insert({
          user_id: user.id,
          step_number: stepId
        });

      setCompletedSteps(prev => [...prev, stepId]);
      setSteps(prev => prev.map(step => 
        step.id === stepId ? { ...step, completed: true } : step
      ));

      if (stepId === demoSteps.length) {
        await markDemoAsCompleted();
        onComplete();
      } else {
        setCurrentStep(stepId);
      }
    } catch (error) {
      console.error('Erreur marquage étape:', error);
    }
  };

  const markDemoAsCompleted = async () => {
    if (!user) return;

    try {
      await supabase
        .from('profiles')
        .update({ has_seen_demo: true })
        .eq('user_id', user.id);
    } catch (error) {
      console.error('Erreur marquage démo complétée:', error);
    }
  };

  const handleSkip = async () => {
    await markDemoAsCompleted();
    onSkip();
  };

  const progress = (completedSteps.length / demoSteps.length) * 100;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="max-w-md w-full">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Play className="w-5 h-5 text-primary" />
              {t('demo_title') || 'Guide de démarrage'}
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={handleSkip}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <Progress value={progress} className="w-full" />
          <p className="text-sm text-gray-600">
            {completedSteps.length} / {demoSteps.length} {t('steps_completed') || 'étapes complétées'}
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          {steps.map((step, index) => (
            <div key={step.id} className={`p-4 border rounded-lg ${
              index === currentStep ? 'border-primary bg-primary/5' : 
              step.completed ? 'border-green-500 bg-green-50' : 'border-gray-200'
            }`}>
              <div className="flex items-center gap-3">
                {step.completed ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <div className={`w-5 h-5 rounded-full border-2 ${
                    index === currentStep ? 'border-primary' : 'border-gray-300'
                  }`} />
                )}
                <div className="flex-1">
                  <h3 className="font-medium">{step.title}</h3>
                  <p className="text-sm text-gray-600">{step.description}</p>
                </div>
              </div>
              {index === currentStep && !step.completed && (
                <div className="mt-3 flex justify-end">
                  <Button size="sm" onClick={() => markStepCompleted(step.id)}>
                    {step.action}
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
              )}
            </div>
          ))}
          
          <div className="flex gap-2 pt-4">
            <Button variant="outline" onClick={handleSkip} className="flex-1">
              {t('skip_demo') || 'Passer'}
            </Button>
            {currentStep === demoSteps.length - 1 && (
              <Button onClick={onComplete} className="flex-1">
                {t('finish_demo') || 'Terminer'}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

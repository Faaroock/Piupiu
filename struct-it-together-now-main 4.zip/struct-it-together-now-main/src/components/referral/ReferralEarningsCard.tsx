
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Coins, Calendar, CheckCircle, Clock } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

interface ReferralEarning {
  id: string;
  earning_amount: number;
  total_contributed: number;
  is_paid: boolean;
  created_at: string;
  epargne_name?: string;
  referee_name?: string;
}

interface ReferralEarningsCardProps {
  earnings: ReferralEarning[];
  totalEarnings: number;
}

export const ReferralEarningsCard = ({ earnings, totalEarnings }: ReferralEarningsCardProps) => {
  const { t } = useLanguage();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Coins className="w-5 h-5" />
          {t('referral_earnings') || 'Gains de parrainage'}
        </CardTitle>
        <div className="bg-green-50 p-3 rounded-lg">
          <p className="text-2xl font-bold text-green-600">{totalEarnings.toLocaleString()} F</p>
          <p className="text-sm text-gray-600">{t('total_earnings') || 'Total des gains'}</p>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {earnings.length === 0 ? (
          <p className="text-gray-500 text-center py-4">
            {t('no_earnings_yet') || 'Aucun gain de parrainage pour le moment'}
          </p>
        ) : (
          earnings.map((earning) => (
            <div key={earning.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <p className="font-medium text-green-600">+{earning.earning_amount.toLocaleString()} F</p>
                  <Badge variant={earning.is_paid ? "default" : "secondary"}>
                    {earning.is_paid ? (
                      <><CheckCircle className="w-3 h-3 mr-1" /> {t('paid') || 'Payé'}</>
                    ) : (
                      <><Clock className="w-3 h-3 mr-1" /> {t('pending') || 'En attente'}</>
                    )}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">
                  {t('from_contribution') || 'Sur contribution de'} {earning.total_contributed.toLocaleString()} F
                </p>
                <div className="flex items-center gap-1 text-xs text-gray-500 mt-1">
                  <Calendar className="w-3 h-3" />
                  {new Date(earning.created_at).toLocaleDateString()}
                </div>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
};

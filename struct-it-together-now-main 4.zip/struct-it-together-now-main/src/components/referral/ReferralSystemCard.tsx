
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Users, Gift, Share, Copy, QrCode, Lock } from "lucide-react";
import { useReferralSystem } from "@/hooks/useReferralSystem";
import { useToast } from "@/hooks/use-toast";

export const ReferralSystemCard = () => {
  const { referralData, loading, generateReferralCode } = useReferralSystem();
  const { toast } = useToast();

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-8 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const copyReferralLink = async () => {
    if (!referralData?.referralCode) return;
    
    const referralLink = `${window.location.origin}/signup?ref=${referralData.referralCode}`;
    try {
      await navigator.clipboard.writeText(referralLink);
      toast({
        title: "Lien copié !",
        description: "Le lien de parrainage a été copié dans le presse-papier"
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de copier le lien",
        variant: "destructive"
      });
    }
  };

  const shareReferralLink = async () => {
    if (!referralData?.referralCode) return;
    
    const referralLink = `${window.location.origin}/signup?ref=${referralData.referralCode}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Rejoignez NONRU !',
          text: 'Découvrez NONRU, la plateforme de tontines numériques. Utilisez mon code de parrainage :',
          url: referralLink
        });
      } catch (error) {
        copyReferralLink();
      }
    } else {
      copyReferralLink();
    }
  };

  if (!referralData?.isUnlocked) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5" />
            Système de parrainage
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <div className="bg-yellow-50 p-6 rounded-lg">
            <Lock className="w-12 h-12 text-yellow-600 mx-auto mb-4" />
            <h3 className="font-semibold text-yellow-800 mb-2">
              Parrainage non déverrouillé
            </h3>
            <p className="text-yellow-700 text-sm">
              Complétez au moins une tontine pour déverrouiller le système de parrainage et commencer à inviter vos amis !
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          Système de parrainage
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Statistiques */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-blue-50 p-3 rounded-lg text-center">
            <Users className="w-5 h-5 text-blue-600 mx-auto mb-1" />
            <p className="text-lg font-bold text-blue-700">
              {referralData.totalReferrals}
            </p>
            <p className="text-xs text-blue-600">Parrainages</p>
          </div>
          
          <div className="bg-green-50 p-3 rounded-lg text-center">
            <Gift className="w-5 h-5 text-green-600 mx-auto mb-1" />
            <p className="text-lg font-bold text-green-700">
              {referralData.totalEarnings.toLocaleString()} F
            </p>
            <p className="text-xs text-green-600">Gains totaux</p>
          </div>
        </div>

        {/* Code de parrainage */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-sm font-medium">Votre code de parrainage</label>
            <Button size="sm" variant="outline" onClick={generateReferralCode}>
              Nouveau code
            </Button>
          </div>
          
          <div className="flex gap-2">
            <Input
              value={referralData.referralCode}
              readOnly
              className="font-mono text-center text-lg"
            />
            <Button size="sm" onClick={copyReferralLink}>
              <Copy className="w-4 h-4" />
            </Button>
          </div>

          <div className="flex gap-2">
            <Button onClick={shareReferralLink} className="flex-1">
              <Share className="w-4 h-4 mr-2" />
              Partager le lien
            </Button>
          </div>
        </div>

        {/* QR Code */}
        {referralData.qrCodeUrl && (
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <QrCode className="w-4 h-4" />
              <span className="text-sm font-medium">Code QR de parrainage</span>
            </div>
            <div className="flex justify-center">
              <img 
                src={referralData.qrCodeUrl}
                alt="QR Code de parrainage"
                className="w-32 h-32 border rounded-lg"
              />
            </div>
            <p className="text-xs text-muted-foreground">
              Partagez ce code QR pour inviter vos amis
            </p>
          </div>
        )}

        {/* Informations sur le parrainage */}
        <div className="bg-muted/50 p-4 rounded-lg">
          <h4 className="font-semibold mb-2 text-sm">Comment ça marche ?</h4>
          <ul className="text-xs space-y-1 text-muted-foreground">
            <li>• Partagez votre code avec vos amis</li>
            <li>• Ils s'inscrivent avec votre code</li>
            <li>• Vous gagnez 1% de leurs contributions</li>
            <li>• Les gains sont crédités automatiquement</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};


import { MtnAuthService } from '../services/mtn/mtnAuth';
import { MtnPaymentService } from '../services/mtn/mtnPayment';

describe('MTN MoMo Collection Tests', () => {
  const testCountries = ['bj', 'ci', 'bf'];
  let apiKeys: Record<string, string> = {};

  beforeAll(async () => {
    console.log('🧪 Début des tests MTN MoMo Collection Sandbox');
    
    // Générer les API Keys pour tous les pays de test
    for (const country of testCountries) {
      try {
        console.log(`Génération API Key pour ${country.toUpperCase()}...`);
        const apiKey = await MtnAuthService.generateApiKey(country);
        apiKeys[country] = apiKey;
        console.log(`✅ API Key générée pour ${country}: ${apiKey.substring(0, 10)}...`);
      } catch (error) {
        console.error(`❌ Erreur génération API Key ${country}:`, error);
      }
    }
  });

  describe('Test d\'authentification', () => {
    test.each(testCountries)('Récupération token d\'accès pour %s', async (country) => {
      const apiKey = apiKeys[country];
      expect(apiKey).toBeDefined();

      const token = await MtnAuthService.getAccessToken(country, apiKey);
      expect(token).toBeDefined();
      expect(typeof token).toBe('string');
      console.log(`✅ Token récupéré pour ${country}: ${token.substring(0, 20)}...`);
    });
  });

  describe('Test de paiement', () => {
    test.each(testCountries)('Demande de paiement pour %s', async (country) => {
      const apiKey = apiKeys[country];
      expect(apiKey).toBeDefined();

      const paymentRequest = {
        amount: '100',
        currency: 'XOF',
        externalId: `test_${country}_${Date.now()}`,
        payer: {
          partyIdType: 'MSISDN',
          partyId: '22966666666' // Numéro de test sandbox
        },
        payerMessage: `Test NONRU ${country.toUpperCase()}`,
        payeeNote: `Paiement test sandbox pour ${country}`
      };

      const response = await MtnPaymentService.requestToPay(country, apiKey, paymentRequest);
      
      expect(response.referenceId).toBeDefined();
      expect(response.status).toBe('PENDING');
      console.log(`✅ Paiement initié pour ${country}, ref: ${response.referenceId}`);

      // Attendre un peu puis vérifier le statut
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      const status = await MtnPaymentService.getPaymentStatus(country, apiKey, response.referenceId);
      expect(status).toBeDefined();
      expect(['PENDING', 'SUCCESSFUL', 'FAILED']).toContain(status.status);
      console.log(`✅ Statut paiement ${country}: ${status.status}`);
    });
  });

  describe('Test multi-pays', () => {
    test('Gestion simultanée de plusieurs pays', async () => {
      const payments = testCountries.map(async (country) => {
        const apiKey = apiKeys[country];
        const paymentRequest = {
          amount: '50',
          currency: 'XOF',
          externalId: `multi_test_${country}_${Date.now()}`,
          payer: {
            partyIdType: 'MSISDN',
            partyId: '22966666666'
          },
          payerMessage: `Multi-test ${country}`,
          payeeNote: `Test concurrent ${country}`
        };

        return MtnPaymentService.requestToPay(country, apiKey, paymentRequest);
      });

      const results = await Promise.allSettled(payments);
      
      results.forEach((result, index) => {
        if (result.status === 'fulfilled') {
          console.log(`✅ Paiement multi-pays ${testCountries[index]} réussi`);
        } else {
          console.log(`❌ Paiement multi-pays ${testCountries[index]} échoué:`, result.reason);
        }
      });

      // Au moins un paiement doit réussir
      const successCount = results.filter(r => r.status === 'fulfilled').length;
      expect(successCount).toBeGreaterThan(0);
    });
  });

  afterAll(() => {
    console.log('🏁 Tests MTN MoMo terminés');
  });
});



import { MoovPaymentService } from '../services/moov/moovPayment';
import { getMoovConfig } from '../services/paymentManager';

describe('Moov Money Transfer Tests', () => {
  beforeAll(() => {
    console.log('🧪 Début des tests Moov Money Sandbox');
    const config = getMoovConfig();
    console.log(`Configuration Moov:`, {
      publicKey: `${config.publicKey.substring(0, 10)}...`,
      sandbox: config.sandbox,
      domains: config.allowedDomains.length
    });
  });

  describe('Test de transfert', () => {
    test('Transfert entre comptes sandbox', async () => {
      const transferRequest = {
        amount: 1000,
        currency: 'XOF',
        description: 'Test transfert NONRU sandbox',
        reference: `moov_test_${Date.now()}`,
        recipient: {
          phone: '22977777777',
          name: 'Test Recipient NONRU'
        },
        sender: {
          phone: '22966666666',
          name: 'Test Sender NONRU'
        }
      };

      const response = await MoovPaymentService.initializeTransfer(transferRequest);
      
      expect(response.transactionId).toBeDefined();
      expect(response.status).toBeDefined();
      expect(response.reference).toBe(transferRequest.reference);
      
      console.log(`✅ Transfert Moov initié:`, {
        transactionId: response.transactionId,
        status: response.status,
        reference: response.reference
      });

      // Vérifier le statut du transfert
      const status = await MoovPaymentService.getTransferStatus(response.transactionId);
      expect(status).toBeDefined();
      console.log(`✅ Statut transfert récupéré:`, status);
    });

    test('Transfert avec montant minimum', async () => {
      const transferRequest = {
        amount: 100, // Montant minimum
        currency: 'XOF',
        description: 'Test montant minimum',
        reference: `moov_min_${Date.now()}`,
        recipient: {
          phone: '22988888888',
          name: 'Test Min Recipient'
        },
        sender: {
          phone: '22966666666',
          name: 'Test Min Sender'
        }
      };

      const response = await MoovPaymentService.initializeTransfer(transferRequest);
      expect(response.transactionId).toBeDefined();
      console.log(`✅ Transfert montant minimum réussi: ${response.transactionId}`);
    });

    test('Transfert avec montant élevé', async () => {
      const transferRequest = {
        amount: 50000, // Montant plus élevé
        currency: 'XOF',
        description: 'Test montant élevé',
        reference: `moov_high_${Date.now()}`,
        recipient: {
          phone: '22999999999',
          name: 'Test High Recipient'
        },
        sender: {
          phone: '22966666666',
          name: 'Test High Sender'
        }
      };

      const response = await MoovPaymentService.initializeTransfer(transferRequest);
      expect(response.transactionId).toBeDefined();
      console.log(`✅ Transfert montant élevé réussi: ${response.transactionId}`);
    });
  });

  describe('Test de balance', () => {
    test('Récupération de la balance du compte', async () => {
      const balance = await MoovPaymentService.getAccountBalance();
      expect(balance).toBeDefined();
      console.log(`✅ Balance Moov récupérée:`, balance);
    });
  });

  describe('Test de gestion d\'erreurs', () => {
    test('Transfert avec numéro invalide', async () => {
      const transferRequest = {
        amount: 1000,
        currency: 'XOF',
        description: 'Test numéro invalide',
        reference: `moov_invalid_${Date.now()}`,
        recipient: {
          phone: '123', // Numéro invalide
          name: 'Test Invalid'
        },
        sender: {
          phone: '22966666666',
          name: 'Test Sender'
        }
      };

      await expect(MoovPaymentService.initializeTransfer(transferRequest))
        .rejects
        .toThrow();
      
      console.log(`✅ Gestion d'erreur numéro invalide fonctionne`);
    });

    test('Transfert avec montant négatif', async () => {
      const transferRequest = {
        amount: -100, // Montant négatif
        currency: 'XOF',
        description: 'Test montant négatif',
        reference: `moov_negative_${Date.now()}`,
        recipient: {
          phone: '22977777777',
          name: 'Test Negative'
        },
        sender: {
          phone: '22966666666',
          name: 'Test Sender'
        }
      };

      await expect(MoovPaymentService.initializeTransfer(transferRequest))
        .rejects
        .toThrow();
      
      console.log(`✅ Gestion d'erreur montant négatif fonctionne`);
    });
  });

  afterAll(() => {
    console.log('🏁 Tests Moov Money terminés');
  });
});



export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  user_metadata?: {
    first_name?: string;
    last_name?: string;
    age?: number;
    referral_source?: string;
    referral_other?: string;
    is_new_user?: boolean;
  };
}

export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, name: string, metadata?: any) => Promise<void>;
  logout: () => void;
  loading: boolean;
}

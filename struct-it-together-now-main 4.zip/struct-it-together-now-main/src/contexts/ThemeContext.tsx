
import { createContext, useContext, useEffect, useState, ReactNode } from "react";

type Theme = "light" | "dark" | "system";

interface CustomTheme {
  name: string;
  colors: {
    primary: string;
    secondary: string;
    background: string;
    foreground: string;
    accent: string;
  };
  cssVars: {
    [key: string]: string;
  };
}

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  actualTheme: "light" | "dark";
  customTheme: CustomTheme | null;
  setCustomTheme: (customTheme: CustomTheme | null) => void;
  applyCustomTheme: (customTheme: CustomTheme) => void;
  clearCustomTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
};

interface ThemeProviderProps {
  children: ReactNode;
}

export const ThemeProvider = ({ children }: ThemeProviderProps) => {
  const [theme, setTheme] = useState<Theme>("system");
  const [actualTheme, setActualTheme] = useState<"light" | "dark">("light");
  const [customTheme, setCustomTheme] = useState<CustomTheme | null>(null);

  useEffect(() => {
    // Charger le thème depuis localStorage
    const savedTheme = localStorage.getItem("theme") as Theme;
    if (savedTheme) {
      setTheme(savedTheme);
    }

    // Charger le thème personnalisé depuis localStorage
    const savedCustomTheme = localStorage.getItem("customTheme");
    if (savedCustomTheme) {
      try {
        const parsedCustomTheme = JSON.parse(savedCustomTheme);
        setCustomTheme(parsedCustomTheme);
      } catch (error) {
        console.error("Erreur lors du chargement du thème personnalisé:", error);
      }
    }
  }, []);

  const applyCustomTheme = (newCustomTheme: CustomTheme) => {
    const root = document.documentElement;
    
    // Appliquer toutes les variables CSS personnalisées avec vérification
    Object.entries(newCustomTheme.cssVars).forEach(([property, value]) => {
      root.style.setProperty(property, value);
    });
    
    setCustomTheme(newCustomTheme);
    
    // Sauvegarder dans localStorage
    localStorage.setItem("customTheme", JSON.stringify(newCustomTheme));
    
    console.log(`Thème personnalisé ${newCustomTheme.name} appliqué avec succès`);
  };

  const clearCustomTheme = () => {
    const root = document.documentElement;
    
    // Supprimer les variables CSS personnalisées et revenir aux valeurs par défaut
    if (customTheme) {
      Object.keys(customTheme.cssVars).forEach((property) => {
        root.style.removeProperty(property);
      });
    }
    
    setCustomTheme(null);
    localStorage.removeItem("customTheme");
    
    console.log("Thème personnalisé supprimé, retour au thème par défaut");
  };

  useEffect(() => {
    const root = window.document.documentElement;
    
    const updateActualTheme = () => {
      let newActualTheme: "light" | "dark" = "light";
      
      if (theme === "system") {
        newActualTheme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
      } else {
        newActualTheme = theme;
      }
      
      setActualTheme(newActualTheme);
      
      // Appliquer le thème au DOM
      root.classList.remove("light", "dark");
      root.classList.add(newActualTheme);
      
      // Sauvegarder dans localStorage
      localStorage.setItem("theme", theme);

      // Réappliquer le thème personnalisé s'il existe après un délai pour s'assurer que les styles de base sont appliqués
      if (customTheme) {
        setTimeout(() => {
          Object.entries(customTheme.cssVars).forEach(([property, value]) => {
            root.style.setProperty(property, value);
          });
        }, 10);
      }
    };

    updateActualTheme();

    // Écouter les changements de préférences système
    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
    const handleChange = () => {
      if (theme === "system") {
        updateActualTheme();
      }
    };

    mediaQuery.addEventListener("change", handleChange);
    return () => mediaQuery.removeEventListener("change", handleChange);
  }, [theme, customTheme]);

  return (
    <ThemeContext.Provider value={{ 
      theme, 
      setTheme, 
      actualTheme, 
      customTheme, 
      setCustomTheme, 
      applyCustomTheme, 
      clearCustomTheme 
    }}>
      {children}
    </ThemeContext.Provider>
  );
};

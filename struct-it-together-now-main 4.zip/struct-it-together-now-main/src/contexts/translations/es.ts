
export const esTranslations = {
  // Navigation
  'home': 'Inicio',
  'tontines': 'Tontinas',
  'progress': 'Progreso',
  'messages': 'Mensajes',
  'settings': 'Configuración',
  'back': 'Atrás',
  
  // Authentication
  'sign_in': 'Iniciar Sesión',
  'sign_up': 'Registrarse',
  'create_account': 'Crear Cuenta',
  'email': 'Correo Electrónico',
  'password': 'Contraseña',
  'confirm_password': 'Confirmar Contraseña',
  'first_name': 'Nombre',
  'last_name': 'Apellido',
  'age': 'Edad',
  'logout': 'Cerrar Sesión',
  'logout_success': 'Sesión cerrada exitosamente',
  'logout_error': 'Error al cerrar sesión',
  'session_management': 'Gestión de Sesión',
  'session_info': 'Conectado como:',
  'logout_description': 'Se cerrará su sesión y será redirigido a la página de inicio.',
  
  // Forms
  'required_field': 'Este campo es obligatorio',
  'invalid_email': 'Dirección de correo electrónico inválida',
  'password_too_short': 'La contraseña debe tener al menos 8 caracteres',
  'passwords_not_match': 'Las contraseñas no coinciden',
  'age_minimum': 'No cumple con la edad mínima requerida para registrarse en Nonru',
  'age_required': 'La edad es requerida y debe ser un número válido',
  'invalid_age': 'La edad debe ser un número válido',
  
  // ReCAPTCHA
  'recaptcha_required': 'Por favor confirme que no es un robot',
  'recaptcha_failed': 'Verificación de seguridad fallida. Por favor marque la casilla para confirmar que no es un robot.',
  
  // Signup
  'account_created_success': '¡Cuenta creada exitosamente! Revise su correo electrónico.',
  'creating_account': 'Creando cuenta...',
  'already_have_account': '¿Ya tiene una cuenta?',
  'email_confirmation_required': 'Se enviará un correo de confirmación a su dirección',
  'return_home': 'Volver al Inicio',
  'email_already_used': 'Esta dirección de correo electrónico ya está en uso.',
  'password_security_error': 'La contraseña no cumple con los requisitos de seguridad.',
  'technical_error': 'Se produjo un error técnico.',
  'form_validation_error': 'Por favor corrija los errores del formulario',
  
  // Referral
  'referral_source': '¿Cómo conoció Nonru?',
  'referral_friend': 'A través de un amigo',
  'referral_social_media': 'Redes sociales',
  'referral_search': 'Motor de búsqueda',
  'referral_other': 'Otro',
  'referral_other_specify': 'Por favor especifique',
  
  // Settings
  'account': 'Cuenta',
  'theme': 'Tema',
  'language': 'Idioma',
  'social': 'Social',
  'security': 'Seguridad',
  'payments': 'Pagos',
  'payment_methods': 'Métodos de Pago',
  'advanced': 'Avanzado',
  'change_interface_language': 'Cambiar idioma de la interfaz',
  
  // Common
  'save': 'Guardar',
  'cancel': 'Cancelar',
  'delete': 'Eliminar',
  'edit': 'Editar',
  'confirm': 'Confirmar',
  'loading': 'Cargando...',
  'error': 'Error',
  'success': 'Éxito',
  
  // Additional missing keys
  'pin_access': 'Acceso PIN',
  'pin_access_description': 'Configure el acceso PIN para seguridad adicional',
  'connection_history': 'Historial de Conexiones',
  'ip_address': 'Dirección IP',
  'login_time': 'Hora de Inicio de Sesión',
  'device': 'Dispositivo',
  'location': 'Ubicación',
  'no_connections': 'Sin conexiones recientes',
  'current_session': 'Sesión Actual',
};

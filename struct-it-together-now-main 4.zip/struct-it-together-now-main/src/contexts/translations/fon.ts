
export const fonTranslations = {
  // Navigation
  'home': 'Aɖò',
  'tontines': 'Tontines',
  'progress': 'Ɖòɖò',
  'messages': 'Nyǒnzàn',
  'settings': 'Nùɖòɖò',
  'back': 'Yì',
  
  // Authentication
  'sign_in': 'Zé',
  'sign_up': 'Ɖò akɔ̀ntà',
  'create_account': 'Wá Akɔ̀ntà',
  'email': 'Imɛ̀lì',
  'password': 'Nyíkplɔ̀n mítɔ̀n',
  'confirm_password': 'Ɖò Nyíkplɔ̀n mítɔ̀n lɛ',
  'first_name': 'Nyíkɔ́ gbàntó',
  'last_name': 'Nyíkɔ́ ɖàxótɔ̀',
  'age': 'Ohù',
  'logout': 'Kpò',
  'logout_success': 'Kpókpó bló',
  'logout_error': 'Kúnkún ɖé kpókpó mɛ',
  'session_management': 'Azán Ɖòɖò',
  'session_info': 'É zé bɛ́:',
  'logout_description': 'À ná kpò sín wè akɔ̀ntà mɛ bo yì aɖò gó.',
  
  // Forms
  'required_field': 'Afí éhè kló ɖò gbé',
  'invalid_email': 'Imɛ̀lì mɛ̀ɖé',
  'password_too_short': 'Nyíkplɔ̀n mítɔ̀n lɛ ɖò nɔ̀ ɖò ohò enɛ wu',
  'passwords_not_match': 'Nyíkplɔ̀n mítɔ̀n lɛ kò ɖokpó',
  'age_minimum': 'Wè ohù má sú gbà Nonru ɖò mɛ',
  'age_required': 'Ohù ɖò nɔ̀ kadi ɖò nɔ̀ ɖò xòmɛ ɖokpó',
  'invalid_age': 'Ohù ɖò nɔ̀ ɖò xòmɛ',
  
  // ReCAPTCHA
  'recaptcha_required': 'Jó ɖò ɖé má nyɛ̀n ròbòt',
  'recaptcha_failed': 'Núɖíɖí gbɛ̀. Jó ɖò gbé kpa náɖò ɖé má nyɛ̀n ròbòt.',
  
  // Signup
  'account_created_success': 'Akɔ̀ntà ɖà bló! Kpɔ̀n wè imɛ̀lì.',
  'creating_account': 'É ɖò wá akɔ̀ntà...',
  'already_have_account': 'Akɔ̀ntà ɖé ɖò wè gbɔ̀n ɖò à?',
  'email_confirmation_required': 'Imɛ̀lì ɖòɖò ɖé ná fí wè',
  'return_home': 'Yì Aɖò',
  'email_already_used': 'Imɛ̀lì éhè zán xoxo.',
  'password_security_error': 'Nyíkplɔ̀n mítɔ̀n má ɖò nú gbé.',
  'technical_error': 'Kúnkún ɖé ɖò azɔ̀n mɛ.',
  'form_validation_error': 'Jó ɖò ɖyɔ̀ kúnkún lɛ́',
  
  // Referral
  'referral_source': 'Àlò tòn mɛ wè nyɔ̀n Nonru?',
  'referral_friend': 'Xwégbè tòn',
  'referral_social_media': 'Médyà àdàkúnkún',
  'referral_search': 'Fífín',
  'referral_other': 'Ɖókpó',
  'referral_other_specify': 'Jó ɖò jló',
  
  // Settings
  'account': 'Akɔ̀ntà',
  'theme': 'Ɖaxó',
  'language': 'Gbè',
  'social': 'Àdàkúnkún',
  'security': 'Núɖíɖí',
  'payments': 'Fléfí',
  'payment_methods': 'Fléfí Ɖokpó Lɛ',
  'advanced': 'Àɖàngbé',
  'change_interface_language': 'Ɖyɔ̀ gbè ɖòɖò tɔn',
  
  // Common
  'save': 'Ɖù',
  'cancel': 'Gbé kpó',
  'delete': 'Tutu',
  'edit': 'Ɖyɔ̀',
  'confirm': 'Ɖò',
  'loading': 'É ɖò ɖò...',
  'error': 'Kúnkún',
  'success': 'Bló',
  
  // Additional missing keys
  'pin_access': 'PIN Hùn',
  'pin_access_description': 'Ɖò PIN hùn ɖò núɖíɖí ɖokpó kpo',
  'connection_history': 'Hùnhùnwhenu Tàngbé',
  'ip_address': 'IP Ñiiɓirde',
  'login_time': 'Hùn Azán',
  'device': 'Nyɔnukunmɛ',
  'location': 'Afimɛ',
  'no_connections': 'Hùnhùnwhenu ɖévo má ɖò',
  'current_session': 'Azán Ɖò Ɖò Lɛ',
};

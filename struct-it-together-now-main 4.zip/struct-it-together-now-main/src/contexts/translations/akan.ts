
export const akanTranslations = {
  // Navigation
  'home': 'Fie',
  'tontines': 'Tontines',
  'progress': 'Nkɔso',
  'messages': 'Nkrasɛm',
  'settings': 'Nhyehyɛeɛ',
  'back': 'San kɔ',
  
  // Authentication
  'sign_in': 'Hyɛ mu',
  'sign_up': 'Kyerɛw din',
  'create_account': 'Yɛ Account',
  'email': 'Email',
  'password': 'Password',
  'confirm_password': 'Si Password no so dua',
  'first_name': 'Din a ɛdi kan',
  'last_name': 'Abusua din',
  'age': 'Mfeɛ',
  'logout': 'Fi adi',
  'logout_success': 'Woafi adi yie',
  'logout_error': 'Mfomsoɔ wɔ afidie mu',
  'session_management': 'Session Nhyehyɛeɛ',
  'session_info': 'Woahyɛ mu sɛ:',
  'logout_description': 'Wobɛfi wo account mu na wosan akɔ fie kratafa no so.',
  
  // Forms
  'required_field': 'Yei hia',
  'invalid_email': 'Email a ɛnyɛ',
  'password_too_short': 'Password no ɛsɛ sɛ ɛyɛ nkyerɛwde 8 anaa ɛboro so',
  'passwords_not_match': 'Password ahodoɔ no nnyata',
  'age_minimum': 'Wo mfeɛ nso sua sɛ wobɛkyerɛw din wɔ Nonru so',
  'age_required': 'Mfeɛ hia na ɛsɛ sɛ ɛyɛ nɔma pa',
  'invalid_age': 'Mfeɛ ɛsɛ sɛ ɛyɛ nɔma pa',
  
  // ReCAPTCHA
  'recaptcha_required': 'Mesrɛ wo si so dua sɛ wo nyɛ robot',
  'recaptcha_failed': 'Ahobammɔ nhwehwɛmu no antumi. Mesrɛ wo hyɛ adaka no mu na si so dua sɛ wo nyɛ robot.',
  
  // Signup
  'account_created_success': 'Wɔayɛ account no yie! Hwɛ wo email.',
  'creating_account': 'Ɛreyɛ account...',
  'already_have_account': 'Wowɔ account dada?',
  'email_confirmation_required': 'Wɔde email a ɛbɛsi so dua no bɛkɔ wo nkyɛn',
  'return_home': 'San kɔ Fie',
  'email_already_used': 'Wɔde saa email yi ayɛ adwuma dada.',
  'password_security_error': 'Password no nyɛ ahobammɔ nhwɛsoɔ ahorow no.',
  'technical_error': 'Mfomsoɔ bi asi wɔ adwumayɛ mu.',
  'form_validation_error': 'Mesrɛ wo siesie form no mu mfomsoɔ no',
  
  // Referral
  'referral_source': 'Ɛhe na wohunuu Nonru?',
  'referral_friend': 'Adamfo bi fam',
  'referral_social_media': 'Social media',
  'referral_search': 'Search engine',
  'referral_other': 'Foforɔ',
  'referral_other_specify': 'Mesrɛ wo kyerɛkyerɛ mu',
  
  // Settings
  'account': 'Account',
  'theme': 'Sini',
  'language': 'Kasa',
  'social': 'Asetena',
  'security': 'Ahobammɔ',
  'payments': 'Akatua',
  'payment_methods': 'Akatua Akwan',
  'advanced': 'Nea ɛkɔ anim',
  'change_interface_language': 'Sesa interface kasa',
  
  // Common
  'save': 'Kora',
  'cancel': 'Gyae',
  'delete': 'Yi fi',
  'edit': 'Sesa',
  'confirm': 'Si so dua',
  'loading': 'Ɛreload...',
  'error': 'Mfomsoɔ',
  'success': 'Yɛɛ yie',
  
  // Additional missing keys
  'pin_access': 'PIN Kwan',
  'pin_access_description': 'Sesa PIN kwan ma ahobammɔ nkekaho',
  'connection_history': 'Nkitahodi Abakɔsɛm',
  'ip_address': 'IP Address',
  'login_time': 'Hyɛ Mu Mmere',
  'device': 'Mfiri',
  'location': 'Beae',
  'no_connections': 'Nkitahodi biara nni hɔ',
  'current_session': 'Session a ɛwɔ hɔ seesei',
};

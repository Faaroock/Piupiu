
export const jaTranslations = {
  // Navigation
  'home': 'ホーム',
  'tontines': '頼母子講',
  'progress': '進捗',
  'messages': 'メッセージ',
  'settings': '設定',
  'back': '戻る',
  
  // Authentication
  'sign_in': 'ログイン',
  'sign_up': '登録',
  'create_account': 'アカウント作成',
  'email': 'メールアドレス',
  'password': 'パスワード',
  'confirm_password': 'パスワード確認',
  'first_name': '名',
  'last_name': '姓',
  'age': '年齢',
  'logout': 'ログアウト',
  'logout_success': 'ログアウトしました',
  'logout_error': 'ログアウト時にエラーが発生しました',
  'session_management': 'セッション管理',
  'session_info': 'ログイン中：',
  'logout_description': 'アカウントからログアウトし、ホームページにリダイレクトされます。',
  
  // Forms
  'required_field': 'この項目は必須です',
  'invalid_email': '無効なメールアドレス',
  'password_too_short': 'パスワードは8文字以上である必要があります',
  'passwords_not_match': 'パスワードが一致しません',
  'age_minimum': 'Nonruに登録するための最低年齢に達していません',
  'invalid_age': '年齢は有効な数値である必要があります',
  
  // ReCAPTCHA
  'recaptcha_required': 'あなたがロボットでないことを確認してください',
  'recaptcha_failed': 'セキュリティ検証に失敗しました。ボックスにチェックを入れて、あなたがロボットでないことを確認してください。',
  
  // Signup
  'account_created_success': 'アカウントが正常に作成されました！メールを確認してください。',
  'creating_account': 'アカウントを作成中...',
  'already_have_account': 'すでにアカウントをお持ちですか？',
  'email_confirmation_required': '確認メールがあなたのメールアドレスに送信されます',
  'return_home': 'ホームに戻る',
  'email_already_used': 'このメールアドレスは既に使用されています。',
  'password_security_error': 'パスワードがセキュリティ要件を満たしていません。',
  'technical_error': '技術的なエラーが発生しました。',
  'form_validation_error': 'フォームのエラーを修正してください',
  
  // Referral
  'referral_source': 'Nonruをどのように知りましたか？',
  'referral_friend': '友人から',
  'referral_social_media': 'ソーシャルメディア',
  'referral_search': '検索エンジン',
  'referral_other': 'その他',
  'referral_other_specify': '詳しく教えてください',
  
  // Settings
  'account': 'アカウント',
  'theme': 'テーマ',
  'language': '言語',
  'social': 'ソーシャル',
  'security': 'セキュリティ',
  'payments': '支払い',
  'advanced': '詳細設定',
  'change_interface_language': 'インターフェース言語を変更',
  
  // Common
  'save': '保存',
  'cancel': 'キャンセル',
  'delete': '削除',
  'edit': '編集',
  'confirm': '確認',
  'loading': '読み込み中...',
  'error': 'エラー',
  'success': '成功',
};

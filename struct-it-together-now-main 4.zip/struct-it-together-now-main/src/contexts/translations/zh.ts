
export const zhTranslations = {
  // Navigation
  'home': '首页',
  'tontines': '互助会',
  'progress': '进度',
  'messages': '消息',
  'settings': '设置',
  'back': '返回',
  
  // Authentication
  'sign_in': '登录',
  'sign_up': '注册',
  'create_account': '创建账户',
  'email': '电子邮箱',
  'password': '密码',
  'confirm_password': '确认密码',
  'first_name': '名',
  'last_name': '姓',
  'age': '年龄',
  'logout': '退出登录',
  'logout_success': '成功退出登录',
  'logout_error': '退出登录时出错',
  'session_management': '会话管理',
  'session_info': '登录身份：',
  'logout_description': '您将退出账户并重定向到首页。',
  
  // Forms
  'required_field': '此字段为必填项',
  'invalid_email': '无效的电子邮箱地址',
  'password_too_short': '密码至少需要8个字符',
  'passwords_not_match': '密码不匹配',
  'age_minimum': '您不满足在Nonru注册的最低年龄要求',
  'age_required': '年龄是必需的，必须是有效数字',
  'invalid_age': '年龄必须是有效数字',
  
  // ReCAPTCHA
  'recaptcha_required': '请确认您不是机器人',
  'recaptcha_failed': '安全验证失败。请勾选框确认您不是机器人。',
  
  // Signup
  'account_created_success': '账户创建成功！请查看您的邮箱。',
  'creating_account': '正在创建账户...',
  'already_have_account': '已有账户？',
  'email_confirmation_required': '确认邮件将发送到您的邮箱地址',
  'return_home': '返回首页',
  'email_already_used': '此邮箱地址已被使用。',
  'password_security_error': '密码不符合安全要求。',
  'technical_error': '发生技术错误。',
  'form_validation_error': '请纠正表单错误',
  
  // Referral
  'referral_source': '您是如何了解Nonru的？',
  'referral_friend': '通过朋友',
  'referral_social_media': '社交媒体',
  'referral_search': '搜索引擎',
  'referral_other': '其他',
  'referral_other_specify': '请详细说明',
  
  // Settings
  'account': '账户',
  'theme': '主题',
  'language': '语言',
  'social': '社交',
  'security': '安全',
  'payments': '支付',
  'payment_methods': '支付方式',
  'advanced': '高级',
  'change_interface_language': '更改界面语言',
  
  // Common
  'save': '保存',
  'cancel': '取消',
  'delete': '删除',
  'edit': '编辑',
  'confirm': '确认',
  'loading': '加载中...',
  'error': '错误',
  'success': '成功',
  
  // Additional missing keys
  'pin_access': 'PIN访问',
  'pin_access_description': '配置PIN访问以增强安全性',
  'connection_history': '连接历史',
  'ip_address': 'IP地址',
  'login_time': '登录时间',
  'device': '设备',
  'location': '位置',
  'no_connections': '没有最近的连接',
  'current_session': '当前会话',
};

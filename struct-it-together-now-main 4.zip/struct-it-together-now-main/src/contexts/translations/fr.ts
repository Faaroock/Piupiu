
export const fr = {
  // Navigation générale
  dashboard: "Tableau de bord",
  tontines: "Tontines",
  create: "Créer",
  progress: "Progrès",
  settings: "Paramètres",
  messages: "Messages",
  home: "Accueil",
  
  // Authentication
  sign_in: "Se connecter",
  sign_up: "S'inscrire",
  create_account: "Créer un compte",
  email: "Email",
  password: "Mot de passe",
  confirm_password: "Confirmer le mot de passe",
  first_name: "Prénom",
  last_name: "Nom",
  age: "Âge",
  loading: "Chargement...",
  success: "Succès",
  error: "Erreur",
  
  // Form validation
  required_field: "Ce champ est obligatoire",
  invalid_email: "Format d'email invalide",
  password_too_short: "Le mot de passe doit contenir au moins 8 caractères",
  passwords_not_match: "Les mots de passe ne correspondent pas",
  age_required: "L'âge est obligatoire",
  age_minimum: "Vous n'avez pas l'âge requis pour vous inscrire sur Nonru",
  
  // Errors
  technical_error: "Une erreur technique s'est produite",
  email_already_used: "Cette adresse email est déjà utilisée",
  password_security_error: "Le mot de passe ne respecte pas les critères de sécurité",
  form_validation_error: "Veuillez corriger les erreurs du formulaire",
  
  // reCAPTCHA
  recaptcha_required: "Vérification requise",
  recaptcha_failed: "Veuillez confirmer que vous n'êtes pas un robot",
  
  // Success messages
  account_created_success: "Compte créé avec succès ! Vérifiez votre email.",
  creating_account: "Création du compte...",
  
  // Account related
  already_have_account: "Déjà un compte ?",
  no_account: "Pas de compte ?",
  email_confirmation_required: "Un email de confirmation sera envoyé pour activer votre compte. Vérifiez votre boîte mail après l'inscription.",
  
  // Referral
  referral_source: "Comment avez-vous connu NONRU ?",
  
  // Navigation
  return_home: "Retour à l'accueil",
  
  // Session management
  session_management: "Gestion de la session",
  session_info: "Connecté en tant que :",
  logout: "Se déconnecter",
  logout_success: "Déconnexion réussie",
  logout_error: "Erreur lors de la déconnexion",
  logout_description: "Vous serez déconnecté de votre compte et redirigé vers la page d'accueil.",
  
  // Passwords
  forgot_password: "oublié ?",
};


export const dendiTranslations = {
  // Navigation générale
  dashboard: "Dooru laabi",
  tontines: "Tontines",
  create: "Tagi",
  progress: "Hayandi",
  settings: "Teeltoo",
  messages: "Alhabaray",
  home: "Goy",
  
  // Authentication
  sign_in: "Huru",
  sign_up: "Waawi tagi",
  create_account: "Kontu tagi",
  email: "Email",
  password: "Sirru kalima",
  confirm_password: "Sirru kalima tasaddak",
  first_name: "Maŋgay",
  last_name: "Gooba",
  age: "Jiiri",
  loading: "Goy ka...",
  success: "Kala hankani",
  error: "Hasara",
  
  // Form validation
  required_field: "Woo waaji din",
  invalid_email: "Email format ši kala",
  password_too_short: "Sirru kalima ga hima ka 8 harufoo ra war",
  passwords_not_match: "Sirru kalimey ši boŋ",
  age_required: "Jiiri waaji",
  age_minimum: "Amma jiiri ši kala Nonru ga",
  
  // Errors
  technical_error: "Kala hasara fatta",
  email_already_used: "Woo email goy ra ka goy",
  password_security_error: "Sirru kalima ši nda kiray ma boŋ",
  form_validation_error: "Formu hasarey faaham",
  
  // reCAPTCHA
  recaptcha_required: "Bayrandi waaji",
  recaptcha_failed: "Amma ban taali din ka amma ši faaba",
  
  // Success messages
  account_created_success: "Kontu taga nda kala hankani! Amma email guna.",
  creating_account: "Kontu ka tagi...",
  
  // Account related
  already_have_account: "Kontu goy nda?",
  no_account: "Kontu babu?",
  email_confirmation_required: "Email tasaddak alhabara ga too ka kontu šenandi. Amma borey guna ka waawi.",
  
  // Referral
  referral_source: "Amma ma NONRU bay noo?",
  
  // Navigation
  return_home: "Goy ga willi",
  
  // Session management
  session_management: "Session juwal",
  session_info: "Huru ka nda:",
  logout: "Fatta",
  logout_success: "Fatta nda kala hankani",
  logout_error: "Hasara fatta waati",
  logout_description: "Amma ga fatta kontu ga nda goy sahãn ga willi.",
  
  // Passwords
  forgot_password: "ɲaama?",
  
  // Tontines
  discover_tontine_types: "Yiyloo fannu tontines ɓe jam'en amen yidaa",
};


export const yorubaTranslations = {
  // Navigation
  'home': 'Ile',
  'tontines': 'Tontines',
  'progress': 'Ilọsiwaju',
  'messages': 'Ifiranṣẹ',
  'settings': 'Eto',
  'back': 'Pada',
  
  // Authentication
  'sign_in': 'Wọle',
  'sign_up': 'Forukọsilẹ',
  'create_account': 'Ṣẹda Account',
  'email': 'Imeeli',
  'password': 'Ọrọ-igbaniwọle',
  'confirm_password': 'Jẹrisi Ọrọ-igbaniwọle',
  'first_name': 'Orukọ akọkọ',
  'last_name': 'Orukọ idile',
  'age': 'Ọjọ ori',
  'logout': 'Jade',
  'logout_success': 'Ijabọ ni aṣeyọri',
  'logout_error': 'Aṣiṣe ni ijabọ',
  'session_management': 'Iṣakoso Igba',
  'session_info': 'Wọle bi:',
  'logout_description': 'A o jade kuro ni account rẹ ki o si pada si oju-iwe akọkọ.',
  
  // Forms
  'required_field': 'Aaye yii jẹ dandan',
  'invalid_email': 'Adirẹsi imeeli ti ko tọ',
  'password_too_short': 'Ọrọ-igbaniwọle gbọdọ jẹ o kere ju awọn kikọ 8',
  'passwords_not_match': 'Awọn ọrọ-igbaniwọle ko baamu',
  'age_minimum': 'O ko ba ọjọ ori ti o kere ju lati forukọsilẹ si Nonru',
  'age_required': 'Ọjọ ori jẹ dandan ati pe o gbọdọ jẹ nọmba to peye',
  'invalid_age': 'Ọjọ ori gbọdọ jẹ nọmba to peye',
  
  // ReCAPTCHA
  'recaptcha_required': 'Jọwọ jẹrisi pe o kii ṣe robot',
  'recaptcha_failed': 'Idaniloju aabo kuna. Jọwọ ṣayẹwo apoti lati jẹrisi pe o kii ṣe robot.',
  
  // Signup
  'account_created_success': 'Account ti ṣẹda ni aṣeyọri! Ṣayẹwo imeeli rẹ.',
  'creating_account': 'Nṣẹda account...',
  'already_have_account': 'Ṣe o ni account tẹlẹ?',
  'email_confirmation_required': 'Imeeli ijẹrisi yoo firanṣẹ si adirẹsi rẹ',
  'return_home': 'Pada si Ile',
  'email_already_used': 'Adirẹsi imeeli yii ti lo tẹlẹ.',
  'password_security_error': 'Ọrọ-igbaniwọle ko ba awọn ibeere aabo mu.',
  'technical_error': 'Aṣiṣe imọ-ẹrọ kan waye.',
  'form_validation_error': 'Jọwọ ṣatunṣe awọn aṣiṣe fọọmu',
  
  // Referral
  'referral_source': 'Bawo ni o ṣe gbọ nipa Nonru?',
  'referral_friend': 'Nipasẹ ọrẹ kan',
  'referral_social_media': 'Media awujọ',
  'referral_search': 'Ẹnjin wiwa',
  'referral_other': 'Miiran',
  'referral_other_specify': 'Jọwọ sọ pato',
  
  // Settings
  'account': 'Account',
  'theme': 'Akori',
  'language': 'Ede',
  'social': 'Awujọ',
  'security': 'Aabo',
  'payments': 'Awọn sisanwo',
  'payment_methods': 'Awọn ọna sisanwo',
  'advanced': 'To siwaju',
  'change_interface_language': 'Yi ede interface pada',
  
  // Common
  'save': 'Fi pamọ',
  'cancel': 'Fagilee',
  'delete': 'Paarẹ',
  'edit': 'Ṣatunkọ',
  'confirm': 'Jẹrisi',
  'loading': 'Ngbọn...',
  'error': 'Aṣiṣe',
  'success': 'Aṣeyọri',
  
  // Additional missing keys
  'pin_access': 'Iwọle PIN',
  'pin_access_description': 'Ṣeto iwọle PIN fun aabo afikun',
  'connection_history': 'Itan-akọọlẹ Asopọ',
  'ip_address': 'Adirẹsi IP',
  'login_time': 'Akoko Wiwọle',
  'device': 'Ẹrọ',
  'location': 'Ipo',
  'no_connections': 'Ko si awọn asopọ laipẹ',
  'current_session': 'Igba Lọwọlọwọ',
};

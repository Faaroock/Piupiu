import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { fr } from './translations/fr';
import { enTranslations } from './translations/en';
import { esTranslations } from './translations/es';
import { dendiTranslations } from './translations/dendi';
import { fonTranslations } from './translations/fon';
import { yorubaTranslations } from './translations/yoruba';
import { akanTranslations } from './translations/akan';
import { zhTranslations } from './translations/zh';
import { jaTranslations } from './translations/ja';

type LanguageCode = 'fr' | 'en' | 'es' | 'dendi' | 'fon' | 'yoruba' | 'akan' | 'zh' | 'ja';

interface LanguageInfo {
  code: LanguageCode;
  name: string;
  nativeName: string;
  flag: string;
}

interface LanguageContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: (key: string) => string;
  availableLanguages: LanguageInfo[];
}

const translations = {
  fr: fr,
  en: enTranslations,
  es: esTranslations,
  dendi: dendiTranslations,
  fon: fonTranslations,
  yoruba: yorubaTranslations,
  akan: akanTranslations,
  zh: zhTranslations,
  ja: jaTranslations,
};

const availableLanguages: LanguageInfo[] = [
  { code: 'dendi', name: 'Dendi', nativeName: 'Dendi (Djougou)', flag: '🇧🇯' },
  { code: 'fon', name: 'Fon', nativeName: 'Fongbe', flag: '🇧🇯' },
  { code: 'yoruba', name: 'Yoruba', nativeName: 'Yorùbá', flag: '🇳🇬' },
  { code: 'akan', name: 'Akan (Ashanti)', nativeName: 'Akan (Asante)', flag: '🇬🇭' },
  { code: 'fr', name: 'French', nativeName: 'Français', flag: '🇫🇷' },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', nativeName: 'Español', flag: '🇪🇸' },
  { code: 'zh', name: 'Chinese', nativeName: '中文', flag: '🇨🇳' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語', flag: '🇯🇵' },
];

// Fonction pour détecter la langue du navigateur
const detectBrowserLanguage = (): LanguageCode => {
  const browserLang = navigator.language || navigator.languages?.[0] || 'fr';
  const langCode = browserLang.split('-')[0].toLowerCase();
  
  // Vérifier si la langue du navigateur est supportée
  const supportedLang = availableLanguages.find(lang => lang.code === langCode);
  return supportedLang ? supportedLang.code : 'fr';
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider = ({ children }: LanguageProviderProps) => {
  const [language, setLanguageState] = useState<LanguageCode>('fr');
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') as LanguageCode;
    if (savedLanguage && availableLanguages.some(lang => lang.code === savedLanguage)) {
      setLanguageState(savedLanguage);
    } else {
      // Utiliser la langue du navigateur si aucune langue sauvegardée
      const browserLanguage = detectBrowserLanguage();
      setLanguageState(browserLanguage);
    }
    setIsInitialized(true);
  }, []);

  const setLanguage = (lang: LanguageCode) => {
    console.log(`🌍 Changement de langue vers: ${lang}`);
    setLanguageState(lang);
    localStorage.setItem('language', lang);
    
    // Force re-render of all components that use translations
    window.dispatchEvent(new Event('languageChanged'));
  };

  const t = (key: string): string => {
    // Si la clé est vide ou undefined, retourner une chaîne vide
    if (!key) {
      console.warn(`🌍 Translation key is empty or undefined`);
      return '';
    }

    // Nettoyer la clé des caractères spéciaux pour éviter les problèmes d'affichage
    const cleanKey = key.replace(/[<>]/g, '');
    
    const translation = translations[language][cleanKey as keyof typeof translations[typeof language]];
    if (translation) {
      return translation;
    }
    
    // Fallback to French if translation not found
    const fallback = translations.fr[cleanKey as keyof typeof translations.fr];
    if (fallback) {
      console.warn(`🌍 Translation missing for key "${cleanKey}" in language "${language}", using French fallback`);
      return fallback;
    }
    
    // Fallback to English if French not found
    const englishFallback = translations.en[cleanKey as keyof typeof translations.en];
    if (englishFallback) {
      console.warn(`🌍 Translation missing for key "${cleanKey}" in languages "${language}" and "fr", using English fallback`);
      return englishFallback;
    }
    
    // En derniers recours, transformer la clé en texte lisible
    console.warn(`🌍 Translation missing for key "${cleanKey}" in all languages`);
    
    // Transformer une clé comme "pin_access" en "Pin Access"
    const humanReadableKey = cleanKey
      .split('_')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
    
    return humanReadableKey;
  };

  const value: LanguageContextType = {
    language,
    setLanguage,
    t,
    availableLanguages,
  };

  // Ne pas rendre le provider avant l'initialisation pour éviter les flashs
  if (!isInitialized) {
    return null;
  }

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

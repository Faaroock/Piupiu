
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { ArrowRight, Users, TrendingUp, Shield, Globe } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { LanguageSelector } from "@/components/ui/LanguageSelector";

const PublicHome = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header avec sélecteur de langue */}
      <div className="absolute top-4 right-4 z-10">
        <LanguageSelector />
      </div>
      
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center relative z-0">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Logo et titre principal */}
          <div className="space-y-6">
            <div className="w-24 h-24 bg-primary/10 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto shadow-2xl overflow-hidden">
              <img 
                src="/lovable-uploads/96f015fd-6988-4f61-a0ab-19c20aa8a6d3.png" 
                alt="NONRU" 
                className="w-full h-full object-cover rounded-full"
              />
            </div>
            <h1 className="text-6xl md:text-7xl font-bold text-foreground mb-4 tracking-tight">
              NONRU
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              La plateforme digitale qui révolutionne l'épargne collective en Afrique
            </p>
          </div>

          {/* Fonctionnalités principales */}
          <div className="grid md:grid-cols-3 gap-6 my-12">
            <Card className="bg-card border-border">
              <CardHeader>
                <Users className="w-8 h-8 text-primary mb-2" />
                <CardTitle className="text-card-foreground">Épargne Communautaire</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Rejoignez des groupes d'épargne locaux et atteignez vos objectifs ensemble
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <TrendingUp className="w-8 h-8 text-primary mb-2" />
                <CardTitle className="text-card-foreground">Suivi Intelligent</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Suivez vos progrès et optimisez votre épargne avec nos outils avancés
                </p>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardHeader>
                <Shield className="w-8 h-8 text-primary mb-2" />
                <CardTitle className="text-card-foreground">Sécurité Garantie</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Vos fonds sont protégés par des technologies de pointe et des partenaires de confiance
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Call to action */}
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button asChild size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 text-lg px-8 py-3 shadow-xl">
                <Link to="/signup">
                  Commencer maintenant
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </Button>
              
              <Button asChild variant="outline" size="lg" className="border-border text-foreground hover:bg-accent text-lg px-8 py-3">
                <Link to="/signin">
                  Se connecter
                </Link>
              </Button>
            </div>
            
            <p className="text-muted-foreground text-sm">
              Déjà membre ? 
              <Link to="/signin" className="text-primary underline hover:text-primary/80 ml-1">
                Connectez-vous ici
              </Link>
            </p>
          </div>

          {/* Informations supplémentaires */}
          <div className="mt-16 text-muted-foreground text-sm">
            <p>Disponible en plusieurs langues</p>
            <div className="flex items-center justify-center mt-2 space-x-2">
              <Globe className="w-4 h-4" />
              <span>Support multilingue pour toute l'Afrique</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PublicHome;

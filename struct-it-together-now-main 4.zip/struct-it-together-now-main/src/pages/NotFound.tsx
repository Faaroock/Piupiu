
import { useLocation, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Home, RefreshCw } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

const NotFound = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { t } = useLanguage();

  useEffect(() => {
    console.error(
      "404 Error: User attempted to access non-existent route:",
      location.pathname
    );
  }, [location.pathname]);

  const handleGoHome = () => {
    navigate("/dashboard");
  };

  const handleRefresh = () => {
    window.location.reload();
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <div className="text-center max-w-md mx-auto p-6">
        <div className="text-6xl mb-4">🔍</div>
        <h1 className="text-4xl font-bold mb-4 text-gray-800">404</h1>
        <p className="text-xl text-gray-600 mb-6">{t("page_not_found") || "Oops! Page introuvable"}</p>
        <p className="text-sm text-gray-500 mb-8">
          {t("page_not_found_description") || "La page que vous recherchez n'existe pas ou a été déplacée."}
        </p>
        
        <div className="space-y-3">
          <Button 
            onClick={handleGoHome} 
            className="w-full bg-[#00B894] hover:bg-[#00B894]/90"
          >
            <Home className="w-4 h-4 mr-2" />
            {t("return_home") || "Retour à l'accueil"}
          </Button>
          
          <Button 
            onClick={handleRefresh} 
            variant="outline"
            className="w-full"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            {t("refresh_page") || "Actualiser la page"}
          </Button>
        </div>
        
        <div className="mt-8 text-xs text-gray-400">
          Route actuelle: {location.pathname}
        </div>
      </div>
    </div>
  );
};

export default NotFound;

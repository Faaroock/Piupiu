import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Target, TrendingUp, Award } from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { useState } from "react";
import { TontineRequestModal } from "@/components/tontines/TontineRequestModal";
import { BottomNavigation } from "@/components/layout/BottomNavigation";
import { NavigationPage } from "@/pages/Dashboard";

const Explore = () => {
  const { isAuthenticated } = useAuth();
  const { t } = useLanguage();
  const [selectedTontine, setSelectedTontine] = useState<any>(null);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [currentPage, setCurrentPage] = useState<NavigationPage>("home");

  const handleNavigate = (page: NavigationPage) => {
    setCurrentPage(page);
    // Add navigation logic here if needed
  };

  const tontines = [
    {
      id: "1",
      name: "Achat groupé de riz",
      description: "Économisons ensemble sur l'achat de sacs de riz de qualité",
      contribution_amount: "2 500 F / semaine",
      members: "12 / 15",
      progress: 80,
      icon: Award,
      category: "Alimentation"
    },
    {
      id: "2",
      name: "Épargne mariage",
      description: "Préparons nos mariages ensemble avec une épargne collective",
      contribution_amount: "5 000 F / mois",
      members: "8 / 10",
      progress: 65,
      icon: Target,
      category: "Événements"
    },
    {
      id: "3",
      name: "Investissement petit commerce",
      description: "Lançons nos petits commerces avec un fonds commun",
      contribution_amount: "10 000 F / mois",
      members: "6 / 8",
      progress: 90,
      icon: TrendingUp,
      category: "Business"
    },
    {
      id: "4",
      name: "Équipement informatique",
      description: "Achetons des ordinateurs pour nos études",
      contribution_amount: "15 000 F / mois",
      members: "4 / 6",
      progress: 45,
      icon: Target,
      category: "Éducation"
    },
    {
      id: "5",
      name: "Voyage en groupe",
      description: "Organisons un voyage de groupe économique",
      contribution_amount: "8 000 F / mois",
      members: "10 / 12",
      progress: 75,
      icon: Users,
      category: "Loisirs"
    },
    {
      id: "6",
      name: "Fonds de santé",
      description: "Constituons un fonds d'urgence santé",
      contribution_amount: "3 000 F / mois",
      members: "15 / 20",
      progress: 55,
      icon: Target,
      category: "Santé"
    }
  ];

  const handleJoinTontine = (tontine: any) => {
    if (isAuthenticated) {
      setSelectedTontine(tontine);
      setShowRequestModal(true);
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            {t("explore")} {t("tontines").toLowerCase()}
          </h1>
          <p className="text-xl text-muted-foreground mb-6">
            Découvrez les tontines disponibles et rejoignez celles qui vous intéressent
          </p>
          {!isAuthenticated && (
            <div className="bg-[#00B894]/10 border border-[#00B894]/20 rounded-lg p-4 mb-8">
              <p className="text-foreground font-medium mb-2">
                Tu peux explorer librement, mais il faut t'inscrire pour participer.
              </p>
              <Button asChild className="bg-[#00B894] hover:bg-[#00B894]/90">
                <Link to="/signup">S'inscrire maintenant</Link>
              </Button>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tontines.map((tontine) => {
            const Icon = tontine.icon;
            return (
              <Card key={tontine.id} className="hover:shadow-lg transition-shadow border-border">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 bg-[#fab005]/20 rounded-lg flex items-center justify-center">
                      <Icon className="text-[#fab005]" size={24} />
                    </div>
                    <span className="text-xs px-2 py-1 bg-secondary rounded-full text-muted-foreground">
                      {tontine.category}
                    </span>
                  </div>
                  
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    {tontine.name}
                  </h3>
                  <p className="text-muted-foreground mb-4 text-sm">
                    {tontine.description}
                  </p>
                  
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">{t("contribution_amount")}</span>
                      <span className="font-semibold text-foreground">{tontine.contribution_amount}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Membres</span>
                      <span className="font-semibold text-foreground">{tontine.members}</span>
                    </div>
                    <div className="w-full bg-secondary rounded-full h-2">
                      <div 
                        className="bg-[#00B894] h-2 rounded-full transition-all" 
                        style={{ width: `${tontine.progress}%` }}
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {tontine.progress}% de l'objectif atteint
                    </p>
                  </div>
                  
                  <Button 
                    onClick={() => handleJoinTontine(tontine)}
                    className="w-full mt-4 bg-[#00B894] hover:bg-[#00B894]/90"
                    disabled={!isAuthenticated}
                  >
                    {isAuthenticated ? (
                      t("join_tontine")
                    ) : (
                      <Link to="/signup">S'inscrire pour rejoindre</Link>
                    )}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Modal de demande de participation */}
      {selectedTontine && (
        <TontineRequestModal
          isOpen={showRequestModal}
          onClose={() => {
            setShowRequestModal(false);
            setSelectedTontine(null);
          }}
          tontine={selectedTontine}
        />
      )}
      
      <BottomNavigation currentPage={currentPage} onNavigate={handleNavigate} />
    </div>
  );
};

export default Explore;

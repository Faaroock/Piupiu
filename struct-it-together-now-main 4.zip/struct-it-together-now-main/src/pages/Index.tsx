
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

const Index = () => {
  const navigate = useNavigate();
  const { isAuthenticated, loading } = useAuth();

  useEffect(() => {
    // Attendre que l'état d'authentification soit chargé
    if (loading) return;
    
    console.log('Index: isAuthenticated =', isAuthenticated, 'loading =', loading);
    
    // Rediriger vers le dashboard si authentifié, sinon vers l'accueil public
    if (isAuthenticated) {
      console.log('Redirection vers dashboard');
      navigate("/dashboard", { replace: true });
    } else {
      console.log('Redirection vers public');
      navigate("/public", { replace: true });
    }
  }, [isAuthenticated, loading, navigate]);

  // Afficher un loader pendant le chargement de l'état d'authentification
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
        <p className="text-muted-foreground">
          {loading ? "Chargement..." : "Redirection en cours..."}
        </p>
      </div>
    </div>
  );
};

export default Index;

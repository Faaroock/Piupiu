
import { SettingsPage } from "@/components/settings/SettingsPage";
import { useNavigate } from "react-router-dom";

const Settings = () => {
  const navigate = useNavigate();

  const handleNavigate = (page: string) => {
    switch (page) {
      case "home":
        navigate("/dashboard");
        break;
      case "tontines":
        navigate("/tontines");
        break;
      case "create":
        navigate("/tontines/create");
        break;
      case "progress":
        navigate("/progress");
        break;
      case "settings":
        // Déjà sur la page settings
        break;
      default:
        navigate("/dashboard");
    }
  };

  return <SettingsPage onNavigate={handleNavigate} />;
};

export default Settings;


import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { PaymentTestInterface } from "@/components/payment/PaymentTestInterface";
import { useState } from "react";
import { BottomNavigation } from "@/components/layout/BottomNavigation";
import { NavigationPage } from "@/pages/Dashboard";

const PaymentTest = () => {
  const [currentPage, setCurrentPage] = useState<NavigationPage>("settings");

  const handleNavigate = (page: NavigationPage) => {
    setCurrentPage(page);
    // Add navigation logic here if needed
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button variant="ghost" asChild className="mb-6">
          <Link to="/dashboard">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour au tableau de bord
          </Link>
        </Button>
        
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Tests de Paiement</h1>
          <p className="text-muted-foreground">
            Interface de test pour MTN MoMo et Moov Money en mode sandbox
          </p>
        </div>

        <PaymentTestInterface />
      </div>
      
      <BottomNavigation currentPage={currentPage} onNavigate={handleNavigate} />
    </div>
  );
};

export default PaymentTest;


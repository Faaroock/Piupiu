
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BottomNavigation } from "@/components/layout/BottomNavigation";
import { TrendingUp, Users, Target, Plus, ArrowLeft } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { LanguageSelector } from "@/components/ui/LanguageSelector";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { MessagesPage } from "@/components/messages/MessagesPage";
import { TontinesPage } from "@/components/tontines/TontinesPage";
import { CreateTontinePage } from "@/components/tontines/CreateTontinePage";
import { NotificationBell } from "@/components/notifications/NotificationBell";
import { NotificationCenter } from "@/components/notifications/NotificationCenter";

export type NavigationPage = "home" | "tontines" | "create" | "progress" | "settings" | "messages";

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState<NavigationPage>("home");
  const [notificationOpen, setNotificationOpen] = useState(false);

  // Extract name from user metadata or email
  const getUserDisplayName = () => {
    if (user?.user_metadata?.first_name) {
      return user.user_metadata.first_name;
    }
    if (user?.email) {
      return user.email.split('@')[0];
    }
    return 'Utilisateur';
  };

  const handleNavigate = (page: NavigationPage) => {
    console.log(`Navigation vers: ${page}`);
    setCurrentPage(page);
    
    // Navigation logic pour certaines pages spéciales
    switch (page) {
      case "progress":
        navigate("/progress");
        break;
      case "settings":
        navigate("/settings");
        break;
      default:
        // Les autres pages restent dans le Dashboard
        break;
    }
  };

  // Function to render the current page content
  const renderCurrentPage = () => {
    switch (currentPage) {
      case "messages":
        return <MessagesPage onNavigate={handleNavigate} />;
      case "tontines":
        return <TontinesPage onNavigate={handleNavigate} />;
      case "create":
        return <CreateTontinePage onNavigate={handleNavigate} />;
      default:
        return renderDashboardHome();
    }
  };

  const renderDashboardHome = () => (
    <div className="min-h-screen bg-background pb-20">
      {/* Header avec notifications et contrôles */}
      <div className="bg-white/95 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo avec la nouvelle image */}
            <div className="flex-shrink-0 flex items-center">
              <div className="w-10 h-10 rounded-full overflow-hidden mr-3">
                <img 
                  src="/lovable-uploads/96f015fd-6988-4f61-a0ab-19c20aa8a6d3.png" 
                  alt="NONRU" 
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              <h1 className="text-2xl font-bold text-[#00B894]">NONRU</h1>
            </div>

            {/* Right side controls avec notifications */}
            <div className="flex items-center space-x-4">
              <NotificationBell onClick={() => setNotificationOpen(true)} />
              <LanguageSelector compact />
              <ThemeToggle />
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/")}
                className="text-muted-foreground hover:text-foreground"
              >
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Notification Center */}
      <NotificationCenter 
        isOpen={notificationOpen} 
        onClose={() => setNotificationOpen(false)} 
      />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Bonjour, {getUserDisplayName()} !
          </h1>
          <p className="text-muted-foreground">
            Bienvenue sur votre tableau de bord NONRU
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Mes Tontines</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-muted-foreground">
                +1 ce mois-ci
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Épargne Totale</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">125,000 F</div>
              <p className="text-xs text-muted-foreground">
                +12% par rapport au mois dernier
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Objectifs Atteints</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">2/3</div>
              <p className="text-xs text-muted-foreground">
                66% de réussite
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Actions Rapides</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                onClick={() => handleNavigate("create")}
                className="w-full bg-[#00B894] hover:bg-[#00B894]/90"
              >
                <Plus className="mr-2 h-4 w-4" />
                Créer une nouvelle tontine
              </Button>
              <Button 
                onClick={() => handleNavigate("tontines")}
                variant="outline" 
                className="w-full"
              >
                <Users className="mr-2 h-4 w-4" />
                Rejoindre une tontine
              </Button>
              <Button asChild variant="outline" className="w-full">
                <Link to="/progress">
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Voir mes progrès
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Mes Tontines Actives</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 border rounded-lg border-border">
                  <div>
                    <h4 className="font-medium">Épargne Mariage</h4>
                    <p className="text-sm text-muted-foreground">5,000 F / mois</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">60,000 F</p>
                    <p className="text-sm text-muted-foreground">12 mois</p>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-3 border rounded-lg border-border">
                  <div>
                    <h4 className="font-medium">Achat Groupé Riz</h4>
                    <p className="text-sm text-muted-foreground">2,500 F / semaine</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">15,000 F</p>
                    <p className="text-sm text-muted-foreground">6 semaines</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      {renderCurrentPage()}
      <BottomNavigation currentPage={currentPage} onNavigate={handleNavigate} />
    </div>
  );
};

export default Dashboard;

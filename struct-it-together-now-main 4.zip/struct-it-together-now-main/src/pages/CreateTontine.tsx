import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { useLanguage } from "@/contexts/LanguageContext";
import { useToast } from "@/hooks/use-toast";
import { BottomNavigation } from "@/components/layout/BottomNavigation";
import { NavigationPage } from "@/pages/Dashboard";

const CreateTontine = () => {
  const { t } = useLanguage();
  const { toast } = useToast();
  const [currentPage, setCurrentPage] = useState<NavigationPage>("create");
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    amount: "",
    frequency: "",
    members: "",
    duration: "",
    category: ""
  });

  const handleNavigate = (page: NavigationPage) => {
    setCurrentPage(page);
    // Add navigation logic here if needed
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Simuler la création de la tontine
      console.log("Création de tontine:", formData);
      
      // Générer un lien de partage
      const shareLink = `https://nonru.app/join/${Math.random().toString(36).substr(2, 9)}`;
      console.log("Lien de partage généré:", shareLink);
      
      toast({
        title: t("success"),
        description: `${t("create_tontine")} "${formData.name}" créée avec succès. Lien: ${shareLink}`,
      });
      
      // Réinitialiser le formulaire
      setFormData({
        name: "",
        description: "",
        amount: "",
        frequency: "",
        members: "",
        duration: "",
        category: ""
      });
      
    } catch (error) {
      console.error("Erreur création tontine:", error);
      toast({
        title: t("error"),
        description: "Erreur lors de la création de la tontine",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button variant="ghost" asChild className="mb-6">
          <Link to="/dashboard">
            <ArrowLeft className="mr-2 h-4 w-4" />
            {t("back")} au tableau de bord
          </Link>
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>{t("create_tontine")}</CardTitle>
            <p className="text-muted-foreground">
              Remplissez les informations pour créer votre tontine
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">{t("tontine_name")}</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  placeholder="Ex: Épargne pour mon mariage"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">{t("description")}</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  placeholder="Décrivez l'objectif de votre tontine..."
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="amount">{t("contribution_amount")}</Label>
                  <Input
                    id="amount"
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({...formData, amount: e.target.value})}
                    placeholder="5000"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="frequency">{t("frequency")}</Label>
                  <Select value={formData.frequency} onValueChange={(value) => setFormData({...formData, frequency: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder={`Choisir la ${t("frequency").toLowerCase()}`} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">{t("daily")} {t("daily_explanation")}</SelectItem>
                      <SelectItem value="weekly">{t("weekly")} {t("weekly_explanation")}</SelectItem>
                      <SelectItem value="monthly">{t("monthly")} {t("monthly_explanation")}</SelectItem>
                      <SelectItem value="quarterly">{t("quarterly")} {t("quarterly_explanation")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="members">{t("max_members")}</Label>
                  <Input
                    id="members"
                    type="number"
                    value={formData.members}
                    onChange={(e) => setFormData({...formData, members: e.target.value})}
                    placeholder="10"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="duration">{t("duration")}</Label>
                  <Input
                    id="duration"
                    type="number"
                    value={formData.duration}
                    onChange={(e) => setFormData({...formData, duration: e.target.value})}
                    placeholder="12"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">{t("category")}</Label>
                <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder={`Choisir une ${t("category").toLowerCase()}`} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="savings">Épargne générale</SelectItem>
                    <SelectItem value="event">Événement</SelectItem>
                    <SelectItem value="business">Business</SelectItem>
                    <SelectItem value="education">Éducation</SelectItem>
                    <SelectItem value="health">Santé</SelectItem>
                    <SelectItem value="housing">Logement</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-4 pt-4">
                <Button type="button" asChild variant="outline" className="flex-1">
                  <Link to="/tontines">{t("cancel")}</Link>
                </Button>
                <Button type="submit" className="flex-1 bg-[#00B894] hover:bg-[#00B894]/90">
                  {t("create_tontine")}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
      
      <BottomNavigation currentPage={currentPage} onNavigate={handleNavigate} />
    </div>
  );
};

export default CreateTontine;

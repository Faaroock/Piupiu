
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Mail, Phone, Shield } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { BottomNavigation } from "@/components/layout/BottomNavigation";
import { NavigationPage } from "@/pages/Dashboard";

const Privacy = () => {
  const [currentPage, setCurrentPage] = useState<NavigationPage>("settings");

  const handleNavigate = (page: NavigationPage) => {
    setCurrentPage(page);
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button variant="ghost" asChild className="mb-6">
          <Link to="/dashboard">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour au tableau de bord
          </Link>
        </Button>
        
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-4">
            Politique de Confidentialité
          </h1>
          <p className="text-muted-foreground">
            Dernière mise à jour : 17 juin 2025
          </p>
          <div className="flex items-center justify-center gap-4 mt-4 text-sm text-primary">
            <div className="flex items-center gap-1">
              <Mail className="w-4 h-4" />
              <a href="mailto:faaroockt@gmail.com" className="hover:underline">
                faaroockt@gmail.com
              </a>
            </div>
            <div className="flex items-center gap-1">
              <Phone className="w-4 h-4" />
              <a href="tel:+22901572184" className="hover:underline">
                +229 01 57 21 72 84
              </a>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>1. Introduction</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                La présente Politique de confidentialité décrit comment NONRU, accessible à l'adresse <a href="https://nonru.netlify.app" className="text-primary hover:underline">https://nonru.netlify.app</a>, collecte, utilise, stocke, protège et partage les informations personnelles de ses utilisateurs dans le cadre de ses services d'épargne solidaire, de tontines numériques et de gestion communautaire.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                En utilisant la plateforme NONRU, vous consentez à la collecte et à l'utilisation de vos données conformément à la présente politique.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>2. Données collectées</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-foreground mb-2">Données personnelles collectées lors de l'inscription :</h4>
                  <ul className="space-y-1 text-muted-foreground ml-4">
                    <li>• Nom complet</li>
                    <li>• Adresse e-mail</li>
                    <li>• Numéro de téléphone</li>
                    <li>• Photo de profil (le cas échéant)</li>
                    <li>• Identifiants provenant de fournisseurs tiers (Google, Facebook, etc.)</li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold text-foreground mb-2">Données collectées lors de l'utilisation de la plateforme :</h4>
                  <ul className="space-y-1 text-muted-foreground ml-4">
                    <li>• Activités liées aux tontines (création, participation, retrait, etc.)</li>
                    <li>• Solde normal et solde confiné</li>
                    <li>• Messages envoyés et reçus</li>
                    <li>• Historique de transactions</li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold text-foreground mb-2">Données techniques collectées automatiquement :</h4>
                  <ul className="space-y-1 text-muted-foreground ml-4">
                    <li>• Adresse IP</li>
                    <li>• Type de navigateur</li>
                    <li>• Informations de l'appareil</li>
                    <li>• Cookies techniques</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>3. Finalité de la collecte</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-3">Les données personnelles sont utilisées pour les finalités suivantes :</p>
              <ul className="space-y-2 text-muted-foreground ml-4 mb-4">
                <li>• Création et gestion du compte utilisateur</li>
                <li>• Participation aux tontines et aux groupes solidaires</li>
                <li>• Sécurisation de l'accès à la plateforme</li>
                <li>• Communication interne (notifications, alertes, messages)</li>
                <li>• Amélioration continue du service</li>
                <li>• Prévention des fraudes et respect des obligations légales</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed font-medium">
                Aucune donnée n'est utilisée à des fins publicitaires sans votre consentement explicite.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>4. Stockage et durée de conservation</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Les données sont stockées de manière sécurisée via notre base de données Supabase.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Elles sont conservées tant que le compte est actif. En cas de suppression de compte ou d'inactivité prolongée, les données sont archivées ou supprimées après un délai raisonnable, conformément à la réglementation en vigueur.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>5. Sécurité des données</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-3">
                NONRU met en œuvre des mesures techniques et organisationnelles rigoureuses pour protéger vos données :
              </p>
              <ul className="space-y-2 text-muted-foreground ml-4">
                <li>• Chiffrement des données en transit</li>
                <li>• Protection par authentification sécurisée</li>
                <li>• Surveillance active contre les accès non autorisés</li>
                <li>• Restrictions internes strictes</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>6. Partage des données</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-3 font-medium">
                Nous ne vendons ni ne louons vos données personnelles.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Vos données peuvent être partagées uniquement dans les cas suivants :
              </p>
              <ul className="space-y-2 text-muted-foreground ml-4">
                <li>• Fournisseurs techniques liés au bon fonctionnement du service (ex : Firebase, Supabase)</li>
                <li>• Obligations légales ou réquisitions judiciaires</li>
                <li>• À votre demande explicite (ex : export de vos données)</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>7. Vos droits</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-3">
                Conformément à la législation béninoise et aux standards internationaux (RGPD), vous disposez des droits suivants :
              </p>
              <ul className="space-y-2 text-muted-foreground ml-4 mb-4">
                <li>• Droit d'accès à vos données</li>
                <li>• Droit de rectification</li>
                <li>• Droit à l'effacement (droit à l'oubli)</li>
                <li>• Droit de limiter ou refuser un traitement</li>
                <li>• Droit à la portabilité de vos données</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed">
                Pour exercer ces droits, contactez-nous à <a href="mailto:faaroockt@gmail.com" className="text-primary hover:underline">faaroockt@gmail.com</a>.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>8. Consentement et modification</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                En créant un compte sur NONRU, vous acceptez cette Politique de confidentialité.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Cette politique peut être mise à jour à tout moment. En cas de modification significative, nous vous en informerons par e-mail ou notification sur la plateforme.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>9. Cookies</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                NONRU utilise des cookies essentiels pour garantir le fonctionnement du site (authentification, session, sécurité).
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Aucun cookie publicitaire ou de tracking tiers n'est utilisé.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Vous pouvez gérer ou désactiver les cookies depuis votre navigateur ou depuis les paramètres de votre compte.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>10. Enfants et mineurs</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                NONRU est accessible à partir de 15 ans, avec l'accord parental obligatoire entre 15 et 17 ans.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Nous ne collectons pas volontairement de données sur des personnes en dessous de cet âge sans autorisation d'un responsable légal.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>11. Responsabilité et limites</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                NONRU s'engage à protéger vos données. Toutefois, aucun système n'est infaillible. En cas de faille de sécurité, les utilisateurs seront notifiés dans les meilleurs délais, conformément aux lois en vigueur.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-primary">12. Contact</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">Email : </span>
                  <a href="mailto:faaroockt@gmail.com" className="text-primary hover:underline font-medium">
                    faaroockt@gmail.com
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">Téléphone : </span>
                  <a href="tel:+22901572184" className="text-primary hover:underline font-medium">
                    +229 01 57 21 72 84
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-green-800">🔒 Intégration utilisateur</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-green-700 leading-relaxed mb-3">
                Lors de l'inscription, l'utilisateur doit expressément cocher les cases suivantes :
              </p>
              <ul className="space-y-2 text-green-700">
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✅</span>
                  J'ai lu et j'accepte la Politique de confidentialité
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✅</span>
                  J'ai lu et j'accepte les Conditions Générales d'Utilisation
                </li>
              </ul>
              <p className="text-green-700 leading-relaxed mt-3 font-medium">
                Aucune création de compte n'est possible sans cette validation.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <BottomNavigation currentPage={currentPage} onNavigate={handleNavigate} />
    </div>
  );
};

export default Privacy;

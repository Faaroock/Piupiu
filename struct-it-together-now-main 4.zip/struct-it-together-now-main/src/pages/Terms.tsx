
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Mail, Phone } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { BottomNavigation } from "@/components/layout/BottomNavigation";
import { NavigationPage } from "@/pages/Dashboard";

const Terms = () => {
  const [currentPage, setCurrentPage] = useState<NavigationPage>("settings");

  const handleNavigate = (page: NavigationPage) => {
    setCurrentPage(page);
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button variant="ghost" asChild className="mb-6">
          <Link to="/dashboard">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour au tableau de bord
          </Link>
        </Button>
        
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-4">
            Conditions Générales d'Utilisation
          </h1>
          <p className="text-muted-foreground">
            Dernière mise à jour : 17 Juin 2025
          </p>
          <div className="flex items-center justify-center gap-4 mt-4 text-sm text-primary">
            <div className="flex items-center gap-1">
              <Mail className="w-4 h-4" />
              <a href="mailto:faaroockt@gmail.com" className="hover:underline">
                faaroockt@gmail.com
              </a>
            </div>
            <div className="flex items-center gap-1">
              <Phone className="w-4 h-4" />
              <a href="tel:+22901572184" className="hover:underline">
                +229 01 57 21 72 84
              </a>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                1. Objet des Conditions
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-slate max-w-none">
              <p className="text-muted-foreground leading-relaxed">
                Les présentes Conditions Générales d'Utilisation ont pour objet de définir les modalités et conditions d'accès et d'utilisation de la plateforme NONRU, un service numérique de tontines communautaires, d'épargne collective et de gestion de groupes financiers solidaires, accessible à l'adresse suivante : <a href="https://nonru.netlify.app" className="text-primary hover:underline">https://nonru.netlify.app</a>.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>2. Acceptation des Conditions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed">
                En accédant ou en utilisant la plateforme NONRU, vous acceptez sans réserve l'intégralité des présentes conditions. Si vous êtes en désaccord avec une quelconque partie de ces conditions, vous ne devez pas utiliser la plateforme.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>3. Création de Compte</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                L'inscription sur NONRU est nécessaire pour accéder à toutes les fonctionnalités. Lors de votre inscription, vous vous engagez à fournir des informations exactes, complètes et à jour.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Vous êtes responsable de la confidentialité de vos identifiants et de toutes les activités liées à votre compte.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>4. Utilisation de la Plateforme</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                L'utilisateur s'engage à utiliser NONRU de manière conforme aux lois en vigueur, aux présentes conditions et à l'éthique communautaire.
              </p>
              <p className="text-muted-foreground font-medium mb-2">Il est strictement interdit :</p>
              <ul className="space-y-2 text-muted-foreground ml-4">
                <li>• de détourner la plateforme pour des activités frauduleuses ou illégales ;</li>
                <li>• d'usurper l'identité d'une autre personne ;</li>
                <li>• de compromettre le bon fonctionnement du service par des actions malveillantes.</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>5. Conditions d'éligibilité</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                L'utilisation de NONRU est réservée aux personnes âgées d'au moins 15 ans. En accédant à la plateforme, vous déclarez avoir l'âge requis.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Si vous avez entre 15 et 17 ans, vous devez avoir reçu l'autorisation explicite de votre parent ou tuteur légal. Ce dernier accepte alors d'être lié par les présentes conditions pour toute utilisation de NONRU par le mineur.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                NONRU se réserve le droit de suspendre ou supprimer tout compte créé sans respecter cette exigence.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                La responsabilité du respect de cette clause incombe exclusivement à l'utilisateur ou à son représentant légal.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>6. Comportement et Sécurité</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground font-medium mb-2">Vous vous engagez à ne pas :</p>
              <ul className="space-y-2 text-muted-foreground ml-4 mb-4">
                <li>• harceler, intimider ou menacer un autre utilisateur ;</li>
                <li>• publier des contenus injurieux, violents, discriminatoires ou à caractère sexuel ;</li>
                <li>• contourner les systèmes de sécurité de la plateforme.</li>
              </ul>
              <p className="text-muted-foreground leading-relaxed">
                NONRU se réserve le droit de suspendre temporairement ou définitivement un compte en cas de violation de ces règles.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>7. Suspension et Résiliation</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                NONRU peut à tout moment suspendre ou résilier un compte utilisateur, avec ou sans préavis, en cas de manquement aux présentes conditions.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                L'utilisateur peut également demander la suppression de son compte via l'interface ou par contact à l'adresse : <a href="mailto:faaroockt@gmail.com" className="text-primary hover:underline">faaroockt@gmail.com</a>
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>8. Données personnelles et confidentialité</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Les données personnelles collectées sur NONRU sont utilisées dans le strict cadre de la gestion du service (création de tontine, messagerie interne, notifications, etc.).
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Aucune donnée n'est vendue à des tiers. Les utilisateurs peuvent demander la suppression de leurs données à tout moment.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Voir la <Link to="/privacy" className="text-primary hover:underline">Politique de Confidentialité</Link> pour plus de détails.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>9. Cookies</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                NONRU utilise des cookies fonctionnels pour garantir une bonne expérience utilisateur. Ces cookies ne sont pas utilisés à des fins publicitaires.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Aucune donnée sensible n'est stockée sans consentement. L'utilisateur peut refuser certains cookies dans son navigateur ou via les paramètres du site.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>10. Litiges et droit applicable</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground leading-relaxed mb-4">
                En cas de litige, NONRU encourage les parties à trouver un règlement amiable.
              </p>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Les présentes CGU sont régies par les lois en vigueur en République du Bénin.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                En utilisant NONRU, vous acceptez que tout différend soit soumis à la juridiction exclusive des tribunaux béninois.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-primary/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-primary">11. Contact</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground font-medium mb-3">Pour toute question ou réclamation :</p>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">Email : </span>
                  <a href="mailto:faaroockt@gmail.com" className="text-primary hover:underline font-medium">
                    faaroockt@gmail.com
                  </a>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-primary" />
                  <span className="text-muted-foreground">Téléphone : </span>
                  <a href="tel:+22901572184" className="text-primary hover:underline font-medium">
                    +229 01 57 21 72 84
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-green-800">12. Consentement à l'acceptation</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-green-700 leading-relaxed mb-3">
                Lors de l'inscription ou de l'utilisation de NONRU, l'utilisateur devra obligatoirement cocher les cases suivantes :
              </p>
              <ul className="space-y-2 text-green-700">
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✅</span>
                  J'ai lu et j'accepte les Conditions Générales d'Utilisation
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-600">✅</span>
                  J'ai lu et j'accepte la Politique de confidentialité
                </li>
              </ul>
              <p className="text-green-700 leading-relaxed mt-3 font-medium">
                Aucune inscription ne sera validée sans acceptation de ces éléments.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <BottomNavigation currentPage={currentPage} onNavigate={handleNavigate} />
    </div>
  );
};

export default Terms;

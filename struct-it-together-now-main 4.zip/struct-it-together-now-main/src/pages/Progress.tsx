import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress as ProgressBar } from "@/components/ui/progress";
import { TrendingUp, Target, Calendar } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { useState } from "react";
import { BottomNavigation } from "@/components/layout/BottomNavigation";
import { NavigationPage } from "@/pages/Dashboard";

const Progress = () => {
  const [currentPage, setCurrentPage] = useState<NavigationPage>("progress");

  const handleNavigate = (page: NavigationPage) => {
    setCurrentPage(page);
    // Add navigation logic here if needed
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button variant="ghost" asChild className="mb-6">
          <Link to="/dashboard">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Retour au tableau de bord
          </Link>
        </Button>
        
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Mes Progrès</h1>
          <p className="text-muted-foreground">Suivez l'évolution de vos épargnes et objectifs</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Épargné</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-[#00B894]">125,000 F</div>
              <p className="text-xs text-muted-foreground">
                +12% ce mois-ci
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Objectifs Atteints</CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">2/3</div>
              <p className="text-xs text-muted-foreground">
                66% de réussite
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Prochaine Cotisation</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">Dans 5 jours</div>
              <p className="text-xs text-muted-foreground">
                7,500 F au total
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Progression par Tontine</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium">Épargne Mariage</h4>
                  <span className="text-sm text-muted-foreground">60,000 F / 100,000 F</span>
                </div>
                <ProgressBar value={60} className="h-3" />
                <p className="text-sm text-muted-foreground mt-1">60% - En cours</p>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium">Achat Groupé Riz</h4>
                  <span className="text-sm text-muted-foreground">15,000 F / 20,000 F</span>
                </div>
                <ProgressBar value={75} className="h-3" />
                <p className="text-sm text-muted-foreground mt-1">75% - Presque terminé</p>
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium">Investissement Commerce</h4>
                  <span className="text-sm text-muted-foreground">50,000 F / 50,000 F</span>
                </div>
                <ProgressBar value={100} className="h-3" />
                <p className="text-sm text-[#00B894] mt-1">100% - Objectif atteint !</p>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Historique des Contributions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-3 border rounded-lg border-border">
                  <div>
                    <h4 className="font-medium">Épargne Mariage</h4>
                    <p className="text-sm text-muted-foreground">15 Décembre 2024</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-[#00B894]">+5,000 F</p>
                    <p className="text-sm text-muted-foreground">Mensuelle</p>
                  </div>
                </div>

                <div className="flex justify-between items-center p-3 border rounded-lg border-border">
                  <div>
                    <h4 className="font-medium">Achat Groupé Riz</h4>
                    <p className="text-sm text-muted-foreground">10 Décembre 2024</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-[#00B894]">+2,500 F</p>
                    <p className="text-sm text-muted-foreground">Hebdomadaire</p>
                  </div>
                </div>

                <div className="flex justify-between items-center p-3 border rounded-lg border-border">
                  <div>
                    <h4 className="font-medium">Investissement Commerce</h4>
                    <p className="text-sm text-muted-foreground">5 Décembre 2024</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-[#00B894]">+10,000 F</p>
                    <p className="text-sm text-muted-foreground">Mensuelle</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <BottomNavigation currentPage={currentPage} onNavigate={handleNavigate} />
    </div>
  );
};

export default Progress;

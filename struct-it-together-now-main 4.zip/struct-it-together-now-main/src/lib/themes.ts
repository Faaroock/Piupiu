
export interface PredefinedTheme {
  name: string;
  colors: {
    primary: string;
    secondary: string;
    background: string;
    foreground: string;
    accent: string;
  };
  cssVars: {
    [key: string]: string;
  };
}

export const predefinedThemes: PredefinedTheme[] = [
  {
    name: "NONRU Classic",
    colors: {
      primary: "#00B894",
      secondary: "#fab005", 
      background: "#ffffff",
      foreground: "#1a1a1a",
      accent: "#3498db"
    },
    cssVars: {
      "--primary": "165 100% 36%",
      "--primary-foreground": "0 0% 98%",
      "--secondary": "43 93% 47%",
      "--secondary-foreground": "0 0% 2%",
      "--background": "0 0% 100%",
      "--foreground": "0 0% 4%",
      "--accent": "204 70% 53%",
      "--accent-foreground": "0 0% 98%",
      "--muted": "210 40% 96%",
      "--muted-foreground": "215 16% 35%",
      "--card": "0 0% 100%",
      "--card-foreground": "0 0% 4%",
      "--border": "214 32% 91%",
      "--input": "214 32% 91%",
      "--destructive": "0 84% 60%",
      "--destructive-foreground": "0 0% 98%"
    }
  },
  {
    name: "Afrique",
    colors: {
      primary: "#e55039",
      secondary: "#f39801",
      background: "#fff8f0",
      foreground: "#2f1b14",
      accent: "#27ae60"
    },
    cssVars: {
      "--primary": "12 80% 56%",
      "--primary-foreground": "0 0% 98%",
      "--secondary": "37 93% 48%",
      "--secondary-foreground": "0 0% 4%",
      "--background": "36 100% 97%",
      "--foreground": "25 40% 8%",
      "--accent": "145 63% 42%",
      "--accent-foreground": "0 0% 98%",
      "--muted": "36 50% 92%",
      "--muted-foreground": "25 40% 20%",
      "--card": "36 100% 97%",
      "--card-foreground": "25 40% 8%",
      "--border": "36 30% 85%",
      "--input": "36 30% 85%",
      "--destructive": "0 84% 50%",
      "--destructive-foreground": "0 0% 98%"
    }
  },
  {
    name: "Sahara",
    colors: {
      primary: "#d4a574",
      secondary: "#f4d03f",
      background: "#faf6f0",
      foreground: "#5d4e37",
      accent: "#cd853f"
    },
    cssVars: {
      "--primary": "33 50% 65%",
      "--primary-foreground": "0 0% 4%",
      "--secondary": "46 85% 60%",
      "--secondary-foreground": "0 0% 4%",
      "--background": "40 60% 96%",
      "--foreground": "33 25% 28%",
      "--accent": "33 56% 53%",
      "--accent-foreground": "0 0% 98%",
      "--muted": "40 40% 90%",
      "--muted-foreground": "33 25% 40%",
      "--card": "40 60% 96%",
      "--card-foreground": "33 25% 28%",
      "--border": "40 30% 82%",
      "--input": "40 30% 82%",
      "--destructive": "0 84% 50%",
      "--destructive-foreground": "0 0% 98%"
    }
  },
  {
    name: "Beach",
    colors: {
      primary: "#00b4d8",
      secondary: "#90e0ef",
      background: "#f8fdff",
      foreground: "#023047",
      accent: "#ffb703"
    },
    cssVars: {
      "--primary": "192 100% 42%",
      "--primary-foreground": "0 0% 98%",
      "--secondary": "189 76% 75%",
      "--secondary-foreground": "0 0% 4%",
      "--background": "193 100% 98%",
      "--foreground": "200 95% 14%",
      "--accent": "42 100% 50%",
      "--accent-foreground": "0 0% 4%",
      "--muted": "193 50% 92%",
      "--muted-foreground": "200 95% 25%",
      "--card": "193 100% 98%",
      "--card-foreground": "200 95% 14%",
      "--border": "193 30% 85%",
      "--input": "193 30% 85%",
      "--destructive": "0 84% 50%",
      "--destructive-foreground": "0 0% 98%"
    }
  },
  {
    name: "Antarctique",
    colors: {
      primary: "#a8dadc",
      secondary: "#e3f2fd",
      background: "#f1f8e9",
      foreground: "#1d3557",
      accent: "#457b9d"
    },
    cssVars: {
      "--primary": "182 34% 76%",
      "--primary-foreground": "0 0% 4%",
      "--secondary": "206 100% 96%",
      "--secondary-foreground": "0 0% 4%",
      "--background": "84 39% 93%",
      "--foreground": "211 68% 22%",
      "--accent": "205 37% 44%",
      "--accent-foreground": "0 0% 98%",
      "--muted": "84 30% 88%",
      "--muted-foreground": "211 68% 35%",
      "--card": "84 39% 93%",
      "--card-foreground": "211 68% 22%",
      "--border": "84 20% 80%",
      "--input": "84 20% 80%",
      "--destructive": "0 84% 50%",
      "--destructive-foreground": "0 0% 98%"
    }
  },
  {
    name: "Europe",
    colors: {
      primary: "#2563eb",
      secondary: "#7c3aed",
      background: "#ffffff",
      foreground: "#1e293b",
      accent: "#059669"
    },
    cssVars: {
      "--primary": "221 83% 53%",
      "--primary-foreground": "0 0% 98%",
      "--secondary": "262 83% 58%",
      "--secondary-foreground": "0 0% 98%",
      "--background": "0 0% 100%",
      "--foreground": "215 25% 27%",
      "--accent": "160 84% 39%",
      "--accent-foreground": "0 0% 98%",
      "--muted": "215 20% 94%",
      "--muted-foreground": "215 25% 40%",
      "--card": "0 0% 100%",
      "--card-foreground": "215 25% 27%",
      "--border": "215 15% 88%",
      "--input": "215 15% 88%",
      "--destructive": "0 84% 50%",
      "--destructive-foreground": "0 0% 98%"
    }
  },
  {
    name: "Tropical",
    colors: {
      primary: "#10b981",
      secondary: "#f59e0b",
      background: "#f0fdf4",
      foreground: "#134e4a",
      accent: "#e11d48"
    },
    cssVars: {
      "--primary": "159 100% 39%",
      "--primary-foreground": "0 0% 98%",
      "--secondary": "45 93% 47%",
      "--secondary-foreground": "0 0% 4%",
      "--background": "138 76% 97%",
      "--foreground": "168 56% 19%",
      "--accent": "346 77% 49%",
      "--accent-foreground": "0 0% 98%",
      "--muted": "138 50% 90%",
      "--muted-foreground": "168 56% 30%",
      "--card": "138 76% 97%",
      "--card-foreground": "168 56% 19%",
      "--border": "138 30% 82%",
      "--input": "138 30% 82%",
      "--destructive": "0 84% 50%",
      "--destructive-foreground": "0 0% 98%"
    }
  },
  {
    name: "Night Hacker",
    colors: {
      primary: "#00ff41",
      secondary: "#ff0080",
      background: "#0a0a0a",
      foreground: "#00ff00",
      accent: "#00ffff"
    },
    cssVars: {
      "--primary": "135 100% 50%",
      "--primary-foreground": "0 0% 4%",
      "--secondary": "324 100% 50%",
      "--secondary-foreground": "0 0% 98%",
      "--background": "0 0% 4%",
      "--foreground": "120 100% 50%",
      "--accent": "180 100% 50%",
      "--accent-foreground": "0 0% 4%",
      "--muted": "0 0% 12%",
      "--muted-foreground": "120 100% 75%",
      "--card": "0 0% 6%",
      "--card-foreground": "120 100% 50%",
      "--border": "0 0% 20%",
      "--input": "0 0% 20%",
      "--destructive": "0 100% 50%",
      "--destructive-foreground": "0 0% 98%"
    }
  },
  {
    name: "Black",
    colors: {
      primary: "#ffffff",
      secondary: "#6b7280",
      background: "#000000",
      foreground: "#ffffff",
      accent: "#f3f4f6"
    },
    cssVars: {
      "--primary": "0 0% 100%",
      "--primary-foreground": "0 0% 4%",
      "--secondary": "215 16% 47%",
      "--secondary-foreground": "0 0% 98%",
      "--background": "0 0% 0%",
      "--foreground": "0 0% 100%",
      "--accent": "220 14% 96%",
      "--accent-foreground": "0 0% 4%",
      "--muted": "0 0% 8%",
      "--muted-foreground": "0 0% 85%",
      "--card": "0 0% 4%",
      "--card-foreground": "0 0% 100%",
      "--border": "0 0% 15%",
      "--input": "0 0% 15%",
      "--destructive": "0 84% 60%",
      "--destructive-foreground": "0 0% 98%"
    }
  }
];
